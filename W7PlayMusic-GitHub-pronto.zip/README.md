# W7PlayMusic para Android

Este projeto empacota a interface e o backend Python do arquivo `player_musica_v7.py` num aplicativo Android. O backend roda dentro do próprio app com Chaquopy; os dados dos perfis ficam na pasta privada do aplicativo.

## Gerar o APK pelo GitHub Actions

1. Crie um repositório no GitHub (por exemplo, `W7PlayMusic`).
2. Envie todo o conteúdo desta pasta para a raiz do repositório, incluindo a pasta oculta `.github`.
3. Abra a aba **Actions** do repositório e habilite os workflows, se o GitHub solicitar.
4. O workflow **Build Android APK** será executado automaticamente ao enviar código para `main` ou `master`. Também é possível iniciar manualmente em **Actions > Build Android APK > Run workflow**.
5. Quando terminar com sucesso, abra a execução e baixe o artefato **W7PlayMusic-debug-apk** na seção **Artifacts**. Dentro dele estará `app-debug.apk`.

O workflow compila um APK de depuração; não é uma versão assinada para publicação na Play Store.

## Gerar localmente (alternativa)

1. Instale o Android Studio atualizado.
2. Abra esta pasta no Android Studio.
3. Aguarde a sincronização do Gradle e a instalação dos componentes solicitados (Android SDK 36 e JDK 17).
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK será criado em `app/build/outputs/apk/debug/app-debug.apk`.

Para instalar no celular, copie esse APK e permita a instalação para a origem usada. Para uma versão de distribuição, use **Build > Generate Signed Bundle / APK** e crie uma chave de assinatura própria.

## O que foi adaptado

- Inicialização do servidor Python em `127.0.0.1:8003` dentro do processo Android.
- Persistência de perfis e cache no armazenamento privado do app.
- WebView com JavaScript, armazenamento local, reprodução de áudio e seletor de imagem.
- Ponte de download para salvar os arquivos em `Downloads/W7PlayMusic` (Android 10 ou superior).

## Observações importantes

- O aplicativo precisa de internet para buscar conteúdo e carregar os dados externos.
- A primeira compilação baixa dependências Python e Android, então pode demorar e exige conexão.
- O ambiente desta entrega não possui Android SDK/Gradle; portanto, o APK ainda precisa ser compilado no Android Studio. O projeto-fonte foi preparado, mas não foi possível executar uma compilação ou teste em aparelho neste ambiente.
- O serviço de conteúdo externo pode mudar e afetar buscas ou reprodução; isso não é controlado pelo empacotamento Android.
