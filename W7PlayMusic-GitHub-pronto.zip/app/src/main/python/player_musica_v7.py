#!/usr/bin/env python3
"""W7PlayMusic (v7, ícones, Ver mais, download com capa e app instalável). Requer só yt-dlp (pip install yt-dlp).
Rode: python player_musica_v7.py  e abra http://localhost:8003
Mesma rede Wi-Fi: python player_musica_v7.py --rede
Esqueceu uma senha? Pare o servidor (Ctrl+C) e rode:
    python player_musica_v7.py --resetar-senha NOME
Download com capa: pip install mutagen (e, opcional, pkg install python-pillow para capa quadrada).
Dados dos perfis: musica_dados.json. Cache das seções: musica_cache_v7.json (mesma pasta)."""
import base64, hashlib, hmac, io, json, os, random, re, secrets, shutil, socket, sys, tempfile, threading, time, urllib.parse, urllib.request
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

try:
    import yt_dlp
except ImportError:
    raise SystemExit("Falta o yt-dlp. Rode: pip install yt-dlp")

ARQ = os.path.join(os.path.dirname(os.path.abspath(__file__)), "musica_dados.json")
LOCK = threading.RLock()
SEM, SEMD = threading.Semaphore(4), threading.Semaphore(2)
ID = re.compile(r"[\w-]{11}")
NOME = re.compile(r"[\w \-]{1,20}")
MAX_PERFIS = 30
PESOS = {"play": .5, "fim": 2, "pulo": -1.5, "fav": 3, "pl": 3}
ARQ_CACHE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "musica_cache_v7.json")
SECOES = [
    ("alta", "🔥 Em alta", "Em alta", ["músicas mais tocadas agora brasil 2026", "top hits brasil 2026", "hits do momento 2026"]),
    ("lanc", "✨ Lançamentos", "Lançamentos", ["lançamentos músicas novas 2026", "novo clipe oficial 2026 música", "lançamento da semana música brasil"]),
    ("funk", "🎧 Funk do momento", "Funk", ["funk mais tocados 2026", "funk lançamento 2026", "mandelão funk 2026"]),
    ("transito", "🚗 Para ouvir no trânsito", "Trânsito", ["músicas para dirigir", "road trip músicas brasil", "playlist viagem estrada músicas"]),
    ("energia", "⚡ Energia e treino", "Treino", ["músicas para treinar academia", "treino motivação músicas", "eletrônica energia músicas"]),
    ("relax", "🌙 Relax", "Relax", ["lofi chill músicas", "música relaxante pop acústico", "chill brasil músicas"]),
    ("festa", "🎉 Festa", "Festa", ["músicas para festa 2026", "festa hits dançar", "pagode festa hits"]),
    ("foco", "📚 Foco para estudar", "Foco", ["lofi para estudar", "música para concentração", "study music beats"]),
    ("sertanejo", "🤠 Sertanejo", "Sertanejo", ["sertanejo mais tocados 2026", "sertanejo universitário hits", "modão sertanejo 2026"]),
    ("rap", "🎤 Rap e trap", "Rap", ["rap nacional 2026", "trap brasil 2026", "hip hop brasileiro hits"]),
    ("pop", "🌟 Pop", "Pop", ["pop hits 2026", "pop internacional hits", "pop brasil 2026"]),
    ("rock", "🎸 Rock", "Rock", ["rock clássicos", "rock nacional hits", "rock internacional hits"]),
    ("flash", "📼 Flashback", "Flashback", ["músicas anos 2000 hits", "flashback 2010 hits", "nostalgia músicas anos 90"]),
    ("covers", "🔁 Covers e remixes", "Covers", ["cover versão acústica brasil", "remix funk versão", "mashup remix músicas"]),
    ("slowed", "🐌 Slowed + reverb", "Slowed", ["slowed reverb músicas", "slowed funk", "músicas slowed"]),
]
SEC_IDS = {s[0] for s in SECOES}


def novo():
    return {"playlists": {"Favoritas": []}, "recentes": [], "gosto": {},
            "senha": None, "foto": None, "foto_v": 0, "tokens": []}


def carregar():
    try:
        with open(ARQ, encoding="utf-8") as f:
            d = json.load(f)
    except Exception:
        d = {}
    if "perfis" not in d:
        antigo = {k: d[k] for k in ("playlists", "recentes", "gosto") if k in d}
        d = {"perfis": {"Dono": antigo} if antigo else {}}
    for p in d["perfis"].values():
        for k, v in novo().items():
            p.setdefault(k, v)
        p["playlists"].setdefault("Favoritas", [])
    return d


D = carregar()


def salvar():
    with LOCK:
        with open(ARQ, "w", encoding="utf-8") as f:
            json.dump(D, f, ensure_ascii=False)


# ---------- contas ----------
FALHAS = {}


def achar(nome):
    n = str(nome or "").strip().lower()
    with LOCK:
        for k in D["perfis"]:
            if k.lower() == n:
                return k
    return None


def sha(t):
    return hashlib.sha256(t.encode()).hexdigest()


def hash_senha(s, salt):
    return hashlib.pbkdf2_hmac("sha256", s.encode(), salt, 120000).hex()


def define_senha(P, s):
    salt = os.urandom(16)
    P["senha"] = {"salt": salt.hex(), "hash": hash_senha(s, salt)}


def confere(P, s):
    x = P.get("senha")
    return bool(x) and hmac.compare_digest(hash_senha(str(s), bytes.fromhex(x["salt"])), x["hash"])


def novo_token(P):
    t = secrets.token_urlsafe(24)
    with LOCK:
        P["tokens"] = (P["tokens"] + [sha(t)])[-5:]
        salvar()
    return t


def token_ok(P, t):
    h = sha(t)
    return any(hmac.compare_digest(h, x) for x in P["tokens"])


def espera(k):
    f = FALHAS.get(k)
    return max(0, int(f[1] - time.time()) + 1) if f and f[1] > time.time() else 0


def senha_valida(s):
    return isinstance(s, str) and 4 <= len(s) <= 64


def entrar(d):
    k = achar(d.get("nome"))
    if not k:
        return {"erro": "nao_existe"}
    P = D["perfis"][k]
    if not P.get("senha"):
        return {"definir": True}
    w = espera(k.lower())
    if w:
        return {"erro": "bloqueado", "espera": w}
    if confere(P, d.get("senha", "")):
        FALHAS.pop(k.lower(), None)
        return {"token": novo_token(P), "nome": k}
    c = FALHAS.get(k.lower(), (0, 0))[0] + 1
    FALHAS[k.lower()] = (c, time.time() + 60 if c % 5 == 0 else 0)
    w = espera(k.lower())
    return {"erro": "bloqueado", "espera": w} if w else {"erro": "senha"}


def criar(d):
    n, s = str(d.get("nome", "")).strip(), d.get("senha", "")
    if not NOME.fullmatch(n):
        return {"erro": "nome_invalido"}
    if not senha_valida(s):
        return {"erro": "senha_curta"}
    with LOCK:
        if achar(n):
            return {"erro": "nome_existe"}
        if len(D["perfis"]) >= MAX_PERFIS:
            return {"erro": "lotado"}
        P = novo()
        define_senha(P, s)
        D["perfis"][n] = P
        salvar()
    return {"token": novo_token(P), "nome": n}


def definir(d):
    k = achar(d.get("nome"))
    if not k:
        return {"erro": "nao_existe"}
    P = D["perfis"][k]
    if P.get("senha"):
        return {"erro": "ja_tem"}
    if not senha_valida(d.get("senha")):
        return {"erro": "senha_curta"}
    with LOCK:
        define_senha(P, d["senha"])
        salvar()
    return {"token": novo_token(P), "nome": k}


def trocar_senha(P, d, tok):
    if not confere(P, d.get("atual", "")):
        return {"erro": "senha"}
    if not senha_valida(d.get("nova")):
        return {"erro": "senha_curta"}
    with LOCK:
        define_senha(P, d["nova"])
        P["tokens"] = [sha(tok)]
        salvar()
    return {"ok": 1}


def sair(P, tok):
    with LOCK:
        P["tokens"] = [x for x in P["tokens"] if x != sha(tok)]
        salvar()


def foto(P, d):
    with LOCK:
        if d.get("remover"):
            P["foto"], P["foto_v"] = None, int(time.time())
            salvar()
            return {"ok": 1, "v": P["foto_v"]}
        s, pre = str(d.get("dados", "")), "data:image/jpeg;base64,"
        if not s.startswith(pre) or len(s) > 90000:
            return {"erro": "foto"}
        try:
            b = base64.b64decode(s[len(pre):], validate=True)
        except Exception:
            return {"erro": "foto"}
        if b[:2] != b"\xff\xd8" or len(b) > 60000:
            return {"erro": "foto"}
        P["foto"], P["foto_v"] = s[len(pre):], int(time.time())
        salvar()
        return {"ok": 1, "v": P["foto_v"]}


# ---------- música ----------
CACHE, URLS = {}, {}


def cache(chave, ttl, fn):
    c = CACHE.get(chave)
    if c and time.time() - c[0] < ttl:
        return c[1]
    v = fn()
    if v:
        CACHE[chave] = (time.time(), v)
    return v


def ydl(**o):
    base = {"quiet": True, "no_warnings": True, "skip_download": True, "socket_timeout": 15}
    base.update(o)
    return yt_dlp.YoutubeDL(base)


def lista(entradas, vistos=()):
    out, ids = [], set(vistos)
    for e in entradas or []:
        if not e:
            continue
        i = e.get("id") or ""
        if not ID.fullmatch(i) or i in ids:
            continue
        d = e.get("duration")
        if d and not 60 <= d <= 540:
            continue
        ids.add(i)
        c = (e.get("channel") or e.get("uploader") or "").replace(" - Topic", "")
        out.append({"id": i, "titulo": e.get("title") or "", "canal": c, "dur": d})
    return out


def buscar(q, n=15):
    try:
        with SEM, ydl(extract_flat=True) as y:
            r = y.extract_info(f"ytsearch{n}:{q}", download=False)
        return lista(r.get("entries"))
    except Exception:
        return []


def mix_yt(i, titulo):
    try:
        with SEM, ydl(extract_flat="in_playlist", playlistend=25) as y:
            r = y.extract_info(f"https://www.youtube.com/watch?v={i}&list=RD{i}", download=False)
        itens = lista(r.get("entries"), [i])
    except Exception:
        itens = []
    if len(itens) < 5 and titulo:
        vistos = {i} | {x["id"] for x in itens}
        itens += [x for x in buscar(titulo, 15) if x["id"] not in vistos]
    return itens


def conhecidos(P):
    s = {c for c, v in P["gosto"].items() if v > 0}
    for t in P["recentes"] + [t for l in P["playlists"].values() for t in l]:
        if t["canal"]:
            s.add(t["canal"])
    return s


def ordenar(itens, P):
    with LOCK:
        K, G = conhecidos(P), dict(P["gosto"])
    itens = [dict(x, c=x["canal"] in K) for x in itens]
    chave = lambda p: p[0] - 3 * max(-2, min(4, G.get(p[1]["canal"], 0)))
    return [x for _, x in sorted(enumerate(itens), key=chave)]


def url_audio(i):
    c = URLS.get(i)
    if c and time.time() - c[0] < 4 * 3600:
        return c[1]
    with SEM, ydl(format="ba[ext=m4a]/ba/b", noplaylist=True) as y:
        r = y.extract_info("https://www.youtube.com/watch?v=" + i, download=False)
    u = r.get("url") or (r.get("requested_formats") or [{}])[0].get("url")
    if u:
        URLS[i] = (time.time(), u)
    return u


def limpa(t):
    if not isinstance(t, dict) or not ID.fullmatch(str(t.get("id", ""))):
        return None
    d = t.get("dur")
    return {"id": t["id"], "titulo": str(t.get("titulo", ""))[:150],
            "canal": str(t.get("canal", ""))[:80],
            "dur": d if isinstance(d, (int, float)) else None}


def evento(P, tipo, t):
    t = limpa(t)
    if not t:
        return
    with LOCK:
        if t["canal"]:
            g = P["gosto"]
            g[t["canal"]] = max(-5, min(20, g.get(t["canal"], 0) + PESOS.get(tipo, 0)))
        if tipo == "play":
            P["recentes"] = [t] + [x for x in P["recentes"] if x["id"] != t["id"]][:29]
        salvar()


def pl(P, d):
    a = d.get("acao")
    n = str(d.get("nome") or "").strip()[:40]
    t = limpa(d.get("track"))
    if not n or n == "Recentes":
        return
    with LOCK:
        L = P["playlists"]
        if a == "criar" and len(L) < 50:
            L.setdefault(n, [])
        elif a == "apagar" and n != "Favoritas":
            L.pop(n, None)
        elif a == "add" and t and (n in L or len(L) < 50):
            l = L.setdefault(n, [])
            if not any(x["id"] == t["id"] for x in l) and len(l) < 500:
                l.append(t)
            evento(P, "fav" if n == "Favoritas" else "pl", t)
        elif a == "rem" and t and n in L:
            L[n] = [x for x in L[n] if x["id"] != t["id"]]
        salvar()


def para_voce(P):
    with LOCK:
        top = [c for c, v in sorted(P["gosto"].items(), key=lambda p: -p[1]) if v > 0][:3]
    if not top:
        return []

    def f():
        out = []
        for c in top:
            out += buscar(c + " música", 8)
        em = (secao("alta") or [])[:30]
        out += random.sample(em, min(4, len(em)))
        random.shuffle(out)
        vistos, r = set(), []
        for x in out:
            if x["id"] not in vistos:
                vistos.add(x["id"])
                r.append(x)
        return r[:20]

    return cache("fy:" + "|".join(top), 600, f)


try:
    with open(ARQ_CACHE, encoding="utf-8") as _f:
        SECAO_CACHE = json.load(_f)
except Exception:
    SECAO_CACHE = {}
REFRESH, SECLOCK = set(), {}


def calcula_secao(sid):
    qs = next(s[3] for s in SECOES if s[0] == sid)
    with ThreadPoolExecutor(3) as ex:
        listas = list(ex.map(lambda q: buscar(q, 30), qs))
    out, vistos = [], set()
    for k in range(max([len(l) for l in listas] or [0])):
        for l in listas:
            if k < len(l) and l[k]["id"] not in vistos:
                vistos.add(l[k]["id"])
                out.append(l[k])
    return out[:90]


def atualiza_secao(sid):
    itens = calcula_secao(sid)
    if itens:
        with LOCK:
            SECAO_CACHE[sid] = {"t": time.time(), "itens": itens}
            try:
                with open(ARQ_CACHE, "w", encoding="utf-8") as f:
                    json.dump(SECAO_CACHE, f, ensure_ascii=False)
            except Exception:
                pass
    return itens


def secao(sid):
    c = SECAO_CACHE.get(sid)
    if c:
        if time.time() - c["t"] > 1800 and sid not in REFRESH:
            REFRESH.add(sid)

            def bg():
                try:
                    atualiza_secao(sid)
                finally:
                    REFRESH.discard(sid)

            threading.Thread(target=bg, daemon=True).start()
        return c["itens"]
    with SECLOCK.setdefault(sid, threading.Lock()):
        c = SECAO_CACHE.get(sid)
        return c["itens"] if c else atualiza_secao(sid)


def secao_pag(sid, mais, ja):
    pool = secao(sid) or []
    if not mais:
        return {"itens": pool[:20], "mais": len(pool) > 20}
    vistos = set(ja)
    novos = [x for x in pool if x["id"] not in vistos]
    return {"itens": novos[:30], "mais": len(novos) > 30}


def busca_pag(q, pg, ja):
    n = min(30 + 40 * pg, 150)
    itens = cache(f"s:{q}:{n}", 300, lambda: buscar(q, n)) or []
    vistos = set(ja)
    novos = [x for x in itens if x["id"] not in vistos]
    lim = 20 if pg == 0 else 30
    return {"itens": novos[:lim], "mais": len(novos) > lim or n < 150}


def capa_bytes(i):
    for nome, barras in (("maxresdefault", 0), ("sddefault", 60 / 480), ("hqdefault", 45 / 360)):
        try:
            req = urllib.request.Request(f"https://i.ytimg.com/vi/{i}/{nome}.jpg", headers={"User-Agent": "Mozilla/5.0"})
            b = urllib.request.urlopen(req, timeout=10).read()
        except Exception:
            continue
        if len(b) < 5000:
            continue
        try:
            from PIL import Image
            im = Image.open(io.BytesIO(b)).convert("RGB")
            w, h = im.size
            if barras:
                t = int(h * barras)
                im = im.crop((0, t, w, h - t))
                w, h = im.size
            s = min(w, h)
            x0, y0 = (w - s) // 2, (h - s) // 2
            im = im.crop((x0, y0, x0 + s, y0 + s))
            if s > 600:
                im = im.resize((600, 600))
            o = io.BytesIO()
            im.save(o, "JPEG", quality=90)
            return o.getvalue()
        except Exception:
            return b
    return None


def etiqueta(caminho, titulo, artista, capa):
    try:
        from mutagen.mp4 import MP4, MP4Cover
        if not caminho.lower().endswith((".m4a", ".mp4")):
            return False
        f = MP4(caminho)
        f["\xa9nam"] = [titulo]
        f["\xa9ART"] = [artista]
        if capa:
            f["covr"] = [MP4Cover(capa, imageformat=MP4Cover.FORMAT_JPEG)]
        f.save()
        return bool(capa)
    except Exception:
        return False


def aquecer():
    for sid in ("alta", "lanc", "funk", "transito"):
        c = SECAO_CACHE.get(sid)
        if not c or time.time() - c["t"] > 1800:
            try:
                atualiza_secao(sid)
            except Exception:
                pass


def pessoal(P):
    with LOCK:
        top = [c for c, v in sorted(P["gosto"].items(), key=lambda p: -p[1]) if v > 0][:3]
        favs = list(P["playlists"].get("Favoritas", []))
    out = []
    if top:
        mix = para_voce(P)
        if mix:
            out.append({"id": "p0", "titulo": "🎯 Mix do dia", "itens": mix})
        for n, c in enumerate(top[:2], 1):
            itens = cache("art:" + c, 3600, lambda c=c: buscar(c + " músicas", 15))
            if itens:
                out.append({"id": f"p{n}", "titulo": "💜 Porque você ouviu " + c[:30], "itens": itens})
    if len(favs) >= 3:
        out.append({"id": "p9", "titulo": "♥ Redescubra suas favoritas", "itens": random.sample(favs, min(15, len(favs)))})
    return out


def meu_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "IP-DO-CELULAR"


ICON192 = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAMAAAADACAIAAADdvvtQAABVjElEQVR42u29WZMk2ZUeds651yOzMrPWrr336kY39hmgMQsGA3KGJppoNI0Wo0zLq171IjP9CD1LTzI9yCSRokQZKaNpTCJlpIwEZuVgADS27q5qdO372lWVlZkR7vd8eriL3+tLRGRWVS8g0rKzoyIjIiPcj3/nO9/Z+I/O/Df0ufnCwK3OHfA/0P8Vuq/gH4XsV2ifC8QXARFQ3gN/J9LjAcQ7e/8E/A0Fwb9IfIxmD9b8zvhIjU8PdwKaXhOkvef6F9f2r6R7Ou+wuE3pLfkP2X6K9PHbOym7nwgQ+vXXgEFiyUe2Nrjck/uPwcgTl7m9xAd5tp994Et+bTHlPQNHcwC6Ro46FlkJFr2VXd1ezrCwp6PxawPahRnh2Vricz9pS/91PO2rLn6lX7uwvdgansJKngkIPT+L/DUCfULAs9uziGd6yrHLV8aii2HPZim/tptPzdY+EfzYFUPG7n8p/5ZZz+6cP57NOcbQK80DEXTVh2fgxZZHGuwGSeVX3Vbw6YEBljCdvQdYePbHay9/SH6l0WWUwi48aXsylM73bik19nxh7IFgYdGfX9Kdya+c9ezuYOIZm+yeA7JdxV4L3d+eaRB2+8Hk3xLrwS4vTZqTLfnkWO9ufTGe9/Ht/9L+atnKHFa4W2+3DB3Bp/HZl7SwAU+Kp7Cbsefaz6HpLAB2jFvPcgcFn0kb2hUm4RN7B/bzZjrLWM+uDmSWgZ/Hp3cd2WH3V/PzFimex5clAhF/vtSaPcMU5rHFvUs/i6wPPR6WSiNGJZ/PlPVgrgE9q3fAn8gnx54vaCwVzO7OXMaFx7Y2qHzYgA40aNbYJYfrGOtuDxL2eqjtZwE8nrk/2yVk7PGDobCJ4htLvBIWMWKMRJF7/exzBKqncmGfPwq91189VV4LA0azi1gRA34KuyorewoV9LkQfxATwX4e7eaTfD30al6fz3sEFpkQPhusuUNbLHb9lE/RVpZUNZ4yAMoqnecKBM/nRI45L8xnJ+MfG8/j8sSeXdhnw/J3G2Mv9HV5uXgoIn/KMH73MeLipy9JdZ/qZHF6Wnsrv9n5+hVIZSxswMByFoeBho4Fieo5gc+cxOpTusKljGkXf4CX8zI8/A/5fBoKLV0XsYDbYNwz7lL4zzpjuqF7N4ZH733sFUrn+Na5n4LL3yzHS8ADj/xVU6KXC0IGGiuw9MvEtjGM6kAYtMVBq0IPAhc7pqdxUKOV3R0nxWN/gYkLum/39D74EzSX5QF84Ysis56FYINF8VGHaNNuYWy8+3HQty77KUe9WN9EOi/cJzqcv9YwD7LP7Ux/OoCFpYUSjFKI4WQqulH9uJEuzU5G7hwjbdhlxApi9IxmLszw0unDzyeJnqcJAwMdgL04HCMnfywnAQw8rU+0+3x5fnUixo2wE64vY0y9x3DBb7C089gDMFj6vH1hUDVZQqQF5pKBOZxmeaAZDcp2FQ0sDNcXO6w5vmm3rW2LDGiZ1/j0s/XDyXOMKouYe04GKe9CIW70xC8AsQ6c8BxDnIc3IwiTgVRuKDxeI8cLpEbsEoGw2GT2Zqj8DLAGyypny+SCQEsxCfTcR+GY8tAfIzZUUM9RG83fiee0XD6QO4dywKMxof1tuq56NsJL9vUMEmnMeb5dJm+8J/PgJV5jD3Uwy5QaZiYGlId+TIZBeUbRDfnLuLuXWO0el56hzBEzPZzo7lQonhubcSn1YG+B9hLPYrZPhQ+flUhtRH/rWk9fgOkNvFnUvzF6vTHKGqAug+6z62g6oPlZd87OPw+hXHZngp4i7mZeXmAaBstxc/p8keiFzhr9y26R9SzAxjwbj37kxUu9aURbwXi94uAZxjhRy9/AQhKemSBnf2RAGipj+046LHdnnLoy8Nmhyksj2QCnRu9fGBbuFtpNNpmLBuGjpCVDrBnZnQjHelAKArj7+OyiHx67NvA6PHoahxEnYRIwLDrPubP82/aZOh1+DraymEJjKY+GEdaVsx/0iHbvZHGhJaLVo0FDWlCHj4O7ltpDtY7x7YqlDGVLeOiodLxb14y4CBgxTrPwjAvK8EkD0bhfW5SQL9kPBisGe6bH7RPQ9TXUy6cixEMjMUD75niMCXFO1XN/CYCIcyqNQnQeABBIq6OjYxzMICboMNfhPmNvHzdaUPYp+rMlA0PMa30fZBUdXMFc4ad4qXiOMcSlBkN3Hok020r7PE7tOcvSOrkj9hTcK3ujPRWAk7X1fVBgPO1fKujRsrhndz+T4alMi3eBVHuc1YRhl4exM5p7pE5tUIvorXPBvJLTZDrAUOIdoyQ7HRuO6NIhbZz9ezCG5/GDxFx8aM5auebhDZefbgideC9RGJ4Duuz6BbDYbREGsqGDlGhQCsqOW3mec9sKtxllsNZzZPnLFmdzOELsiz2Yh7tdFTAU7gzEDNz/EwOP4R4Ijobx/PkL4zHPmJZsWMCc5HYBQtxS3bx4IzOUyIvnpz947D3lSQlFNywv0ungNNi5G2hjTsjA8WGa7mQiRpQuu2aUbgcoinjF6H0kzHNhzzPaekrdecGdg8Eahut7BuCn0PkChoyUBHH/qI+mvvscqBORdVQ79DEwh4eOFJ5eq8uWuKs7oPPus/ir4EPRnWkv38JtCEeAxV7M5FPspV1oPYNdDRgh1BiK5Fsvgz4BT/IMt8wA/T5UHsxmgKR0YGjVoH6Yja4vaWO68HiER+VG3atN4OIg8ADhR4LCaDEtV5fBopIsCqMuRedPzkye1qgwVyVa0noGZZtcpEGHBYNHtd82WENmUgyUPBRDMjSYSu68xGHgki2VGViAw5/uSD69stQFDRgsBB1mQwWJ3lVmk5+3X8MutcTFvRkYVtt6IMTUy3Vk7IfRkRWRRLW+BhDODidXWJ61FEVz5z3281CZuXOhHoFRsKmexNw5Krmow7n1ZF6YuXtEhUmHYzb77M4vnqtFYfSvDrMdDMtCBSwNJFPj6dDylKLwIL2/2Cq3nD8F3MlspHgt0yGZkdrRGD2H0KPb7cO7h7u8BjJRx9sDJ1jKDkNmK8Hi0st09ENhKhoJIomeA5j8lDwaz+rZy6bDlgvmS6vKzwYH9qIBUDy6IGMPSAcaJd3plgd17uQsF8aFvhTTYUNz+FKAN8SQ8iw9qFe0w9EIqFQNWrvi1mw4F5eylCon4PF3CkGpQ6L3qtnskSAxzVU7eVm7whA8YVSPxggmZdSlEA/RvfQZyNho8bTyMyH6Mvb6MQ+pmZzzIeSpXwQP4m9rSd4Tw29pfBSpo+icf8p+VAUJ2CoZQpbkGh1ZQrgg0UVsT+Bdh/FMz+LRvLQb7Okm+XWC7mFaTkUcSMtzN4LvZAi65RzcLX0vtcQUcWdXeUgdcAq8ingeFH7F7a/AbayfMd2EGdmxROsQaayOjJkY0cAR/5lZzFilR0GJuOwH2jUHwlPYF8/9N5ZKXpTGMFZOPycWQ4E3fb/G3fFhhdiDJDDGtW3RCnKe0fo4DlGMv+4hrYmKRw/Oo7bWmCJE9NtIIun2VEhbD6fq5cLs5Pr0qUaw0fhUIuXySsm0IEZPLOdoXqBdcaD5RsDj1sDjhoSlKxQWTdkdTqbODeM73ioxjbyIAp0A1kMQZ+EvcwBxJQb7C5iRrlTiLG5P3iEXmDle8zyUneUstuLYApuJAsjePDjSfZAwEO9BWHhIILDEbYXeKBWIQAiK0hSQLgL/Wbn0viGSjw/gxA+xdwRC1264OLVjcX5b34C5/aCD1UujWDXWYc5DfKiHPTzc5uvfr6T0N0BtKZYPwZmYOKQgwiFNtVrBsLR1tyHI4pC1yJZLEiPmUAFvqO2GTYYmDq6tZuyfkiTFFsmYoO2voAHe1EORhEwGkgkimnhMpBVhGg0FZdGGmO3AeVyK53DZMcD5E+cgUCrIysKApQr4MZwVHM41YbEaFM85MwWZLMUaBP8JuNB+KeI/sg8LBpGEM2QI8GSISaI3hHhZJd9XGlEKwQ7afaXFTtbWhsTf0PS3kM/SQ4ZSqm05Zua8CBpQBEQqwRBZAO/7qNPDipYsU2Zh+cUbnmDRlzaXqOSIXDCaEWeRQPvXOoYEDGV7GYkxLCll7i0hX/j8XPhJVCW5IaYUJKdomP2lC/YwwCxBJAQBHEIuApFovEgA5ixmCo/Q4CCQgizq7bxNlpGX6xMEOdIgB54ATgwheNRRkLcY9t8ASH3VmJJKe0gkGpan2IzWVSmKkILLFh9m0q4LW3ruJCKKsT82PqRkbqF7nDQjUjNGFoguNJ/R3PtInnV0zg9K9sN5SNt6ZmZuoyew/zeIidlE6uMvJJCAmDXxXwb5B3BIgUd7QrYQ2mOPotWc0nSroqOjw4HKfwb0ZAKgjIRwgCpDAWEowKxMCjADTBpdK0DkiBgspI5IkFL2/iAIFZ6O+in6pcJ4HqXJ3P4uh53oAEZINDMIeaASTmQrnGDgtO8iRT9vRFRWMlFYT3GVeZ7QuiqGEAjMAiZlYok+0JNQ9oYF5fDBPNmgXAJgdLPxefyfbRBPcBLfuRbF2ggIxN315OrpDgICAVBSJVWCkiipsjKBwQRVYiLV4M5AJIbUFfky6tVyIBfyAkotMyOx2xgUBASvczAzcYQefyMaUGZjmVqOAJQIyT4knSFd7sRDcgv1BJ+xPW2lWsmjUlBuPVG4ibbPXFw3HAkQszCCWxAoE8TfT8REAmLS1Gjhs12cadApt9oKky1stF4Vo66Ns8HCQOHO0JJlJYDUkbchpwQX7ncunKKENUohcAuhVlkZmxcoMspsWojCdtuEGkyPW+AJRhOshznaDvOAdhi1ijwJEwBIB9LVJXHH0HiSwSZeUDkPiEfaxDLrSR8p3GIftDN82MJMTOL/KUTCYLCAmSDETCoEITBIIl0IhtW6bCTcSnDCOfYgXkFAPkONvRGiaAJJQVxAHY9lGjiQKqkjVcCRU1Ih5wLGKJErbIQg0eY4q7bP+NBguQmRR6D5uTAe0Hs4XaPhYMdbzK0BBXvq5KEyG9b2OvJvNcnyYLAuUxg02h2GIc2ROxp0MHAU1pMQleMHJBYGMyRmKgyp+N8TDBETC6kBMbEhCEM8rY7YE44HsoxsNo+RszJ75P2KLeoUCmL+MP+ZfBgFRYjeFaqkDqrkHKmyc9CGG4Fjco6YiJpC2A8iJJN4jbHMrgUhlNsKpqzI2mbS9cApYkZpeIzInjiBfwIeZiZhlsyXFR+aAzhDgzrS/o2MSvfGbvAc6kNjda49sCkSSgymnvXELwmmH68IYoawhxM1TAIWhhAJsRAbUiH28GOYjPdl5LlRIEcMj2H5nHK0+W/V1tVmKe/8qmr17dyRJUYOEEiVfViujtQDj4NryDlqDJmGGg5mRETsiEBkwss6ju+GB0a49QtbUyoD82N39KSfSGoiXWAmlnDgJTeg1pclePBQG3V1sIJIwUELbaUscG8SXYfQzCXRA4ntcElnTg/MTGCSCKfC4XMws3j4YRH21iNMTMpMhrzpkCESUsNkiIVgiITJxBtCMN5/cQjmOS9TBFoiX2Th8mrrXB5Pj+SCQkUhInquoOt4b9U4UsdNA9ewqVEHx+DPmdZEBkQgpywShMcQ0nFK+JcSWy66ZjXRWCKxMDLm1V+hxOSPsQhLOOosTCwsLQB4i4EPD5iYAVZyqT1uaLQNxsAHNFg3M7YrDOXzvKgDj0SSWY/Ea4HCbSEREibDiMAEE6wHhtiyByGyTMZ/k38wGa+/BN9Hwih11CI6Q1tP0qkzQZ78yMpP26xs4tE+klfHzsE5do5cQ3WDpiYjJMI1J7WC4cuPlNQQg0RIPSxxVj7GZa6+zA6AaU5RPfcSFZyTTqaM+Ug8A8Ishk24IUbVy2ZkrSigqmBVqPhwgcAkqbeWkbAnxfSFvjlYzAkU8WU/I9aZxYRU20nBUkIAQOmDGGZmNiKGRUhYjFEmBwVLVYkTbz1gb0mWyRJXzFYU6gyTFV4xJCTMEIYEKEouAsWkgiSGlaFFe8mHOBXJgcRXIMqokr8wAThHzsE5N91BLSxiKqtT8V64JRQAQ2EMASF3q7G6zSfqc8kHWf4rpQdHkqnMfUfQpgmpYD5EbQDGIizCxrAREWbZ2Zpt7F9bWZmow6OHm7Yyla2cOianlF9R7Eg4WVRRjLyL3XL9dotBGMulqxR/mWg9hg2LCBtmEbH+M02ntVmxBw4caEgfbm7xijFVBVE1YEtkmCfcQGe1Wzu6QZXZadzmzpQtq0laYaDTWSVQUZ2PgTlCUaJvqQklIsVcijKIeTEFhEhBQvuPHDaq083Nxw8+3re6IjPWNu0W1GpSkCh5vVG8xsWZoXTCsY4A4hGolfIHWM8gFUpPDhSTWAINEmERI6RM4O/+rW/+9u9/dd/aiirO/vzi9//ljx8+eFyt2MZlIBgklbagN/6jczkuJD1zojPuKUAca3UCdvq3LxQQlNkIGxHLwnXtvvHOl7/57a8eOnJw6por12/9yV/85Prde3Z9ogK1JBVvu2b9+P6/8Xe/8cbXXxXhre3pj//q3OMnO2wlI0DcrT8eHRJd1pt2Jp3xYLIx0UswUM9mZ146+fUvv8nCW0+2//x7f/kX/+rPyfpyMi8wOjKGVEmUREgFLMSaUZKUi+XuJDUuvBv/4cv/9Yjkw73/M6WDzd6piogxLIatiDVsjRjDVh39R//5H/72d9/efgKFMtHqPnP7xqP/9X/4Z/fvPRTLThunjVOncA5OtfFBp4ZYVJWy4GKxDE0jibAuE2JqJSofM5J44EzYaUWMsDFijTWzmfujv/cH73z7azPnpnXjBDKxT+r6j//Zn/ziwwvVxkptsaNu7eTGH/1Xf+fo6cM7W1MQGRFrDcoKv2dbqbfMV103CojI2nr1p//6r//R//SPjGswnWK6g+mUplPMZmhq1DU1NZqG1PmzEcCpTYwQpfYwlGNMlh80zlnKoa0kD5gaOIQwG2OnW/W/9/f+5m///tsP78/EMDMD9Pjh7IVjB/7T/+Lf/R//u/+raWrDFhJiVlYwi9fYox401oo9vy0eSxR4BOE7JCg8W6bW/wobfzFYa+up+813vvRb3/7a5pPthghCTrG9tcMr9m/+rd+6fu/Bw9k2kbH7zN/9L//2oeMHNj/eEiPEVLtmNmvo0/7yH6xpmgf3p7//B996svnk//z7/3htMtGmgXFkGvK+QrwaEVU/zgOxhDRCpEXVRyqSTQw++84Svty5s63ljmAXQlUhFjZu5l58+eQ73/7i5uPGGOFIlIyVra3ZyRcPvfO7X3I1rLVGjBFj2Jhw9qJD9GFRVD7Kvoa0raGIfkO6uS0AGmqIyDlpFgV4Ji1kmA2L91zGiDEkK5PVb/3uV5xzRCQSEEKMTGf1/oMbb33xjCq5Rr/8N94++vILO0+mYiXBW4K1T/E7qVvGmMePdr793d9+6cyrM6dcWTZCxnjTCVqXCKVzQFlnKmc/i7ROXnLXHvSB7Y2lUIFu00FUnYlFRFyDUy8e3bc2Ue3WlDEzlF45c8KbjrDxnzTYDsVPHNTPtr2zY0PRjJiLxC33pfMs+9/yPPgwlZkkCj/+XbAYFv/erBiCWV9fO3x4f9M4lu4ncQ5Hjx0WMcRy4o3jUGX+bM53C0deVdfX97342osNwNYG6wnfDJGWWjEXFhOKrLn4bTIjJovOEAbqdVN3nUlMPGR2mn3JvEPJVM+csBUWww4s6pUWFrCGmgmPlSkc60XzfYWhswcCbZ15KV/EWh+OWnFQH4iFRcTTIPEEyDV09Pjh1X2TxsUouledwCzMSp+TL/jyVmNIqLWeBPueROdBahurc1FNHvp7QgRduLABb5aa4IBF4/sJoEll71x/sP2kNkYGJhUrNvavTaoJkxG23l8E8dqLMoN2EvVcnw7I740ygteGmbJrJNhydklxVk6bnp3SdxJUUGPEGGMJcvrFY5OVCuiOimOQMXL/7kNfxHHr/F0WBvBZNh0R2d7euXX7XjWZwDusZDpF4JRgvUQa3wbAPYji0oVlxQFA/58xFYFYQ1k0DBET0WSlunX9/rv/5sOqEi2PKTPPZu70qy8cO3FIGwpejIx4tc77lTaZUCBpbi8xO1ACXysixxRoVkPLeYlvBs5MTBToM/voPbwrmVSTN9560SXFKsujWGMe3n90/sOr1phqYs/96Ud3rzxYXZ9oo11XX9L45/e9yIB0ZWVy4eLV6zfuVCsTUE4BSrPoZ9ILGtQhCExEkkFNaS7cQtAQSeofk1ADPFmpfvinZ7eezLogxKSKlX329S+eJkdGvL+I31GS8do0l/0LGdq02XKvsaRMHKeQinI74qxrnFPPr4/hi+xX8mJitKETJ46cPH24qZtUZckxnzaZ2Pd+cuHh/c1KjBC5af3//vf/6uPbj9cPrXkdKXyXlNbs+ZsXf8tcBsbMUHzvL36kMQbN0BjFOJLWo3XoTjoG3HnM4jA+7zhBSzgQKiSLEswQp2xvze7devjSmWOznSanRL5+/fQrLxhjRCjQ1+TCUlNn8lNZXQflUWaqvSiqr+Hzo75VPan+5X7GtvBE2kSMD778WRbDtnF64tSR1X3Vk+2ZSCtyMsgIT3dm16/cXbHGqQJqJ/Lo9qN/+t/+82/8na+/8bVXMCbrcNG507k9OLZ5hPCVJTaxOmvFDC9eUsW+1ckHH10+d/7y6r4VfbI5ktXsZjuR6E4qnWjnn1FHiR5qqEGuo7dvlYhAGtO1vtw/tVr7mg2ud+qP3r/x6heOo1MIy9zU7sSLhw8c2tjc3BQxDCci7FI6UxiaWTjyhVRMRCwh6CtqAwpbz4ibxtbLjIpzvLI4z8C3YMEsxsgrb5zQoaHQE2tvXr378M5juyLOORZQ7SYT2bq/+f/9g+//2Qvrall9EkM4VA4JgzkkU6Xoq+e8zYlTjsnzulhGYoTEkBHy0VNlyRqylq0lY8WaJ3Xzey8d/btnTm3VTR+KfGn8937wU1WNzTxAPjmIc6PJ2A+jk6/Lmw+SlViMtGKVFWu5ZK5gQUjySM6QNPIjU5nLv7y1s9WIn6eUHSPX6IHD+156/djPf/TYrhin6bSF86kcxP/UWZNhTObBUl1CXqrUlnZmTTCMTvdP5uE4FBFQgB8RQ44OHNx4+bVjrnYeftqoDWSFr5y/5WpnJszOMRyRYuqMpZXKTB89cYbUsPOVZYYhrKF8kYglz0ignbsQO2mSPUWhwWfRyRiqDFlL1lJlqaqoUqpUrKqzxsg3jh9qFP34N8DPxavnLlxdnVTuyYw0JsLUX19lkMt5cQ+XRsO9VkD41ub+nNGuDaVq2Nje6BMUDAWJIr4phMZHtdY++njr0YMnR47vb2rtm+TrXzz5/ruXmCGxeEiS9Xh0kFSQ25Yre5YdzjqXxC/2XiFUKiiYAc0DzNbLx/g9BPCt+RojRqd4+bVjGwf27WzP4tsIx02YXKP3bz00RHBKBFLH6tg4AsipmNCKBfgEJYUcuK9Hk2AiEl2sptIADh9XfcOQd7EigJCYKMT4Qgv/ugrAEE2b5ndOnzi9f9+T2Sj8fP+Hv1DnQoF9KLMPaSK0cJRnu3gcRJD1yjMRWWAwjTpMh6Jz0+gUPAgRSDV8KlUoC21v7Vz66PbxFw/WM1fQIOamdqdeeWF9/77t7a1wIkUYkipDov9Kw0SS44mFaz7k7lbNUmp88deXEoNVkUqPEeFHfAam4NCBU4sSvXLmRH4hpT71ypp79zbv3HhgDdfOMTlmR3CEhlQhyg4k8NVCJAThIC+Ih9SsJCgUKxaDXZRji5SICrMRGEPWEGxb7s6MUDsjDfPapPrd0y/UbkDJVGDfpPrg8o2zF66uWtFpQ8mMYrarqDRugb6jr3FWyscdImcx1og8wP6USHwRD6DErCS+NwFQb0PRi6mwufjBrW/83hv9mmptsL5/5YXjBy6dfyJWRCXW/EUkgIQZopxcYB6oB6biT3kKLlvdAb4JShlOiRnqC/VSGWtmOqkCLpRwkPK+tcmxUwe1ccLc1tcyETCx1bWLd6ZPZrJG1DhiR+RIGuIGosSOBNk3k4kwKql5jtqmIi6uyzBSwTtwIyQCEbKGnAkw2uYcGnLCanam9XdfOn5yY/XJIPshUqLv//g9bRr2RUKp0j7DoaEqmbx6hwYYf9afbtt66TH7QVkGGIqbUhQWYTEm0kGqqnZib129d+/W4yPH97tay3Iv2Im8/sWTFz+8YSaBOwuzYVGwhBynuFDe3Ubd4UyLl45MsACR9EEBdcmUoQxmqJJjUo1NETGLYSK/ECGTCJDWevLVIy+cOFDPmghvvguDwdTUzaUPbwqDHAAFOZAjbUANi2N2xICoNyAwk4CZ1fdpFI27KKLjjIJ4uu3fGoywGlgbnuIvsUZIhJxzTbOxsvLtV0/UOg9+zl24smrETZtYaJYafdoKkLIMKXZ8I+PLwFChBnxNNBYt7MlnDShIGAo/VAAKCKCAQ3bmFI4Y29vTO9cfHj99sBnwYvrKm8fX1ldnzY4EXhPsQ9mEpquseImj3Oeth9mYkPuUetqohlZua82kqpw6ZV8oIoyGwQpH0HjhBAYtMY2R1VJKo3j9rVPWymzaxoE+gLeWnzye3b/zyBqqnSM4kCNqQA1xQ64BK1iJFQJi9c4r4kpIPKKlE7E1UKjHnZlMgB9knoukISNwyqpM2JrW3339xZMH1p5M62H4Af3Ju+/rrGZ11DTknK+VRrjeteWunbESXIZdKTbsTZL2HCgf0Y85tSlZoyRzqD7y9akefpxTFXaAU3iKz1c+uv3lb70yIE40uv/Q2oFD63du7bAxrKkUX5hFIIiMM6R8u+UWxoghEm3w5a+88bVvfMFaefRo6wd/9ovbt+9XqxOnjVOJ7U+OiJkcYgFyoFAxh8psvBpJxFVlj5086BxyfQREpJjY6qNrN7c2t2kCdQ7kAKfkiByoATdESuQgINLQIc9xBhD7+mtORdBZJjG2iTMHqmSEVMhIMHpmiLBzcIZd8EGuaTZWV37vzOm6GYWfs5dvnL1wdcWIm+6gafw3NQ1yJtTOT0cxnJz7dAdlhBbQyfYWH9PcyS1JgQaFHLRTsMD4vjRAFU6hzjlTVVfO3378YHvf+kSzU+Il6dX16pU3j928dtfYTLBFqA8MQQKDUv0aiyEjEmrWhK06+g/+k+++8ztvISpe7/zOF//vf/JnP/rBBytrK3VTC9iBGeK0UR+UhXLQzCJFjPgvow2OnTh48vThZuYkBoCcjVS4cPa6c04AwCkaoAEcqAk2RApyxEqsvj0+i401qyoPslmhm6bIwTCpQIX9CG9miJAatP2mKkRPpvV333r15KGNOfDzvXff19mM1VFTRwRS3ywGdQF+2kies7GKQwnUosCwQ6LnSdCdnh8wMTiQXICVWFjD5Qjn4ARq4BRqDT36ePPWtQdvfuX0tKk7F4o6vPb2yR/92YdEjlmEfCxmhADx+lI829F/GbGGrRVrxGpD//5//N13fu/Nzcd14lbGmv/wP/sDVfrZu7+crKzUjgOPEmI4JfG6dqggI5HQSBEyGPVUX33j+MraZPvJlKUo6zdGtp/Mbl69Zw03roFvvIIjNCAHNBTcmXpH5t8+e+KSWsC4rVSh4h4GM/v+DQgkTvYQjpXLGmVRMFHj3Pq+1d97+7X58HPuwpUVYTededRB05CLgZiLDUDI+0CoHJ9QpgBz54W2K1MG8+/lt2bZ1pRPjZTZB10BeDywa+Rpzqm7ceUey0B2ppm5Ey8dPnbykDYIZaWeEUsMUkWMiPHpcbFGrBVrjbV2ojW/+farv/k7b24+rlv4MuKcquof/p1vHTxwQMhWMrGmsmJtKLcV4+tW25+x8YKEwCsrkzNvndIygeqjMGvNg7uPNh9vs5BCVZ2qAxTq4Jw6p66Bv7L9SXKNb8iiug5nrmmorqlp4rejxvkb/gHQxndTxJ7AEJm00l88dDuz5htnXjp5+MDMucGUiYK+96P33Kxm77P8X3S+YtWFWDlFYUAcmMe9HCp1a4PKOog4ugyaF2wMFXO0siXSCLUoZ0biHJyXRjRSVbZ08ezN6XaUpHuJ1WMvHlQHEwIrKU+tSaTHsLVSWZlYmVQymdiV3/79L6t2sVOEZ1N35OjGa6+fRs2VXbE8MTIRroxYI5UJ9c55sjI4MShtbOw7cmy/qzPKHy85MXzh3I3pdEakpM7LXeoaZJdNaz1NMiMXYp/Ghfvbb29DbXAUDl5oaPfJxpBdyGs/nWJj38p3vnymrptB+FmdVB9euXH24pVVYVfXVLfsh1yTTLMdyVCkGVOtQ9bzl0vU1E2mJgTS8D32FR/j81/l7fjpIw75anlVZyzfu/PxrasP7MT0K2ag9PKZ474kKHJkETIiRsQKe9iwRowVa9kasRMz0RmdeeulV79wYjZtRAa0VxC9cuaklco7u+T1DPsiJJunun0XmxGrDU69cnRtfcU55Sz9TkRGeLpdXzh/y1hW51r4gap6E0n6ioMq4KDennxzsfNwTHDhn+pZiP/pnZRrp2oUvd0cag7EN8rKTtN8461XTh45OAo/RN/70S8Q0K5GZsrxAlfkEDGcps2OAVOZhC/rgXouTDO8IeqMxAKFcD25sYizinhMI/woHEhns/rC2RvG8IAXq91LZ44dPLwBJUklyWwMBZzwfNlwZaQyUlmpjEwqu/LOd94e22DFwvW0+co3Xz1x6ig5U5lJJZWVynJlgzGZZJdGYp0FiYh54+1T3HO3AGxlb1//+P6dR2Ip+AAUZuTtRr3TCbMN4oSDKNBDNbiPJLiqksZ+5FRklQpwfZ1cLFfx0pUjbKzv+85X3qybEfhZqc5dvn72wtVVEa1ranL4CWF8rkT3tlF3TGROgUd0YTpapaTUuq3ed8Z+fPAVe7KdRq3Kwak6Zty+/qCptT/W1TW6cWD1xIuHXaOxPShG6WwiAgUgsVJVZqI1vf6F0y+/eWy207AMyw3qsLpW/ebvvElOKjsxxvsvK8GGKsPWRM/oQQhK6+v7Tr18pGmKl/UgZIzcvvVx3dRgKCng4hFwqs5fOQolOERh1WfhAKIokIWDhHT1a9sQqPnCDA6adSp0D9+Grd1u3Dfefv3kC4dmzSj7+f6P3gsW09TwvrKOjjKYeASKTrUb8UAVfTEkg4k6pdMsBB33WR32k9/pJ2wohdBdA3TD+UOscIBz2phKbl69d//OZlWZoWUddPLlI6zS8pJAda1h01oPV1Yqw1Ulk9/89hvMcwc5Cs92mre+/uKJk0eo5spMbACw5BOtsBUxXpA0YuDo6PGD6xur2oDLSmpmbpw7/8sbLPCfMdqQ03BkFKSETItPM1Zac8kG1LUZzDgiM+8AZobP84oJ2XgjZC0bccQb62vf+doX5sHPpevnLlwN7Me5wKDVtfS8sO/oxRLTYuoynqJ9oYSiVNJaEKCsPINaa/KXT2eiVsugvQQSaJAnQGi87ECi21s7F8/dMFbQK3J1jb721sl966uk7KMuf4I95MTzXVmprK3Q8OtvnXrpjaNz4CeB0L616uu/c4bh2bc3xMr412RrjTFsLAdfScqvv33SrvSIGqiqzN3bj25eu28su0j10rWsULRWk3qhqJjJ2rkeYz1wO7s3naxU7h4SLT5qNGSEq2rHuW9+6cwC+PnxexpjPYT4LpAwBJYWo6DRzkZuJxbyHA4UDEvGCFDWgJhokLZwlRxZOCQxdEcKwVwgQ3AgvX7l3uB7drU7dHT95ItHtKGAEC13tjZhj7HWVEL2rd94qRvQjYHQzL3+pRMHDm6wmtaGWkJdmQhIBFlbX331jeNNHTp4suQajDF3bj7c2t6BUPDO0WcF4ZSgrOCcAKO7PZ6R2pGQT4uSwJHh+yJ8AjUl6KyBsWQNG+uYNzbWvvMbb43Cz6Q6d/n6uQtXV424OjgvuDDkBdpQpFzhjHXb1QcK5vPbnMVpOcWW4abCYc+VGZlPcScRiLQNxMJteB7t1ElFN6/e23y4baz0B/fbSl57+yQpB9YsxkiVgMdDkZWKGjl64tCLZ47MZgvgJ2VL1jdW3vjySTRcmSrYkJm0vowriZrkyRePHD664WrXSiHZ7u7LF26R/1BByg1RlvqJTgGEiHLtg+Ms31KI7W0T4zaB6vuzjLA1ZA0ZA3/DWq7sjtN3vvTGySPj8EP0/R+9p4ksuybKS0qNBscb6HPencxFA2FX7KF2/iPnsJS5sK6hFF/aYky3YUPJvynS7GFZSE8RgdSxoYcPHl+9eKfqB/NM6nD01MHJpPK9Pr7B3mbc2YitTIVGvvpbL69tTOCW68Vmdqpf+a1X1jfWGMZTqCAqthG+7yGUYycPWSt9jDRWNh9tX754Wypx6rzzSgQoD6Xi6O6BQRXtnq9UvOGxx2dbY1kbfKuNrz801hewsrVsrRPZ2L/+e19fBD8Xr62IuECZA3GOwVcqA+pMPQF4yGiK4SXD7CfXgbSM3tEzKUWamJ/PLE4JlSQCRc/l0Cgan9zwesn596+hpwV5SfrY6YNHjh+EY2sS+6li9G4D/Jw89MbXTk6nS8GP/+DNzB0+tvbW105pzUGS5srKxHJlpLJsjVTCdqWavPrmcefQ0Q+hqCp75eLtR4822fsvwCvsqXwlaaqpmRGFOkfExRpTZK1GhcbjSzgi9njgIWvJGrYefuayH6Lv//h9rWtyQfX20iWcxuDLlxxTIR621bXIDIXmmEtPWuzrQFBkuYtuVJ/oOwoxOpFDzXWgNOhRG6n42qW7W5uzfsOhl6Rf/cJxchzCJY4ex6vPpoIzX/mtl1bWqlH4wTAI1bV+6VsvrW/sEwQm5GmQDQJBBcdHjx88fvpAU7veTD4mpksXbqtqkSfOsZnTJaeahvRydzZaUXbO0W58K6VImnRCvmXdBBtia2lZ+Llx7sLVFSOap9zz+g249izls2U6onPHkTEPB2VZx54AOgA6hB4aUR5IECGG7pFB+ySGN3VPpdV5j+bgWPD48ZN7tx/aSjC0a/DES4cC/HAV6HNgP5YaeeHEgTNfPT4bgR9mEsM0QtIPH1t786un3IwrM0mMykpl2VpjycmxUwdX9lXQfCFWK0DfuvmADVL8BYqqDreqTtqkFKbxZvsHUis1qDObwIvLEor6jSBZT4QfWCtVtaP6zcXw857WPovSUONyFwbXxu3xHLYDnor+VO40+PTNZSAQk2HPFYdYtRlT6hiaUu7FvBm1DNrzzaAlKhwY0+n0/AfXjenN+RSua3f01IH9B9fJiTGmxR6prJmQM1/81osra3YQflh4uuU+vj2VaoDEMHNduy++c2p9Yx9DAgglXZutkerF144MTTuDndhb1x/cufXAWAn1V/E6CReMd99h8Fe68tJGLxoYDSTt/GBfqhGK58VQiNhNcmRsrWNZ31j/zmL4ubZiRWvvuWLOy8Xq1Rh5xVGm+QCrbqc38QhfpuFIvpcLGw6+tAAq6kBUxHMvzrbH1ykaJaeqThtj+eKHN3a26n4cro2uH1o99eoROI8TVQrEyMkLJ/a//tWjs6nrww+UqolcP7v53vfuigwzIVfroWP73vzqCdRSef8YXSSrOXBo7dSrh+radQRoEBnD5395MwjQQf7xFwaK04IWoYttQGWFFhUTaNpmsRC6Gw9ChqwNDNpaqeyO6jtfemOR9vO+NnVI0PrEbRMzbs618JNnT4sq1DLnRflAgTx477kzEPmFPyNJ0+54l362NTUXKWmRmVfXBr1wSo1q42OxRx9vWTt4qvHyWy9UMgncmSvLlQ++XnzzhdUR9sOGp1vN1fce3b+6defik2pFoAOHWR1efutIZSfJLg1X1lTk5PQrh9f2T7RR7vZAUtPorZsPSLx+6Bw5UOHFso9fLGJG2mrI7YI7xMwoUt+bxOArRV7GkBVvPT74Wgw/V26cu3htxRhtau+5KOVuG1c2YGQLFBIE5mmvHIRogC+PKdGluURyHHlinw9p3PQSHRdSFBZACNGRIbBO5+BIsPVk59KHN21/7oJw0+jRF/ev7V9lmIQQomZ9Y9+Zrx9tatc/glCqVvjq+48f35sZK+d/+PHAsnTvxWbu2Msbp18/rLNWEzJSGbKnXjs0WC1eVfb+3Uc3rt83FTtNmBrrLeIBUT8sN1NX8kFX1Eeg4LlC8IVIgMgKmTbyImMlaD+vn3zh4Dj8oA2+Gq/9OHJOY+Yr0jbNGrnQHZ9AnQwGSgJU+DIecWHDzksJedUYhjgQBU0I5O2mbdIIphP1aHXqyOD82etNo/1ZAGiwb6M6fGydnAQ2bStt5LWvvHDo+Krr52KJ2PBsy11892MxZCZ859LW7UvbwyAEYuG3vnUsqEFsLVuB7FtbOXxirQjg48VtK7n40e3tJzvEFHFUfUYA5LRghGEhKrLF8u1grNTrGS/f0OYcU6QBfsRG6mPJWq7McvBz89zFaytGtI6ic0f4SfioYb0GyvlivSqfYu9AMUKnm8RI5RyLU6cpX9jhQEViNVlbWxXUCkI+vdoYyzev3r1761E/sQrAVnL6jUMSsleWYfatrbzxjReaWofhZ8JX33/86O5UqqAHf/TD+9AhEBKup+7Ea+unXj+otVhTWVNRY144uf/g0ZWOdXJUp86fu0GGorIVuTOlloGIxCEtiHzmXrZMvt08l9oLY/DF5Du/gucy8AhkrHjt58vzM1/4/rsftNJzDN3VNZQl68rGnawrv1OzQaPZrg77ybTSVgeirgBdVrK2ARdlOlAsDAqhbBDWnG/xSTn5pEerOhJsbe3cuf5gMLHaNHr8tY2VfRWBRYyb0stfPnTg2GQQfvyCiavnPlZuGm1qV5Nt7lx9/Pj+zFQyPJ6T+Y13jkjsaCbIqTP7jR2I/43lJ5uzu3ceiqHYSRUrfdByCiW/vg3aGXJDWSxGcco4SZv/apveGUH4ETKWvf/y8LN//Ttf/8Ji+JEUfLlQOJuqaRTZ8szcmXIx6adDlgumTMPsp4WoUB6v6CxuDW5r0Hl1RWqCa8u+fUVMKm8NP5uUZwXrpY9uDSxKZdIGawertYOVr9OarJnXv3GoqTEEP6hW7K2Lj29deUjW1c2s0dqR29menn/3rrUD88JYqJ7q8Vf3HX91Xz1VbyUHj6+o6/WcKCprrl+5++RJrIAOhYZtoXIIbBgxj9GZsdRqP+1MSQnN7cgGOsDXz1lD1sJ6JdpKVQXp+cgi+KlrUh+0N3ANNS4Utfngi1Ldj7Y9dmndTs6OweXcVB7PwBf3cyznGHVemkVeWTu+lsiU4KdvPU7RpGLuxjlj+er5W48+3rb9xKpisirHXl1Xh6bWl758YP/RMfghAs7+4GbdzBrUjc4azBo3o8qd/8Wdj+9szwGhM+8cYcNNoxtHJodOrjYNBggZ8NG5G547uyRrxW+v/YQKMWQtgnFgbEfNhqTBVpKH7jDGz23x0Tvbyk9v0eXhJ7GfmHWPm1YU3eqRvD0590JztJ+RRFjp1KTnvPKxH63kEzdV+/aAwuA05VMjUUhNd1ks5i2pYUOPHm7eunbfVoOJVTrx+roYZuFTb27ADTQ5evi5ceHh1fP3uNLazWr131OVenNz69yPbg3q3SzUzHDk9Or+F1ZmO+74a2uTVUG/Mt/I9pPZ9Sv3jGWnjRaRQVzmVspigQVkI6RiwJUlxfxGH5YIQkJW2FoYw1n+K7Cf+Yn3nP141adx5FSdxr5B+GkheeEz0miNdkgZFyIQDZRwDBTVl5KjdKP0JPGg8GsFRCX3lgF4KBfQUBucQVFWGAQ/WtnduHJPhAYSq7UePr2670B15PS+F15eq2dD43OZCPTeX12r3azBrNFkQHXd1DLRX/7sxsd3ts1QASSAakVe/doBZj75xoa6IQHayr07jx9vbpOhVNuc8+j+WG2Na9qooEGE2K2MsEqcQ+QVuvJNlr4I2o966flr8+Hn1rmL11eEtWliK0jW85VqjLOhNtnc5xJ7qBSBihlB4/CT3e8HmCl1OsJijr3HgQp8Sow7ZMfC6/iKek3lV85L0qGHqhFDF8/dCOOnBtDFHDqx8tpvHhRhGmjkwGTFXr/w4PJHdxL8eDPyluSo2Xyy/f4Pr1WDIMTUzHD6rf3HX1tbO2Cd6/ovgIzh8x/enM1mIPiWnVj6o2kboIYP7uf6pBqgNFgvLkz1Talpkiy3a7FC3tQaX/0Da8lYDtLzmQXaz7vva1OT07wxSLVNXLREP1WSoDP9qaQ+4zpht0p6QAdCLOweD+BznTpOtsvACbkLiyptgT3qYlrDqRPf63P9Qb88iIXrqb79naPHXl2vh3IXxATFz/7N5cbNGtQBe9y0dtNap7Wb1m4mlZ772fX7tzfHQMhW/Jt/+4StDIY6y3a260vnb4svYKVEn1O5XKmTpUVxWeFYS4OS1OsLx/xUb065C6/6GISOI6OyDPzcPHfp+ooR9S07TZJ/lBoXIVJD8URIsXAxNqpvGTTnnjKk73k0KbsscvV5KHXaWlLWbdve0KhMR+lW/aFvysSqm9X1xXM3B1PoANb2VyLD4/ZsZT6+t3X98l1q2c+0xqzGbKb+59Rxs/n4yZWP7g2CkIeZtf1Vv18WQFWZWzce3bv7SGIFdGqzUHLKCnZoa6MQNy0gLdbN9i5m0jMLOOZNTbIeIWNgLAfxcDnpucN+nCN16mLHe2i1oiyt0kmYcunI+mE8DfGewSmt3F26G8VuxLVgSDE0KGt9DTPPUM5CU4IowbD6KhGwUxhVVUmtl00ocmVz+/qD4QiLqJjE0CMo7/3wytb2tllBo7MmUit/YfkeHSLiyrz34ytv/cbp4TKPsT8BEsN3bn48q2teyfqT0nUdu0ezve4tAuXDEpTzcQKpw8sL0Kkx3/fmBy1RmdfX982Bn32T6oPLN89eur4iojuztuInIVB+LVN0W6mFJVu1l8/gKCqqsjXEvZGyQ8MzKeNAnci81AyHdaCiIRpZ0Vnc3RQ4UFjr1ARtWhup6Oa1u/fvbtqRXp/BN2wqc//25tmfXpFKG89+3CyLwjwfqmudkXG3bz748Oc3VlZs30/NGYTkGj3/y1skcDEP43L5Jxz7UB/ajvXktsQ5MyOGeHLNxGFpJphJDBmDyJ19CYdUdqfRd774+i6kZz8voWm07fkCXFl0Q5yF8dzruCjryEYlH5rT2SNl+fNgl2qmGSZri8uXs3qGzKkFqS0lNNoiIYdG1RHr1pPtSx/eslaWXBIAoKrk53996fHmE+VmptNa61qnyYUlHt1gVmtN1v3sBxe2t2oxy5XAgmxl7t3ZvHn9vlgKIhDFNoy83CCt5aZsTVBRKo+MobYL59LgVYT8l0mpDEeyvrG2KPN16+yla6uB/cTijbzTVDW7nvPBMeW8hM7alM5jyrr6cp1NL5gvS1qzXouinSnLmwJlX3XMhSViFGplXMIhP/0kVtI0Dq5B47RRcjcu3112w4Q/u7c3P/jJZZnAS89BP8wi+QazWmeN1rWbkdHbNx+c+9n1yRgI9f2jkduhgweOmlhOHKl0kH+0nWmcAtIs/uofZHAefzEzUxwCEMbaWLvTuHe+9PrJo4dm9Tj8/CSxnyafyhB/RoqvKDa5t/XOvShsxCb66dW4HGAAqyx6G2uzkWttH1Nvqa1Q2p6a6BGI2YW9nOSnFIZ4HnBOXSONRaNoGm0qa29cu7v5aGd1X6WLTrBPtf78Bxcfb27KqtY6a9Rr0HUkJcQsqs7EyfbiRGz10x9ceOtrp43hhZbqndPli3ccOYqZYE1VET4VE/Yik2aDxlCMfkZeJpFMxxc/I+ZQObUtGyERR9jY2Ped33i7rgdqdrNhq9dWRXRnx4ezEX7yjovceeWzDbvnNNtx0JvTXqz67kyaHyiXkTK73isAysKuhEagbMYLFfG8FhNbgwjkUpOGeibUOK3J4MH9R9d8r898Awrw8/j9n1ySCWZNkA1nXjxEVBF12mhdh9i+rnVGVm/dvnf2Z1eryWIQslYeP965fPGWWPKZNU9QcwKkrJT1nmpWv0FtNiPbMtVuAqS4T0aKVDyLGLMza775pTMnjx6eBz/vni17vlwLPM7lPdRZNxFaD9XpeyfKd4p0ixKHQ/c+bgUXpp2KxILNI1aUtEmMIpmqiAnUtsZKs4kLKafhN6Q2ThuHpkHjtHaof/n+VSwiQX6q6y9+dOnR48fKTcSemdM6SIjwN+oWmTBrUNduRuJ++sMLs0XNQKqoKnPl0t2PH26SURfzd+kCCMU1XqEr9vKBmLRc8oFQediuDwjLzX0y1XBsAWMSdsDG+r7vfONLdV3P0X7OXry6KhzLDvOaeVeOnc+OJtIAfC4aCKlffVmE9UUbQNndzCNhPLL9OMNBCvLJ05yn5frBjQIMZiXHYCZ1qoaj9Ujj0DjUjautMVcv3dranAWEGDnFYnj7Sf3R2atk3aypPfupUTeYOW0cuTTjT8j3fjMz+8GdYsydOw+uX7n/2hvHpvM76pkunr9Va82epcHPhcuS8HnQEFdno5zZ68c5FwOgY+FEqEJMu2L86D1rHk9nf/Odr546evjJ1s7AuKMw7+d9rRsiUB3mJSCOrkqpSGoj92xiZhJhuDxFnQHQIOIF4XonfkVnCjtlXRZUVPy0bitfX4KiybAdna9hhInGbnmN3DkMfHHaOA1GAG4ePnp49/bHthqNxVSxsmrf/8mlGzfuwLpapz5Wd5g1WjeoPRMKt7VuqA5UGrV3cDv1zl//5Vlg3mJkEZ5uNzdu3oNxDerovPJ5Ft5cVOMirGJ+ZLmplcroLMU+oQE+bSsTns6aFw4f+MNvf306q8cHbtw4e+HKqrDWM7TjMmPo7rKkds5+xgRD6q0AGxade88qv9tFh93JEf0+Q4WW8xLbRFiaNNE2JSJqboq8kSo6L4em0dqhaVA7arZ2tj784HK/16et7TK8/WT2w798n4ybNdNaZ4n0ROtpWutJP+Hd2bR2U5ngow+vXvzo1sqqHWTrACYTc+PG/Zu37pLR+MqNa4NHF2P4fJ9aOe65TX5Rd/wqsSaPRu0GPBCpc3/073z76JGDTeMGs8YK+t4Pf6F1HPaTKGVsfolNF0pZd0jRCTEcc9EYpxmO1EZrg/w4VAxADnVyq+jUsKZuniLaj8gU+VM2O9HBOdTOW5Kra53N3BTGfXj24taTmRmSjD38/Pzd89dv3IJ1tZvG0D2ijtYukB4/CjD9jDRIZw2mU53+m794v6ucZzGlCH9w9vJWve3I1Z6ihbMUkgXhXHF5BLhsYSZu9Whuc/Kds4ZY41rPZi+eOvq1L72xvT3tOy9VrK5Mzl28fvb85VVhrZs4bixIz7GMT7OAptQRaIgRdxMaAzYx8MT+Y+KL9BbOofDiaVgwmNMKN/YxfCzyTyOZwhUJJg7swE+RZhZFozAOzmndsBEYVmN0ZogePno03anXN/aF/Ri59Gz4yeb0r/7y5zDNrHE1phF+Zg4+j1HHridmUrAJQ0DjiiYQk+NJtfLhR5d+ee76m2+dnk2bwbXADx4+blAD5DSZYxM5KoDMetJI07x4wxsFlaORmdtdW22kFhhbXTfHjx6ZTKqtrW3pdbUxE4Dv/dVPdTpjI1o3VLs4tCVNXNQUwISi+YK3cI/olDJ84dZbejveMD5AkAfnRPutTsWDi5U4nK+wE1/tn86KgoRArCBSMJFjiDIrGoU4GEHdqBE24kRJVdZsZYDBvIu4pn785HGDmWqT6n4aLVxM5E8iUPFWqFH7AvtR1vVMf/bzX779xRfHcEgspjqtwHXyX+T8uUqzODSUsQbJB1n7TrIev24awuVeLW8+4EyyDYg2wvxWVyZnL1z54MNLqyJuNqO69gQotC230zm16GdkjrPruEilgkfWEPS2XAC9sz5vE4ZN27FLc9VCI4zxBQ8YoqajGDNxUGIBlEGkpMziHISpYTXMDasISw0h5RWhBx/fu3791he+8MrOjuYzLhW6WpnLl+4+3HwAaSsPA32mIGeHq88fORWEzSa+0CtoMnBMwldv3JzNHDPnNgSEbcBXb96EcbVTb0C+xTwVGLs2mKB2O3ELOUiD6DEw2J/bJ6UQxDkrcuPG7dls1nlLqbLlX//5uzqbkjVU13CN/27TFxpzS23NKrdboUohuLP6MwMkngsw81ZfZFEYOixnpH6+T4y6JYvIRlUkhqTQVOdd+8LWWuvGzXw0vjV78i/+xff86iVVjZegijAT/4t/+adPpk9qnc10OtNpgzoghPrxSWkSswvT2OO3Q11j1mBWY1rrDll3+dq1n/3io40N65yLMwrhnNu/YX/63i8vXr/GRmeJY6GdaxqzFknuLRoI26TYQM0WtIXqNmHoSzcrI9cu3/jpT8/t39iXv6WmcQf27/vhTz744Oz5VSM6m0Xq04TQ0LWp6rbsMA/BhjMVOT0afgxjSZbdfpv1lePzM9W5mYKHhKHWyNHCVtZI1O7h5k43JBHBVtWNm7fu3Xv4rW9+1VZGFcyyumqtNX//H/7TH//kZ3bVzJppy50RuIAvNmozvpk/4LYWp60PdKoXr1z7whuvnzh2AGQAssaur9nL1+78L//kj5/MtpXcDLMoswQXGTYDsLrWbkIeIwg8FBbDdCpnQKH/y48S9LozxRWqLEGkvnj5+hfeeu3YsSNpJP7a2uqVa7f+4T/+57PtHVFtl6TUST/UfG9cZ+JPdyF8znmHh2ZyT2rmJb7Dg83GyrGRagdwv+O3YEWgzkCUnAxwu2E73Jaw6ja3Sg9R1cRcuHj5l+cvHz50YN/aPueaCxev/IP//Z/+6Kc/rVZN3XjgCdGWP7WpTCdFsW1lYEomcAqqoVA2sjXd+asf/UyVN9b3WUMPHj76kx+8+z//kz9+vLXJBjPMnIZEZUAgDlJWSBiLXzHjc2+xO4TbP5QNHYgrc/3WPJGwplzatioiEmN2dqY/+MHPlWhjY80Y/vjjzT//y3f/t//j/9ne3LKMBIX5uMyY1dWYIxjZdzJWiko8lGWP6lRHbh6O/zNbO77/yyN/nDibGVPu++ppZKG0KD40HKCQ7OE0OJytsDXt5MOJiaNYrammO/WkmhzYf4CZHj3arF2zum9Su0ahjhoNbqtxWZlsLN6MaiD5vT5+gngcppmmdrIRsQSeTuv9G+urq5PtndmjrScrKxUxGm0caZiug7pOme6YjQdDQyOYz2AIpVgzDVHgVpoMOQQbscc3wEvqXw7V0GytEm/P6o39G6trKzs79ZPNrdXViRCFkiQNVWOpggzOT8x0fuY8svEyHfcwXI45mGXASBppURWDWZscHdxNXkAP9/L13O+4yoajcDK6dq9La2mcsiF5Ts2ZSsC6tbO1NdsmUbFUu1nIe8Brj40izjIPpVMaEguxrL2Fn1wX9uzDn35RW5mZ1ps72w0aOzEuXuZBYwkDijOpzifhw892WyVKnOs2P4RaDgmTyMpLv10UDyKilUmlTT3dnpJzK5UhDaQuFRymfQkIhN53DOYCPpfzVqnAGBpRhob7v3bhy2xn2U9C5qIPDehk/rOSyMDmFck6kqdTIgbUN38A5LzdKJFQo3EIiDjHjcCK1n5hDyisZExTLH15WsyHtNn+tEMuDm8CQcAhZDJKYKioIetIRVVYGH5bqmGhhoAGkUq41JYXy4BcEzuWiFRDzBbkHHB/qyh1k2KUvDQzxzoibTuLlYgVZETVEYsRhlPXhJUSgXHnlW3qSFPDl9fVEU9XdqP3bubkkecXa84d6Y4hHaioACmqY8GdRyG6LcQtU1FjDFqCEPu9PEysBGZuUrhgCFCIKNQwG+Em7P5WySpYfI24A6CcSkTisg7KtgQwEZTj8t0gTxGUSRQqGiuQQ1GFb3rywYv6JBfylSdOi7HKms/fQI8elpPIGNwWUrQLo8NYQCZW8htcQ0ZISD3XlhYyY3d5GqjXVrNF4QchaOd2Yxz64XqnwHkoUYr5cXohEPV/01OiY9lQ5k4lGStzjjqcreUOb77Fg7AWXcDE5JQMyIkXGbnNoKk6ZeM3JvulzMkF+o2FACEsZ428EaqsSItCMi/L6s0C7Ev8GQIoG4Ew+QJl9vvFiTl0UsQCdMcppaSOVRFSp570qMePFnsSAHd2MXdOVKzn8nDKlJrVQcQkpH46vd8p7UIoTfkYXA1L1ZP15BWgvYETc2eP8vw0+4KRpeXe1AEhsUAs5O5Ms8ntxcFiKur+QczBpDgaAAl7TGqIrZICZIgcAQQhCImSMhxLcC6RM3Echz2UhiumynFmwBKzK44jFDFDIewvcx9oQAgtcoBTKBPFXQB+LFCYf9iSjWyvBeWvkA5yu36L4qLuoN17kVzTNQn4iR0a1Bfh1gSyoaboZCDb/yiDn148vEACRJur4yVbDobLOWwpVHfcGect33EHdquMISkh3DJCLq4IVSX201TgV1uSA3FQdVUpLAxkFY4HMeODKAOMWLLAFPEggrBfxRns1/spBUEAhhALQ9QbUC8ujZYRMguappO0c3VC4bOmVdiBOJf5AWb0am4ABLHWPw9KKqGuQYjUN5UxMZMWSap21Ed3z0Z+PJDT0CEEwaIy3uU6DsbRzCIN/uiNT836idJK1kgwOE+clEk5+CPJBU2DMIeKPmYwxBMmhqhIO21bix5KcIt6oYaLCzzwzc5pT2zcd64g+DlyKuDkedhvkpc27oj9bWE8L6Jo5DfCZnstUgqsdziRKVulBQSWGHfVI2TDiMEa8z9ZlVnSk7JKjHJtZHK3gS+jWMg+jCA8Cj9YtJ17OViymZ/uaM8o1ICitlqzwXooqRu3jg6I+5eVvbmEMili8dYDJvWDAn32jQdKUhDX1JZ7TLjIwqUIFQgSFFiZhEEgx6xMgtDhp/l8E187QCBlIDSRU8Q2SlkLUJGsQpnmKgkQ994+B6RUb0+kBA5xmSdt8dh0nERmSUg0PCcTQJFgxzIogkWPXB6TAgLRgOfijl8F4As6cpKUHsbhGi4ExkA/IiP2xFwYYAZUWEAk4ZyTtqIppx6ZzuKBTPyOwgI6I4NanEznR4JrYY0FC20iJfJoBlFJiVJKGX3sxpBqDxIUi344Q+MsZg2TyxhtepWJmBwNigJtfSqojdQRjzDzMHDM5zDYlZEsakYY+ssFFpUkbZTIB++R+b7MOYP9SHzymBTphK97YCViFkrSW174DWS9cO2wCX8OtM3iBAxM7cZCAf8CqWdky/dCsQrHwtM2lEPmg6M9tXoPUpqCkurFRQ6VczJbnmD2V1Ea/YIgVQeE9XE905CTbA0XvTgveTFexg54WXq0NCDlURhnm2WynupsRkis++GsvoOpa2HR68fQvvU3RFFT83ij7cg1v7umTd1yl1bEtqucq8ZDV5KwGDkyqR+iFNyEH7ZCzKxIOd0CRgJgDAkmacpYceg1mGuJB5n1oLDLrLkqWVJxNfZiJy7buNA7qdjN2cdCerRrTLJURMLZOciX6eXokhtc+5hEVsBFdgNUzB4Gka+fZxAzcyg+Ix94p+U2XIoolEho55RnEmxi+wh6QttOJ61P4hQqR6jzLCR4WI4Al20h6dQgZHCIzuyKIoBPVQBclAgiOxKMoSab4RQVaPBEdTSaOWY1tqUPuzcg7hhQRwwo3yPSMe0q1W2MwtLO64jBbV4qida/FNFqCKpYQkljljzhVKPFrUTflceZePjiKqrFAsRyCw0d7din60BEbaUld+PcrH4jsx7u1mTlA6a61s6ZGZWhUJv2SL6vdxI666LmsYq5dsK78VBLsHKLnBQXxJTLt8ydKwE5v83pcxSyswPG0a9loWekGjEdk09Kj5WE8R7uDFHnAnvC5cwdM0IGnK1mMlCVkLVRDUBLzzox2D/XtnkjeEzuVVT1b1Bp0ZwlJXLgwFh98UIoWqQ5zzeWxc/ingtDP4znVgdL6lgorUd2geRQRMlWohMSbg2vc9F1IJvzY8EtNciTl4WhoL/FuQ0Ji36aEsBKysrlHgDuOizKs2C9n0XXTpdN961nqFqPB6wEw62AHel5FCgYywPKHilRJ4xPbgQ8FJShuK1dYEA2EzPGzLFrQzPNpJN/aCcfcVcNz50rZ4Ed9wpJeEAf4yz4HXA0DKY5mMRleIXMkqgQoylr1U1hI8athzPA4q7pcPkuee455kWzlUb+hafiQKNhPHd5dH5BdmIEJOMoqAlaqptPMcu9CShBV/YnkPSkwmrbtFj3IHBnuET21DYgwgiV5EGj6ZCo/uCfBRcrU0++GjCjHj71rYd7aYYO6cEIFO0CbfC0sVgyoG66n4d4V942gl7SHpzF7ZFstMwareoV2icGg6k8kM2rSGIpWslvUKptnQaJtngSvTW4BXoNW1LiYRnY0LDzat0chj1Ry66GH9BzYRhIR2AUivhZxFVPY0AgzFERO/wwhmNMPc2Qu/drwaBDloCZOwJZCrv6QSpKGUT6Vs5di+n0NA2ufxq5aBnZdT8Xoro/M92cy9RGy8NC51oPe7r8Bp0ghscjKKbFhWP8XI0HMYzvQ04urxTqDhN3FIlC5+KsxCwllDmhUbbylQcYN/HAK1OuEXTCjXKuxAjY8IDpUDe4GWcTvfOE0sNixAPGHE5mK4yu9XCv+mE42poDObw3c+FnAFXc50BDsjfnngUF0oBbAAisSHs2xCjQKNFjbaOhkFvIykA500hSh0enipTLFWq8kBjk5j5kW53z2kmtc09l5qHT3NEeC4Enj5sKcQvDURgvnWB/TpiDZVxYPttsSAEqcqtcBtvouTNvQ1TE7fEV2kRVV8AHF63bXZeErucCDdLVInwbdlvdv8Cjxx8d9tM53x3T6wTzgwaa6xi91QhzaTX1LXpZq1r0m6eM7W1PdO7yjK6bGPdimQ2lzBL1xvBxVlBRQEIxw7g/lnpBjmfE3fB4CDzOjag/XqIv+aSVJfOskItQkQfyemNR2KBvG2U/T4E+/HT82w4kX7jPpju3ubwiUf4qt6RcyO61Z5f2MTheYXBUWnk8wfkcf+qlwUdeEQsT2IRCuRkiU+iCUPlz0HqYB94KUbc6jHumw8tR6U/2yw7PZ+hq7YOSZqx9575ZdETnBGOdX81lzZ0wftAyuPfeGFkH2hyMKfwPOrocty/R0w+X+DmPuPSDwDEtkXfDfp7CdLi8WHYJRRajKROUkXwHbErO23KdAUvK3pbG3FaXNfOA9aAXzfb1tNF6BQwx0c7TQYPpKp+f47nPHbQbHj2Xc0jY2J0LrYdp8Z/bmyfbjSXZEm8wFOhx3oFRZpowxA/HzmuJK61+AyZBF2O6MTnGbIXns5nBGxj0aDRqBqWiOJ97FyyqQ6V7oDL8gku8+PJ29vSR+tzAzI7AD41B0WA+a74LG3p8Px0Wav+GfD6W6mliLF3cMB739//J84k6D9vNQCp+nAONei5eYDfzcej5fPECEj0sSQMDpt4BpKGT2tZsDEARD/kjdNWB/qPnK4TLoBH3ScicXNiAOMQ9WGIesS5+dhzos/jVT2XQYFMao3sKMQBIw46MR1xblsMa5EDF3+LxCGtxgd6yrq33TB66yvMJNbzcOZ5v62O51YUAw/N7kj8J07NLy5ElsR0bNdhLws99WR4ykTJVubhcfACWQEOVW7uimYMwwMs8h+eATsrjUDdWXJoDjR4Q/lSwakkXNgRLXSqNeW1sCzjTGN8qW7EYo7rHHo8dD5Fo3qO20qsWGqnlWAqOBmyfPxMcqPMl5WDq5FuGBrwOdIRgyI2g83OofGlo9FGafZEWko15qnwgfP/VlnFV8RX7H566xRODTo2HWTP3oYjjnyib3foMmucy6M8qE7JLOK6M3paow3Mxo8Ol+zDDCwOrnpDwDIKHZfJi3BmZNd8dDjg5jNGRhS5rsRS5PDx+IhwIw1ynS31GZgYtdFidQHhgyUePRA+LQOMRE+ZUDWPQG3Xjr8HcKo+cTh4EIezNiGluJnVhbLnQ1/IngUBlwqpbH41CSZ6XzJqvHy6AEIzb2fNQMDC/eHjAiQyeUcbyJHrYlBdKESOWNCiefhpuThbrbphzF5aWvHf5XF7ySkqzEAjljYXGhOV40l5JNI2CBC/J0ZgG96+Mzkv9jHAgzO2AH4Wf+TI0Lff0ediEJXviehnupfPVvAtKsTiZ2qtwXRjc854uoT2Hn7v+wpJhPA+dsn7lxnKqzLL3twrSHN+CPR8MptHYeIGV8LiJzGE3C9P0S/No3psdPA84mjcfaJQ755EYzV1sNxfBOotiMJYOxAAJnhO/YIHeP3onjwVfC9xZ+56GqPReYsBe8M97hqNPx4dZDLsIjH0UjJNoXpDyxGDteikgDz9+d/26Cw/vAovhgiTl1hYHemAAoJY43cvG8Mvx6D1Yz3OwscWpDAwrcAPlHGN9/aMaOy9ZAtATjnjpI/L0h4yX/x0vxWl4+ShsEfDwJ2orS0Rhu2BPu42/MP/jYXf1uHjWpjAewC//QktGYcS7h6blGD9/ChGZXY7NYDQjtkBLXK6UZ4+neZdo1LMSzAuGlqAdzzYKW+ZQPGPy85SGBhobMDVkLsubzt7eCj+Dj7lrY+K5Lnsol8m7PfK8xwcuG8Z/im6MEwINrqp73n9+kRrMT3eO+nUdw49kGgv0eAmqM1zqyrsNx5fgzc8djp4Xid6TWezK/nbj5nbFmrtzXkoXtYw4NJqO2KUHXarAjcctaeG19akl6+2zgxDsLkx4KuzhbqnQwmcvPoXcKQ9alF7aU+5jeUFod2E8fR4NaA/OaPkMRvd1htp5F09a513DWH8uBy8KfoiW5N8D7RlPF8Z/Br5keRuZG8Njr1F3UaWGsYeWlpQ9cu+V59h78LMbtzXPQvgzxWaeHwJh7piaXZ+qRcoc8gmVvPiVmT8jR37ZlNlnQP57hgaE5Q5L77QtdkZjAWa/B35e5X0/17Sr9UT5zs5nXr63bGsz7x3GnoeJPzcEGibFyDnlstn4wlD2nLvfzRHh5R7Noz1lezCavTyOPzmD+EQs0w6VbdCIkPj0wiU/1TMXcIZdCUe8+AHzBr4sw9J5Vxb3bKyHP2lEsrvBFTyDKRDPEYRoAGB2ZVi8XDg9IBN+sv5od7jGzxuBnoOtfMIHkQcZz1BekXdJQnih53qeprOUofBud1Z+BnWgz6phzbebOUkM2lUp4PNRa5Z6VaZPOwS1n4kT/EmiFA0J0HMKtXhJu6Fn1rlGI+1ET+HGfo1An4y5DWYvnltiYd7SjDmDXT5bqqN8ojDwOTKj3buT3dDz+ei4W+v5NL+Efv31mSZw/Bm/FuXTOzS/IpC1C/47ONmOl4Smz+iXfApHdrcCG/9KmNE8hv45Tqb+/zu306xTrgXKAAAAAElFTkSuQmCC")
ICON512 = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAIAAAB7GkOtAAEAAElEQVR42uz915JkWZYliO197lVjzjkLD+IRHhFJImlVZfHqrukemW6ZHgwwIw0RDHrmAT1fABH8An4CTyPAA54ACCDSAhk8dBc6q6VRldlZWZUkIjI4ce4eTo2o3rPwcNg+557LVK+am7mrlZenh5makks2WXvttfhfXPs/0urr0H9hzp8NemD0c2D4s6Hfy8H/CPnHI/8MyQOQfbOIfgsNn0i+BSQPjp8c4jeR/RVE3wNaHukfHt4M4neT/XX3mMxLiH8j+5wQby88OHrmcGBqD0DuqcKLYe7fynyEpneI6DC2vlb2gOQOZsOJED9B/UpAfPXlL4P69Za/OJG/knPXW+5+bL4X4udQq9i5+nrRMyL2/RUXzdM4kEdkP3/roL/Uof7i8M9VAlh9vfg90P6+Fnr3QEv/YFj4wdjH33qZMsRBeSerBLD6evEiPsa78TD0EZjrrWD4u8FiT3UAW4GDmjbm+5T7nOtXCWD19fIW+Ni3V923enx5HwQLP2A/WwEckiN8SNPWKgGsvg7jDYMxnq15AjzSW92fJmXurmJJD9jn18WLf7WvEsDqa5US+v4U+/ke5gN8Fg/ohy4Cztd27FukfGnHx6sEsPpaFU1LeWEc/M9z4M8uxn6SQ5I49+9trhLA6mv1NWdcXkbrgcN/WJ5XdMTh/oB4Lm9tlQBWXwc8vOBA3J4vSgxdEtKCl/XqPOxfqwSw+lrdcfNUX4PyEp77J1x9Lff6O6yncZUAVl8H587CIbzzlxgP9g3T2M+2YB92CPZxAIDndxmO89KrBLD6WjXci5b/B7BHwaE6PTiE1xleiNthlQBWX4eo/Mf+vDAOz+HDqIfiEIbFg1Jy43kem/mfeZUAVl+rLuEFD2qH9IMsb0kYh/5QY6wjt0oAq6+XOjQduvJ/9XVASv4XIxGvEsDq62CGXIx+e+Fw3ZrPI7gcfFwIh/OgD6kzsJ8nbZUAVl/7eUfgcN23L2Ksx8tz8LG0x+PgnphhT7NKAKuvVd9xqCP+vgny41AU+Evizr6owOAqAay+DmD5j+d+/z+nO79P2BnxMGL4R0TPX9zPRQ8c3FsAixQf+/C5Vglg9bU/dxwO19t9rm9wjuoTXVF3UDKYOyUs5ezgJbiPnpd04CoBrL7GvWGXh7vO+Vx4QQ5s/wd3/mhQAbqU/uBQX/FzqZMf0KOxSgCrr+cY/Q9WOb/vtL/FfQ4WITHOkQzm/uwY/VwcXnvfZRzxuVHXVQJYfT3H+IkRb+zDg/OMUVCOlgb28xgvu//o9b6ftyVA9pp/bhfvKgGsvpYNO+xH3fc8gafnUCAe8lH3/vUfL1uRNXjevEoAq6/ndd3iRfyAWDiXHdz0vOR3PvIR25+aYIFXGcShWtbNUq6C0+rrsCzJzlH+v/CZ5/lF9iVNeg83J+iQ0eNWHcDqa/nRH8/r1jpUceBQvyu8YEd4rGZqfzqvRV5llQBW0X+fov8BwUQw2hP0gX0w0l2Mfb8ksI+/+PzO8MtYLkQvt4KAVqF/PzIEDs0tsqSYgoMdFA5aMsABOGXP7YDv51tfdQCr6L/0uH3gJwxzrGFi31/6hb/YDujBwQG78sZ98lUHsAr9S3rCfYr+QyCVQRRwHKqzsEoDIyrlLesDL+NeWPDDrBLA6g58AeNc1/79oMWgEdH5Ff/o4KSBw3usxvw4qwTwktxRWM6rYh/e2RBKxlLpGz0zAZZ0zF+4ixbP9WofX+/5MLKsVglgVdEvJfofgM+AxSLCqpA/4MlgqdcaDsV10FXvdL/BVQJ4GUL/mEuOPaM/9ukSX7A8XIXyl7ydfdlVylcJYBX654j+z/+zdxU4Y0V5HPhbeHWRD3oevAyfvP8LrRLAC3xXPLfo/zw4kvu61nAA7/+DJHj54hXQB7FRGGXetUoAL+RVPnLNuySmy2IJavHrfzRW6DKOT4+ADoxxULG6rV7ir1UCWF2gzyf6D3yq/qaJS3fzHporxlPpHIXqDnqhuKtLldsZk4h5MA/jKgGsgn7jG1hqmBgPXMeLcY5lWzMSzwrom1BHbYhWFf3h+cCrBLC6cA/aO+vcoHyRIn4mUtfG3WhNEtnH9H0LnWTBLsTp4J+YEac+OOyXXDYBLPipeBXFD3JQPZgC5UPK/4Me/Xu8P/QLzUtcVUO3LGvg46PrdfFcRV6X/1IH6JJbNpOpPAAH/cVLITgIL31gvSlwQA/dPM3IXJ8U/ToDtBTgDY+RLULLiDjbQzQ+rCuxdT4b9XzAIekDXqjwVB7Iu2zxLz48b/VARH8cuCtzv9/XKHSr1rDeOFGcd9w97ntvekRfgGjxo3rAssKhzAdD3/SLOgN4eWleB9yUbsh4cxF/leceMDBEkG7o5xmRajsu/I3WVHcQWoFVtHkpEsAq7u/rxTtGFMGhO6S5+newhsySSaI9W0P0P0cY9n4wx2d5+ZbalvTFndS+VQJ4qcsPPJ838JwL+VE+JnqV/8/t4+0zpxNz/fyQB/dDeRmvOoBV3H++l2rP2wYH4D0dHE/gXkXxoCg8aIsY45yahYQ/xzgCc2T2Q9CqrhLAKvQ/t+iPpTwcB+zoLl7RLziVx/6frM50MmREPCAZLLMtWGRAhhcgMmCVAF7OiL/vb+yACjE2vC30jr4vgyfwHHX6MtYCVoD/Mr/cdGCVAFZxf7/C7PP/lJnishmj6Rnr8SKd284t4uWM8YcNwpeGBb2MX6sE8MJE/AOijnugmN/oKuTTf2O5xx8vwYU5t1Bap2TFy1ZILeksuuKfiUDl0KOzUn54uWv8A74708JT7BQ6zWcFDP50L50ncOc8eSRpv5EtSFcdwzwdwChH6iXMIjgwT4/n8B6ey0igqbRHd9WJ53oyX5wLvm2cMO+04IVklA4PoKOwL/g5QUAY+2isivp9eXsY+0fjfpqm8h8LcI8OcsdzuCwPQUsW7x/rDB2O/MHjvNEXYQawqsfGOFAHn/48Ly9lMBrxHAPrWEJAOKjncdHeahGnhAMaKOYO5WPkALUKi6u8sHD0P2jlfzdujxbY4PmLds+RBg7OeRklLuN5vOhzzQHL+kV+8TuA1ddz6aGxr3cZOuMF9gN1GPc4j+gHgEPVDYy1DzhOr4aBR/lg9QGrDmD1tZyqf8EMgSW9b8oV700F/IGEyecLf3PiPz0wk4OYBgY5kR3Ekp/35VfS3xr8FKsOYFX1H6DbCvmQ1REKB7FM9p3gk7JC0dHcZGyBF7CFoYGNwv7niRGUTfock+fQE/HwZ1ygD5jv91YdwEsS09G76u/5tFhuUYWO+Dgkkyz9cCOO8qi/7R741BDL3TFr4k6rr4F5YknXcGfWx/JunoVKdR79yTnzDZ7zM646gJehlj9EXDiMEPPwPD/AKId1LlY7+ieNISNvdCk+PT9pwed47ngIMrU/+D7PcxRXHcBhjPs4jNG/U1IYzXh1M5AN7NctX/umq6DRUv6jC/AZJzF0/XtxmxrsxyXyvFNIj6kL9qMPWHCzaUgPseoAXrBif/E7Ac/lA6Ab+t+f8n/g2LjvbgX6R1j0jEXzfqpBGQLZc9TwQCzdYQgH65bkkOJHfme82CeWOQBtDcgqAbxIQX/B39230I/+tf/S4kGv+huNDQd614ztPxrZB2ZQFT/4cMx7fp/7TTT4DfGB+RALvxNw28kpezz9Sv/tEHSvz/nZR4n+A98vBv9SZwTMhkG04iDz7Umg6Wmeq6Yr5kg/nQcTz+laXpCenNTNjZmee+fAwUV9JNs5WsaIf17uV+hYZZF9i8Y4IB+gX/RvRkGG3sZjSseDBuPg6GEkgP07Q/OfuDnZSHNrtx3c+7Bn5LUD4d6faY6innlJ3IbyAF14L1oWwcF50XGFdPsEkd7IwDzgD5ZyzDHoAAyQa8AIKnqLWErOBenMrw4ylJW/7/fXEm5M3i++/9jY1OGaAaxk357T8RkGUPSN/t3yDsPeIeYu/zt9wbBPB7tXWhm+/zX3ddPTRGF+aQfs5+U7RzDl3qNtHngODkYOWNFAV2mh1+8jijtjmTdhSPTHkqpnDP8IYyP2ozcu44rmY3Gp2NGlHeb4+O2YAnrjDuh4wv2qFhpxEe7/G6sEsPoaFKLbYy6GuHENiv7tIYV6s3paW4G+0qELtiad73MsNdCFks3woI99Pi6j9QF9Yuw+wc/7jXKvaKCrr17BsjP6zwMjjOZjNj9TFEur6oe/JYz3n3MeFoz66TDGgxd9S9zjs3KPNUUaQvjZh758pK9VB/Bi1epj/TrG0loZJfoPQhQG8DLn+868b3UZIW4paWCMtgALvyRGuyN61vhj3Yf9IaPRXnT+J1p1AC949B9K+wMWuOvHif6dQXgetn/Hk2LB4438P7D4QZsD/zk4rgDzDIcHU3d7z3Jf7Apu1QGsvtLrCUMeggWi/zDaDxa5L8aJ/v1+98Ca7i5oFTDy58KCP+/Wr+76XV783GApl2PnkzA9X3b7qgN4aXqB9vJ1Tkx4OL8b495fGO3OHvxwzPePJRH/G/B0DNyZQHM4WjBD9FwkmTei8oILwv0gfl7i9TTka7SOphy8v7D6OpAxf+4NT8yJHi1Yzfcp9wYD8vNKpPZPM8ge77lRG/T7JfRYvkVnfBzcMi3UKHRxJesP4JZLezQs6PmXX/uZJ0bvABZ5m6vksZyLDfOdOQwQqxnhchivUke/CNoS6PvROnsmxgX7n4XUoUe5y+YCcOZ2Xxl4ybCP65zGdwxUqB5rVLDwYw7UMGIfIaBVq7HfQb8xRmLMUzXHqZ+ffTOQSYMe0T9bXqN/wB+iD4qmpm0OXAjc4zF924VBMnnPK5TFOA9zSzM7oDc6rF/j9DsHdQawuAr2Sx30ad7tpX2QbmyL9Vg0+g/zWBz42dHvsDbC/XNE/FEv7zmkp+tSwpz7PV7kPQxrfVqQ+vpAFc8lvvPIc7FRI349AWDhT7tKGwch4i/6q+N7+/Xq0RfBlNtx815l9DDIAkPewTyfM34Ux3bnaLePn+/f3D+Uz91D1G62pkTSHeUwaHeMOX4tYH8Jo72nWLzvAhIuAcz9GjzOmzwA0RfP8V0vZn8F2q9fGvQC4+n792hn0B24e2EAfUgqaE0P6NWXdAU1psUcWeacy8wt/d+WL+c74csLwTFqBGD/I8eyK/qhL14+pw/voyjG+0AHMGfsv5MqlnrKOrqMwQYpi+Q/tIA/iwW9hh5iNJI5UjlPbr9axtoFW+gSaqKWLiyOgM4iYsy7hsWFI/JBlAx4X0sr7MerNH6k5zkDGFcU8IAAOXjBX3wekKPT86sHpt6faTkkXGJAqz6vNE+DFAQPQDJy0McAaejevr69k3mfX+ZBS98jDZnnpt/4ZDDe2GDeJ4py1NJuaiYG4QVaBFt5BTzn6I9h0E3zk6JP9Aftq78W+r7nLuWfgXF/0feV/ljaEnKPJrXTBb7zoWg8CC0TB+40GljgpLcHVWb4N4eDFlR45LzAq03g1Vev22ke4uhc0X/5lemA8h8DY2Lrnbuk1NMQ6GPEhtvPDuY5bD1TTq82rfW4obPeSNmxPRZ6e8X2sduCJWBZc/7YP2aVAF7yFmgeQLn23+jbEQx5rf2RZ+7nBtMOUDT/g3t3BotlBUSREnNnjj6xe2CGWM5J5NZXGGig24N7yj3KjzHhml7tIfcwp+8qFFYJ4OWM/nPeGj33iXvqUvRYi11UHKK9akTj63aW/+gVnrCsM4imwfE8r4J9uP4WZhx1DWl5QFZabNGax+sJGP5MLkJhX8CCcpUAXqoUMa7iIxYp9oZH/zneKhqBC2RfZY74iLYY1P10PYUt5FRwCNo+8JuL0XdGNY5cMO9w1wN5Af0sWgQd4sa5yCAbmjnTBVYJ4OWs+ue/tYa4PPZ98h6xY04ECQskv2HCQvIHreT9FkZQJ6cqQnO409Oy6d8L5QYM4dilbKWWy6QRiO9x6ocK8nC/DDyH8xw3NARzxG1uKat6/GKvz5C+rVUCeLGhHpprajoPvQbzv5nRon/zp8C85X9X48MtSWhYjpTJYd/YJ2Bk8lLf07RIedqGLi5X+5MXu8r6NwTzvRA3DrK7kozgCFHzNLzWASy8C7z6OlgRv2cJP1ro719dLjYexJAgssgiUb/f5XygRO/mI1mtaiO8Ln5tcOMHG2wYUHvmQT5CA/g/fWt8dF7D6Axgg2N0ayYAFkqTw98Y+oRn5BPA/semVQpZ3iFdJI5jbr9WzBE45v282fq6CRpBWwsyKEmIQ8pznsssMgPKdSg9cnlDtY4mhyx0HZY+nyP7om3SqdyOabSmjuUQ8dGeIHsqeLC8GtCdBrgT98xnswVHAOjKK88XAnqBdOj2O8SPi/ksZNXd45YZEP3RK6X1j/4LqXGg64rLbgw0mBCg6wT1VMrEkm6Focz6UVmP3dpwc64RYN6g0idJdu2UiTTAxPPyMKLkNOgjcef4+1DPAPYHKeWWtckDdjiw5OM4YvRveSgGRf+xTgp6VE/tL6x7ICvZgbC8r3sbJyIu8/soQ/Qo2BtvAoy+lNsVzXgBAGqMK78LwUfPHJN0A7zAm+bsdbnQ9b8aAve8SHDA39/CvzgPRW/c6N+NvQyp6DHCUUEu+mcq+hqCn3mTc3izIIsTDDhHAySYIuCl8a22D5a46drosbWA3vtV3AOh6oiafUJtSKGds9w+r5BJAwsMsTHCo7FKAC9t44NhTzY3fRvDn6V7oNf5ExpiEEbRfZmr76IHDCW/Ajn8Z+ANz+EZMNJ+L492fS3qvcXuQ3H+0NVVedBYqHNXkB74Aessm+bKHz3TAObDgHqq/PZMDuFhqwTwYkR8LOVZF3pMe/THXNF/KKA/1Nk4Zo5yR72KMU9JwyCxq1rugf8A7QV68/vp27UsOKjkvPl7Y9MDtEFC3Z+RBxQodW4+dz33oFZgue1s93tqM4RZcXQOSY0/jEk5GtMIcxvHd+p9dn02DNqGrX92dKQi7tcfDG5B+sd9jH0RtcFBDUOIoeck35fFM+QxTGC4T/PYY27H3PeeqD0TWnChPhI9PPfS18gIUblUqGGVRZaJ58zDZ8FoTz63w1fP6N8HLh5mEoAO8AeUW3lF5kl6a8NxU5XZGhSW1q6hVfWo53M2OEq2QkHj7Yv1BHgGguT9VraaNYgwnxoPc625QI9Dxos6CcYJYLlGuofT8evgRPnFn2botdKvrp9T5nkRN5JBNmy9oGl0X2S9jl4XFtQKNQilSYx3Y/cp/NtvuC5B6UY5/8bZcvuenuVJdrQI6PFCg5NBROrvjQ61twh945oiwtj7Dtyrp1nMEhKLvb/nFUNfkqyxRHO6HvdU3/A91Om3NSD39HdEQ1yGYL90zCfGwX+YRWDt2AzoAPepMzL2bSCGK8y3dJbzDKhHWReMkgG3PnXjMzT0BO1T3LnRO16EzTrvmgbT83IEewn3v16EvDZv6O9VF3cdlL5oD/qpKaD3BTWUvIROBMlJCrfYis1l4tjvpmkfoGJeAWvuwQEa2d8Qc3z84Xr+taDeGauZwEx6KPG0fWe6Y+Vsbp+iw8gCOvioEg7/wekon4fAQoOpkwtE/3GPSHb825P748O9GFlwa9bkbuChifOT+a3lYLRtp5j7nuompAs876LsIK2JFiFn7iIDjQrDZH4nysHcYSyKuQmt4TsvMw0UL88nmo8uOWRTrG/0H/5O0O+FhisQcQd8gh6JCs2Ve1oVLtQAUS8mOLdjQV0rYJ15t5vj2AT0IxeIxrsBuUf/mY2Bw97IwAnBfIhQDQ5qVGFdlC+2soRcRf8RQj/1H/kOF9zvjP4Y8PKNXKBsTERuPwD9GhORG3o4d7VaxKAjmrNIQljES4ebjnPv04/RLtl0CbefShLPt4om0nNumWzR7eLOx9YfwENMx3gOlaLwsFUCeJGjPxZ9/BCNzMF3d2con0PHrUVHQcK4bRNT9PqM6IaluE+qGCpslCA8bb/dnDw4G7sbwI+Bb7AzCnO3ZPYiBsoLOaXzoDsnE7kbLYl6vrR8XMdkmJGF+xqz8coS8mWP+xj4RL3Abozwnnt1A+jOGf2ifyu2jrb43psIxP1LQXS9qyxshVEwhxR/z6k3o57V0Ks6HdBDNO0811T1QW1kzUFdwiIycJTJpj3iLffoVpIni3JAvzlw2zWQt4RccXJe7GJ/jtBPw0UUun+CAe8EPX8XQ+MPZzIF2n6h/0YCaiUzmu/sgagat2e24WxRHkUvHI0hsb9tQkumZ07PBep7toMv2hbLrdob6P+s3CJLAbQ/kFv1jeZiiDI1gFnjW0Lu90LAKtwPhgvGjvtzvGe0AvU9eg101Yc9N7+614Mxt0lZU+HPGLbElnnOxbAQFpLm3W+mZVZsa0zMab2G5hOWTIkbXL2SZel6JOVerSni7V/0iVLoRFO4oyOMS/m+aSU64u0fj7s3mWtHf2UIcwgC/fDHzbenO0xvYA5Lk3mjfyc60ANU50bsCb3wqa6A0nx9orvRQb32HO4egk5cpat1GFrv+sBWe62GNNOmstcT6uiKaLX+A72fBd1VOTrwHLSkC/mTvr2FY/uYPqC3CB/aHhAbwuAQh9UDuxCAsZZe8NyOyRxPjoGhs9sYq4nqPseseC7j+X5oG1ON/s95aaDWrTGEMNF2JNF4HGTvTw0+FqB+MWcODBADTn3vu7C1VIm4MtzU63Fju4beJXyvNJB/HOrtoPwAmZFAA1WW3ZbAqApy5ZJCyKEqznEQnhP78qL7Vvv3Kpy7X2Vw3M7ejH1k4KhzSsE1K1zOQEboLbuMermW/61eWpUDRt7coU7UPQoeUqfPc8mxU0bi3GXBXRcHi7cnoasuJKoe1FvXwrh1A661Qve+YNxPsSFB89D9EtSvCVgWBLRSEt33+nyO6D9YY3LIttcci2PoSh4Y+PaQRX76l/+1dwK0Xp1Iw0c/1LuXEJCPOe1M0IUS/IBxNzO1WTEPeEfDACgWs8w+oS8T9ntMgPsoRfdyDRugy9Z3hN2m2NGN+XR3AC9HuFwox+BwH6p5hpwjLfo2RX8s/u6zBJlsnNG5mNNHmBqyiI4uIaaONbGcpxj3T431RqHO7bG5B32N1NHWbagulD+m0vRer8v87pyXei1xcj+OP0Dt4FCKp6G1IcgNeON/tQ6H8w/pHOe2UYMGsZbKwRwjfqHKdLwsbxzzjRP6Ez0x/zsZANqjL17UiMSA+mpooqm+T98DN90MjbmK+x66Lv2GphjW3w0YjTcxt3cEWMK12mRuyH1oL/DzD3QNQamVo5tNA+FpuQM0G7CaGzPEBkFJjTmAB60olwtHnuGODS84zHPQ8tQcLmBdvzKvGUDv4cEwgYom8/QcxXPoiBhp1EY2eKSuv43AADdhSj0X6zLzRzQU4G2aa90JMHBGh3eXmY2kpikCWkwFGM0Hrj3Ec3fZw5kj2nHdc+sjuOUaZTG7aNLM415qS9HzLZID9lkMrk+/MjgXrGYEc0M3i6SKdq7nQlpt6Ns3tM+KWzR/+oA/wDgnJkoJro7suRTQYMlbi0GgQYzyLFJRB3mwhKt5jhmVxbubqPXovCAlFxYND8sSe+qIXh9Ipzv2ZqDC4dFbKMF1Z62OJz1IM4DB5N9DNGnGPh9HLOX9zRf6h0b/5p0v9Iv+vJAhGfKITWvJ2fnESj5BvmloeR5wqkePziMAX+mnbUEWqWgicXaJXvR31O3XEM4ZEH1s7koG6B24syZf3MSCEumBQUykF/hI3HtIYlYENM0t/3cItYBGtrF/cUShMf9YbUhgxDyF/wKKku21f+9o04D+14j5tUkAz5cFgzJEkxB0fTG3DrlnpwUd/CpuxX/mhApan2eICLMktoPRhF4NhjSa3kddXacp/fQfGID6tALROD4iEXOCD2VuEh5yqhTXoETueRBfLDG4ORYIX5BPjLl+F4sc1p7Rv5M+1Pw8nVPfAU3JnKhOL6pl20Jv+4vCNQQwZb2IEpprVX17b5dkmg57mbShQWNPhhgtQWPOyVxdXIu1vcIueOw6rU61TBsCTt176nhL5lrsgoOIBph8cfwu26g+jfEd+yIGxy9G1DyknwwL3RyDAKLOl2qDffowiNA3x/QEm9AU/bkH+QfJfJQb3gV3ZS2x09vjrYJEGjD3cM6KJXOzS8mDPmx65DJK5iPwoOdZOEpzW7JGDUNLi5fWONvBJEobglaW/SC/sF4jlWYlUYn39Xk3SbbgltQai8HNFQxfXAG4g5cbMM7Bn2Ms3D64H8EgrH3hq8cHT674TDxEx35ABwumU+s5EahMZAnQXlDXX5sTDQnOgTkYcjUCndexqktudl4Mc4iD9n2TvUZJXEsGfdR1WjJ3JNTDDdOmnGp/5ik4vTLb1tYY7T1Ef3thVgTdN/r2EYNbzowVoz3Ti5UbliPPieHPhR6Y0VKjf0+ZuRQeR+9o1R29uNehSVjrgTrZO2Q2fBhuo+Bz5lyg8U1lIxz6XLHI4ye59YoaW7TBRaC1XeB5i51Bzo7c40bu3D9QmYDeQBKQSnB9yvncK1qIv/7rORAJnbKlsRjccwybA2P/AW47eucGLOXwjHXU0SOozxf6B0T//nIAna+LTD2LFuX1qCZrFG7rsuruRCUSQbcG4U8DCmnBJkE/kaGmhdtm+j9yARqtyMHwG4vnEKbjdA8DrSCLCBPcUkT0NefKtAahgcvU9V08USb4AD3UxNH8IvdQjRiYAw7HEBjP/QlGf2Xe70M12Dwgc6UtivhTD1vgHu+jWxwUA896DVvgHHWHo5s54eNzW7leMxoLcSSDv0dFPCPn4ViTYWiQUeJ26ZghxRNTlwVb11VSL47zs40muYYgpYmWN4mYu9WxKcU5AdcUU2qz/WqEd5q2l9n3ijnRiK4c0OdV+uSAIAXRIPSx+trvxMCjP2Of0I9WqKcvgDEcgxoS/dvxHB7wwdCObKUxrlEtp1au97L6Qo+3TTXwJBfCu6azwUsL7Umi2TisWzuzgXTU9HjOYUHI/5trC1NoqPrzgVK2BZ4Vm+gG9ZN9jqCb5tI+32W05ABqbanaP1oPY8jemb0cqUBepZAltzk8zy93VOVInxnz6Hxg+PRixOifhxV6iaHla/9ufCdf5Tc+cWoDAG7Z/2pZjM+NmhHXe5xEbfQIC+0fF9TNHxBOvY1OkEOiUhfRtDsZsjzQXiKoh0xQWxpoXQFrGAA35wzbByTHrvuodcvAmffT0QRgbCmIQzbaXdKrLhFp6j3NHRyO0dwI9HhPw1cJOle9ekd/ao/+KYDQwwCgySQg95G5/lt5FWidFIUtYJZ4ZmSK7EYhAWZGM5emYwxryu2wZsCY+1rmHjrP3CDukL05sw9UjavT2aYESQBtLFq4w8mLeyBC6O342Eja6RogMXfRp7M5IP+w5z4D2I/MsW9Jhkf9hIN+G/M+A+Z80bFA/8Y3wB1gRx5EQ29d6BqxJcsj4iHKmvUXTv0DWv0gUdsR9SMEGYSEzoDKVvl1YR9uvlj7tJaOkJomiZaw2xdYRv87Khec0Zwt0NLYstPw1qAMmxg93kn28sz6P7fIQbeoubUkEQEKtpOLeuSAw7sJjJ6XzXNvO1olgrGUzz+nNdgo1iIY8kmBvsUfuqI/NUT//PP0blzQVv6j3fIl9Q/I0IqY4+bd18htb5WJA47EUZBGa1MHplaPl35XJ7fdR+gvadl5rFsyVtZLixvSNzff78pdhmh8FjTU+I3BPc7R0RWQSRgkdIzmjQbMLaJF7aVMiecIxDw3VAcH5H0uwcYF8z5oQPQfQvPvFf25A1lCPlrlX74/2RA5GIdig+/ch+IMFacO+meWwrhJyJDF+0HD/etX3UxIY6TFv9/+1LlmSq45c9xVZM3iOTnIfRwV+l57rrFBTKyKeyVk7YnTjTn4Lis5IP14DLYVYCIK+1aZkS9npJ1JIkId6+JtUdjX6dy/AW6l+sQ7JbX7LN4Enk888uD4whzq1MXNxeOSwKJ5FxE6L5JBhT81jAvRAzUCuKX27/546HvpcD5dcRwoa3hs9ObZl3gR9Iy6kxXnC9UIF2o21UC97q3rWIQt1p4fepAiAigF+nvUrWi+uhrfbZ2s6dsxmU5U3NbEbuzIXa5+vYu5+ZKMIR5uDtY+R6fZIMeXqgk5ZEsMShWK2o+yuwyyD+uzCTwokmCeoLdQQOcR4i+3tqHPD8NaztMMV47rA5gMCP3cdpC7o38X8kNdj4/pnrL8Tz+EjyscIRuNN1oixMagFpP3WivA1C0kx41aOPWoYmbCw6sKdIn8CMENgLrdPHpOAlTSQg3wPM8WFBCxP0y1WUiFc/6jc41oFXAnTWieDYAWUASS6RAJ1NecS+s5oCfss7+bwEMDVs8lS+pLm+SBSYUXDJ2j62eMMjOYK7Fh0O4Y+n4W9EshfSuMZrnQNpcYFoxJEAsonnMoEsg8RoxAOVG7ZI7Bk3jGy/52rUfUBizdoyDp0czqU0Nw/80DFXLOZfHBSTg/yVwaDUEccSksi2qkqkwpbaZVkaKJAIqBly2LX2aPmsE9l1BWrctEc0TcjXfykiELU8ZcganbSIaHzYS5iVzVvw/guOk5bJvALQTjxspq/Fq76S5abppczKhpPnOYAZPe+n/PbceC5qjeONVszEb1BVv2QEwzFt+MkjHFYT25Krx9uGHLoOV6DM1E5l1E7y3XQ3jiOPdAZvwsEohiW1eV1fPq4x55Pzp33HQKBbwWDwZ6bMhG29bwmTj8KIgvmIvAK76RjvMR8skAtTzKAg1K629G/X1Lg5f0IGdEPTvsjwfP2HN5wn3ww5EAuPsBPCDo8KAI3Pib3DBGW96QuXcyWJ49ADpu92FP3kujNLe0hp7Rn93MrgdGBBE74nIp6Q+AOFLHOkmK5bWRToNZBCBu3gPw/QS4EUsx74VlMEZth1XVRSxqRuq1voc5pSFF8TyzJNbPc6bb2D1T/guYDy3tJ3Pj0/lTAUcAddATPEYEIhY9k9wX831bCrawk4KAx5ca1R36snKSve9+h4+5zbC+LSvM6QfQP44uN/Tz8gifPAwU4aX3BH2SAeY4Bsj1pTyw6h8e+qll0yr3322KNHVwnFtSBbsYF0VGmSTQcfiYZfTX5NRdfEyPjmO0emTXUjnhbIjw7YhAyAc0Ed85d5BQP62ssyo37VGbm8ay8wO+DWsKvZWcudHRGRlkjNNrhEXBhiRziFbAnCjFUWeQ0EkRr/wmgktIuKLsQcKMFCH6R+3WJqAjB4Q8kXQB5QIKBEvPHDxf6OeeT86DY1YXZMl9TJ+XghaNA/HznCcaw99Ye/TnzK/nxAnQ47TGBXi3xRcnyFH8PIgBWW2eU8kBY8AwENAGR0NhgGv8Iq5zRlmOEyDeBzyhpcl+IHdZWrSCOXdQEgBKoPmQ04K05M4BtBhSG2TfdlM28J85WfYoom/W5OQy7vBevg3+gKgwLhb1vuyu7KgfSecvs6/yV0Stpqr3Ady8e9HSBOS4nkOFReOvcq5be8HAjuHPxDUEru9L8/DKhZs2XLox0+jXl5QJsLDa84KeMH28udBDC6jFq6TBprAdbeMaKo0YLocAhVN1ZNR2dZMXYuZE6wXsXpJjvMLXASLu2CLTzpJzqtQOWYYbKkRvCEypVxfiIyaH0vLXOY7slE4CuBVl6pR26Pw35xNIKrXjUacQ6VGr2C2eHsD2aItKPEOYHeuM2Ac7XD5131HN6x/R8rA7bkzQsSisIgZp1Kr7diyIM1dynAMai39/+iLrmIY1udqGRDmmyj7GSRJN+AN3Eq0om+7nzlRoygpo2ONpqLzmD/UYJV/Mk9M7panm8wvLkmDQ7xlq0Z8hjnPmwkBufx+5MTXEtCBFlUPhb3mFTqJZlHMcCDsQQ0hb7EOnM1vfRzCIGCxG1HnHFWrYWaOE/BMfBq5NCPICdn1EhNJrPWql0OWVyLmrOkc9SowyQ2JoEs7TEZIG9x0WZpIS25P5l6MBsWCOCvo8omEPwdiziHQV0oD41KogXdXEiDhdTcieDtRRnd6YfsYdPlfcIqKBzm/0gMXCUWNs5n5VfM+HdUf2TDfd3lV11PjIHm+MfzDnr9wX+cWFQn9tHjvEJJLzNUENLOIadaMuqc8JDNw4eOAsSuEmvWwgmjiq2+LS/TpzTj7awEY6+lCc7Bn5YSM7mIPbPOgdB6k2tqWY8cmtF0B2P4+ldFKGTYKmmN6pT9Fwn7UsSXKyvhV6DDDYbBUYGq02bxYuDftBi3/bYp04qrjdiWDlH4OA9XOay8zembzolLJnLKruVS0/1T65z9lomu72Q3hytnKgtNsonxe+3xZEUK+ja0/P0T3KnU1B17e6JqVoaErEA7ihIZC+efszERgp9A9aG0aPaVL7EzbPYIFcZSxIfXX1tAw2ThkRCdRNwcJrMUnVBF+wi2dy1yYrFxh90Y0gRM9cw7dsXGKlKBJzlhoMHPArH8YkLYZVHNC9oTwTqEFEISY2MudV90kiWkxtw5eICI88yCMewZ1izpya6BDia0fbQwNZhIleMFT3mgoR78A+OdqAHqhDrvDXstvgEH60DrN8TiQifPlfa/iZiRnQsTZHjhvaHkr7ovx9VsPMW1akdb8ZwEgBqD/K37eiR1yJ56QNuX418/D8hC5eirhckHVk5RoiBNq3w45xskVn+zLHityA2j/5DteFP5mziTk+OymWiLiOoNzEGDXECaI5AHPS0zB7mMhNDpjjNkKgseywBk5c7X2CcSg4S4WcREUgVOVNsHuOfcLN3oeUbGlJ2Z6EWxNfBdzj1LNA+alh+6xlG1jJi06QqyBOk3li90hor1HH4acOnQuIEFPBpJGyPgFbzkdDFtH6yFNTByNZEVe1azOr+MTIOA1wssbR7WzJef2fLD33+ewB9GEZcnanLvopZ3/G9XHAIm0Jp1YUnM8EEpFohLhrDn/ztVtzLyRjrMePGPpb0QHUxffj6N+e1yWBnznWOEMtqYhNMSWr9ShpcIiPiG7ODIRLylIwxXhAwodBMcKNNkX5HxGWHPajcmFW+d3c+kFOWpYQdhsVjKLwH8cR5IN1NFXOrB42/Ba47adpNVUT8fHaDGgwOQs1u3I4j9mbQHDmtQg+wTwbQCoMh6Nxhx0JaAJI+cKfw1iYGZGKoAhfqrC/KFeUB6jnxEAQ93fdbHlOC0aVByP6d9X+nO8SZdfP+aiNOsDP3HPCgcyeXnSLoG8aSKcCtV6hvSxeNCeMaiDT1BnN1Uy0wD51KMdHfx09Mj9Bk+U/c/1Qg5GCP2wSdIj+lKpEuLofrMDkK/dwPLy6pA21hijEIE2sjEhPGBz7iMVODCfojDoCaIJKeYiDxAOY6rZVsfAFqA5QcjIhaEEBBahi34qmbEtBjW42uUBfS8FEwj4neaIa+iQrAZnU4FMFwtTXpE0HygMQMjsQBafFgqBDac+kiKBt1e9AfDkSUOxzQDj0Ka8nrsp9rd9h3dW+P9Yt9dPQW4QroVwMj+B9jv7Rj7iG++Qje9oFcJMgIifdLOeJiTL0INGP4hih7moF8rFv8bi+iGbRPoV+qlMkspOgXO2fuzAS6NYV9RxlFFE6MDPXRdSRbyzDpImddhAnRQdbBrcNAjY0++pEwckBOSTCwwjaFfXMxJr9AAA1ho9neojIHg0q6uI/qeqORLRQ0zXuGgUpIOAwDd7C6eoA8sxaRv4VHSU/OTdAgrQRdAyMeF6OdhcpouUsLwlnPnfIN+ZeFCx+L+SptUd7xI2tMiOBwr1JCFm3JOgrRRqRmAfQo2pvFnKgvlSfluagxELBGnNFf140+vcI/TJ886CBb/oraZ1YA3nspVBjdaGzFUCT0lY2J80t9T8ck1kk9A+I/tzXpzeD/HAS51AP2BJS5+wqSbRXnJT/cCwfijF6e2W5e50ZMJV42BFjYlb2MWkKAcSwF4qJFOJjgrDtlQyEYwQ5PCYt8IMaZtymQigaMVg6B9jTAc7dsvV5bK3rYo53oChbFWXbvGQYwPaA6JqTfdI6FL7Yd5eA+dxFoP0EAg9FahKmlQEIyo1VTOgvLM5jgof5T62RpAE7EnBx2Rn8CrMae9iR5gCxRhBywKCqv17cohlBR9vZZCa0WkKOK2zJPZ6YazFSfFBOWn7Oh36/8c3c2UMMAbi9dAsYORiHvS5LzaeDu3JA7r5obw7mVePGXKcX8zx/tuxrhn3aXiiu/bl+RaPucIiUJ1af3YStAHu7sKr/ugNM3XOxZ/37ObAlgytYUj+UDf2+BdGBOqLsk9tE4scTsVaEfdFIVhrskw4CtYwzxFC70RrIQIiCRVh8YyQ1O1pAGy9yhy7NEWS7imbfhGiHNk+yQAbLdT/X4cUguge4thARE9ROBbyAj9nvheDyB04niA2pn9NugJm04ZlyHFtlDkAG5FGGgcMhcQI1Olarb0yL3lHSz1K39fHSZwD9NYo4KQgFeSasNEYWDJxEf45sNRA3CtxY/zf3UxzprLtpUEJHT6QfozTQlgPQHYnb3tnQ+I95Zs19dkTQFvp5QPpp5tpyE+xTi/5SksHDunHm5FqXYM6JUqLNl3rRFriBWACApAKxrQg808yhQORhH+VFI3xdzmY2wdo82K/wKOVewPUKnGCZVrIgvgg5VqJOnCaRMbIS8EpDkd50hTZpMaEV/Uf+bAcoNH4PqD8bQPEg2v5b1V5cu+2xeDYADpHdpwrbDZDtBpjtd2yihWUBmWEvNNnhD0gpNrRR2QpIV3hv+54CONxmLdByO/dfC2CXyeq+8zI3MM83A+AlProW/SkWe+JQ+NTreq6VfuKG4OycsPONJpQAQR0EI1zAqOP99X13ZNbBuYmJMeRwcTNaM3idGH1PHdowJU4ndq1XN5qt4dujP4X5rcA8VN3Rhb2gV40rrJKOMiSJQC8WsTiSniQWmvM2rMNrwPkprp04GMFRgM0b1PD6cXKaLbaO03fCVFt6EPAXN/OppK5PLGYBg4PnIntTAmjo4TgBfmJGJ1hc7aCm69Ni+Qw0vg0bdeMOA0gIQBDrXQztwDUdjQdMVjB8Hm0fD3YIj4GGPFCjXJLwB0wp0pr9InicA8LAII3YydywBgQx1YT9huBCbSBe+o35OgDMFf17Q/9x9K/BPhyjOxw/MkoG+XkB9WcBxWhlLHoFjhh6taUaxN7RiGaVqbTfuKsBQJNzN7DwSY14j2jqBFD7diPi38j9z0b/+oyWo5Vdw+wT9T3HaHrgzyRXAiNuERCzxthT/hlhv5dFDc4uCLMvWSzrUPYK4WVVCdcYhMzhsl5UvHPUwTYAMMmOEuISKMJkIPAoyawHU9NAGA0VPVobheZyIR/fIUXcgFzPISp3fzPafWo/DXap1m2JmQ20MEQCAC2aA1MpazciRqj9yVtLmtCv7bRDuxJbuTvdq236btELi/r47kOCJQ51Gh0gqkIINY/fWHB0aMnYPgMYcQAwAPrn+POnSH5D9K+Ffhn3G5QkuH3YWYsOYRAI0ZI4Zar6fFhMBRDDQVzPAYvvCfe7AjKfGvOpA6ELBEpDRkZloPWlweg/rmdEp5slRdgEWK5NlVyMZo6XQkOZj+iB7rk5ZBkw+RLeFuz2XQMshwcOmGImRaKTKMDaRATI2pBtxrH1sAo7QdFJZLH4ypmc66/caGed66EZDcgPNwvwoT2y1wqBhoWv7NNm/B1qS99ChQ0qoYFK8MdJeGrHATXkKRfrAbC9QNzWrukJHPEfMp+a8a9y9H9wsifE5oyY+O5Le58fvCsZYiAoPw1uhskz+EGbyxiaf1ruV/Sf69drJJCEz+e50ZwhBNV2wDhPCsr5INVmvEGQN2SC7jTACUHIK4Blwv3wHLCIVNwgp7DO0N8j+g+BfTIhgLlP9E8WRCImTfgfydiQ4v5yXcBvbgnhSZMnlDAVYZcRGGCCpPObf9vvm8jDUIZoxMykSZPdC1NgbS8pZlH3iXkGC0Ug/yq+HUFNZyJafUdzUyb22rLATtNMmGuIf2azKZ8ngO4BQ/aycSCWhP4h3jjCTgDqyQCOgWODPsF1WQYUMhMbMBRYA5rCq/huwG5+meZBOxN5yezhhhyQA+GZqWoFgqgB+ZlTcj7PxSoxqnjDXIE+B/5Es3XmXASPC3+OCiMZ1ZnThNHwKWoC55J5EqB+lliDSAOW+NHcCuTHwmg5ovNuhXUFcYz2WwNsGmUT0GIQ5tZoxEQ22YlNQb/4O7YMj6YC4iLx6z2BzoEalwB+hkYxA8E91sQKE/vJSTXYbV5WYLdzyso8Fkq5kbRDirgIo2MuPaxEUisito6RMd3+yCa4WpTnnF1MbfoaaxY3RF4PyjDa8nfdOaDJeQFIS5A2ZYjkNcDRqwkpNxK6oQL9h5z6KvEjsw4GBNjHZ45CMxeW/QkdC89pgmf0uwtKxwQTmwPEVCAgQqIJoLBV1npXcpetIXeUc63qQOWcIaQrjHA/s4784Jc5g1m0Rn/xoGSSlg4D+60B1+n3Hp5lRBeiTwOeSoh4AhqEZznLhItVTMJ1PYaq3rxAf59sMTD0y4DCjb/qoz/LWFZLIM3Rn9ySVoiVoT4Iqs7hYkDyS4i3h+1Cr7JjXlYW0GdiUqE857DlBQPyeOIQs+kDXFoi2xMwLH3I/m21ySCtDb3aROQGE00/4gPIjiNEWQ8AivbbOUcHaukO67LMbdwhbnZWSCv9KGXEz+8Wu6RHe+Rij0CgDYxPTwGyZbtPEgiTYf9HI0yGNVuej9LEzJoBZl1ZqA3aDoHh1B3MSEAxVY5OwAZEMr2jhOxteECyBhztdTQBQe1uAdGCSI+bPKGBzu8INviXeuEe8dq+XbGIor/k4vpbVcYFFrMCToJ+fZusBZwAeTogu8Bl9kt9GvDdgF/8kHCQYAmJPgCU/CiRHMudRV4o9M+hBjqvmhCox2FNSYzxt5kypuoZb9tM9E8yAQW5YGZB3nGUHkf8D8+rGATlcSE26jCG9i3YRQH6d5cAh/BtBWZ8T2DeinLlv4fsmUhJCqlzgrEDBu9mg1QclFxGyU3OorIjk8tbRrXoYXDd7NOQtr6JETzS2N14abk1BRsNVcqzi9uIMCGAKcD8MNngPNpj/YZcJHKAJg1bkmtNAJQmUhbcNzeoJuKCtGaBIoWGQJHNAQXZHGDkqG0OUCAt4P4GvibiU9nLJLJVBCKrq9kgOFEONILtUb8vMjFg5liKt4b7g6QTE0mJL1dwSY8c9nGCPYwbjZSb3wxETyfmc+ws/NwODgyXztyoob5106Y0B8hzwPkc0CPwcq8zhNFSReerDFOKbjQxRJOqX7yRx9luwCEmzFHbyPFOeCDqmd6RpVsA2Kj8SPqZY3Aq/xuCo8mkmT0v3wb6IPlgLzkYFRn22JFDChUH8QnfGVgcUTnoH8zetZaIkyXh8E7SQ8X1I4/a1CuNy+C8mnntufwIockGsoFUyk0PSYfJqM+QkfwcJATuBPhjdC6E85vW7jtglwCgPdNfW8geHPRBDWfUVPSsCGCtCQpai7eprDiTVwliRahC7eq3f+XOsCzhXUyIJcGpW/szy/HvxovSoqscCWTmOezAagoN2eifQX4S0J9Dmc+BXsHZJ2kCo7I4A8WljRXyAoc0ACv1BW8JxSymAgzO5YB4iyPtgXLT4Gb4jfuH6vEl4TqrfrQZ7aALbPLMnpjhE5Sa0p6PyLdsMgXYXBsAHwugRzNfkONoKp843M3KDi5iIS7E4cXBijlEcGLlZNqsZBgz7CoAhzkw7DdtSiA3TKZoOcCvKocyBpxezbUrOhaPjPTJmBoQfx7A6Wx+JKOrtMiuBTRdRag35SQ3AET5z35TzPP9QUTK6TlraDcP0G5qY3k+TFoTGwiIrc4oPFqnSYNIW9a/UgRAaxvyzWavp9RqL7QJc8mkA+HQDVCeElrX/iRqGLP3Wg5o9WobjQXUZagVXZa9x8nd0Z9r0d+H/gg4kv1JdgyQ3VdArO4An288kQRCvtFGdhNnHPcq4nzGRnSJbBbP6dqLtoM5tw0ZFon7aerMvmnO2P1KAEeotssgBzA1RX+S0V+wgJhVaARDMRCSBMslXqGwb/MAB+anIHRaGMDEcEssZKtkY7WAGB4OsqAQO/Ko8s8QeoXgS+geH64NszuW8pQSowukKmNJ+GycvqAt8ubdBbpTRZzhE1cfNDWQaPWEYEpGvmIIHOa9bmMr+qNIaQv6s1DyATNAiqG1IYISG0TIzQOIiDVVighUMOmKNLEyrYBBGZMcoIjD0rIdBnANigmS0dxLMIFrbQFnx78N/rQNfrqNYnBzIDm9fqWBi0lBHpBz2s7gCN/NR3+2DDlJ84iyQvTSHK8RJbKFnknoIToZtQW05IALGLMJT8w2rYDPAYhLe7HhEwFBQuVr3o2t5Jrg0eJ+erPO8wYbUhxynQD3iv718S+zjP4ch3m3DOxyhBd1ZU/wN9EZHjMU0LyXiFDuHbKCK/PNBWgBKJaCPwYicOxMZlIE5UKvcitgttJXxCAGKfN6EINfDlmTXdmRgCpNjizcPKtnOXHNsfXbtD/Q8+yj3yyh9bpL5sZCGcIPeJMJMDlFT+v2pew/tA47wJqDiidrZi8kARhBUFUQmKgiTaSNVocmEJMCyCJCNge4SwWKqIrUoRWTRjhfQL18zM97szV+6uTTQxSa89OFsgddhHtGf8yZErpShRdlFzCLa/XBfo4n8oRYB2WO1sK4zgvKQlJc0yo0YSPaVLRx2rK+vCNgsF6NcgC3EEN9xOeGhnmOwW8TWIQhET9f8qM50PQP/XVvK+HyXl8bjkQ46k6gtejvJ7xOkZ/CTJiZjeAX+fVdt7TFblEgsDYNMsPKCT8gbPwqGeVZsZ/uOizIIjxm3mtBJHK7YEoMk8MwQMErhLKQoPCLxxwP3CJBCI7PMjpuQo4oN+nyLddPUsL9pyaX+Vzkb0gAXI9waCFlpCOBIPSGaFHAjXzN6hYA0mA39YVyNb4fA2gmVMQmAVfMDK3ZJxptzoiGKfDN7FcRaXatgBg1KUIVCQHZuMG1kO2bgHbzgCacJ48OdfYTUfYoFwouXaEdDTE996YYss9hz7aoUYA41ELMypEsQhXHGSwoIgVJ2ijFYj11qjM7riD8Np9MAxwQIZkD3GQ4zQEkd8SQK6VYahODGixZ5wHpmp6AB053myykhlb9TaIRlJFsFt9UGdkPEf1DF8hy6uviPbPo/1S4Js1V4wfDJOpr5/we6g52UdGLCFmSj63u2T9SMRjMik29bzTFTHOiRHPgehJY/0iG8hxQ91qscui/QLQYqd1gyzllkTOSaz/yecxGbc4AOJkdb7mjJ2MB0HH5deUMSfuRCs8UWEBW7MFrAWkNZdg+JhMwKYZ26LxVCWXSlVvI0MRuvo/Km64Z2j9p9vMAaM3KvKaTCTJlhmZpFen1oWMF6dhIp1HssyUH+LgTOxVHVkpoKdKXKgVR53dChPK6lSvXdNvlFcpOlNF19+yHfgwiZdZ2wCEbO+yW0yUATpOA+FtspQS2CSz24P5thb7g97+sZ4MYFAeDCpcvEBieYRiAKIl3tMk8T3JGN6zDWQAJ+QH5gNdHxxQ76ijcCVdci/5yliOviyT6CyVwkfRlkgiIIVkqflr+h7WwiHHPzNrNgS0tx4KOIAZYMQeakLbQkKnxWVv5B9jgbkcFDmvy9Yxyn0/5nTKOmKPkSa1il5kjAcQ2ckM3eOeWWeIQ3GMBMPLma04VmVor6/1QKzIyyqCxpxlglf2F/INPAIBV8DfxXZl6XzFrAoO1DdZaE1PQbmNt5i6sQQSYoS9V9pxpLYK4O19QxNp3bKEwDxYxzTNZJdwZUFfzHygGx82PjMdBXTTQsdB/5gG/HnpPjnk+JCRbWMyEzS1DDvJ16L/4d6wRxtRMW3WLn8EhFjauQ55N7ygXY2thym9EOLJofn0Y0NDhdYtDcI/xLA9JEdy8vpsZ2naF/t6WkHm8ItH3EcPiKJq3RH8j1uVOfvgt9yjx+0ahg5WXUnB0fDa0X8VErLSl9Niewaj/MxGUJ/sTk4IKIqNcmD7AzHVVeBizVn7ea1Ag9hNjm4rclQuOuJ7gSBFIFpLIIn6c6tXmSnd0AZDouQ2KhvFDZkTFPa6orDJogIWk6oP3rQRp5Tg/2tL/lSJdEUBakTbUT8VckQI0MzO0vU7scq8X0bNdvesA/DJwEPc3wnCazDOYU18pBwdHu2DRbjALj09GdMV3D9s44zvWOAHO+yyMQAPlkTQh+jwnx3U821tPCahHcLWzcBBFRHGKl4fSMxA2ANiNikhDc6RT6ehnYSSgCBpBzIvbhwFUmwQMb7XmB4f67A52C78ND/1Uc3eNKT2eaMWp+Vca/V2gJp/z/am3k1m7HGDcFNmh9Va4LZQK/okhriRXVwB2ZZfAFmcyNb5tQRlQjq8Z2D5mrMvwhb+ZBotFMHLvRROTYsiUwLHJsFwkJko7FRKCJe5tdK10ccOIWGg1t0f4nLRg1x478sPOtoBXt4/zDbYfBviNX2X3AJQmH/cNNARNmqE1sYn+7KAeLSpGkwbMfV25V9NERM5OhgqiSpPZ83JGwexm+I4FAisfbSihnkjCTcPbOjfSTxHkMerTB7QPZKNzV/bwaVl4SMANH5Xb4z7XqT6S/+NqfxP9VWB3R3dzFPrlmhjlyaAsBfpNzy9ZQURQRlIkcmP1ZmFWLErmAKf91zAMiEdClPnWvO5fzScLc+SIvrPmlrlBU7PCeUdDqdkQyfpTEv2JlfAAkKeefFJw/6mIlbuWTOnAQfMn+D46iVBiUqYctFccKz/jJSsLGCibxIW9GC2arwzWD7YzXva4ELHj/yizLqAs+MMEJVSj/W+xtZ+IMlNdHKLOEWq0c8maw7RdJ61bXWguP0m2blHiQT04ZITt0pkz6tNgMAUICJ73aeK+dvMAzcRubGtVHBRpDc1UmXwQ4GlmbRetYNj9sBdRoWBWxoj9MCCI/NgmsrJ9QCWKyUwQTz67ItZdK8B1D8hs1ahqIq8UjZ37zwA6uT1db7gBYxFvJwU+koFGtJnVoP9ci/4q7HnGoT/NBw3ja0B4pELOcyTi72RjtSP2GEDRaUgg2ujgaHjszlwkuJvqBWEEY85F8gd6/Ep7euhcNuaE+8+JtztHscC16BLL84hfFO4ptAKKAzLk0gOzmOf66sJKeIZLyez2m3OtJCwDYlLM2vI7wUxUeIU4gnLTYM/y9KC/eYPKNxMMO4BgFBICctxQds2KlZmTOnGx01fU5TZVc2iuO9HSMQAZPKe5iUT67JydJNeB/0CxTqmI9r90TU9aUD+JYu6/Jo0w/jXhHppYMVdW/9mP4rWX5/QdWS7naWKGdbEMLvC21AQJczirD2DygDvF/gLzTNDIHT5bKzczQUmSf3u2AtQkBbEUwGeIlgSnVCiX71QSIhhMHPfH7IZnLgS42swNguMwYR7GGflNaKv55tdN4ZZ+PQrETguIWPl63/xbkdKsvaybIw1532i36C/uNXDwexU7O7yA3jMWOBHo9/jOvDL4PdQ3oj1AxE4Jh1PHLhZXQj762/mQYwepMChiMQ8WhFDFrByGY5mgALM2xaVX9THtp5GlV2YDwF6FRtyN3QgXEemToYiU4oJNW2C9IVUAiJRPAG5U4Ntg33zIFhZSDoXDFKsFQOHGYx4VHz0YaEld33MsKZoGzhMSkEn/dYUICBcZoQAaPN/Noq8h/mtD+IHWpEFasdY2H1SVripQRVQYpzYZWT23VLxxRcqEb6cPSkxaEVcOfHPfZ2kgl8o/OPOgWkUkfAKAHgc20RrKnNLGvbBylODSiBUxNZLGmfs+B7N4Ir+O6cI9BUQYCSwcD459N6CUgsbu7lRrcLQIRkqptfWSDUXMrxe6pV9P+oxMNQzqZ36HFRmFEdcRwpgKsfZrwra3YEo2wiXvEw0T46EZdg7Z5zHkg9AD9K3FgsxkHvHyn79lgqQye96/jP72Z4rISTSIVcFQEFj0yHePpFhpptlsNqsqD+y4Mpwmk0kxUZq5Yu2bA8NEtuMBBQHpOLhfCRMYRayYCjXT1d7O1DwYTiwayhrKB0yJWStT+PuxAVNmNczHfg2VMcBo2QlAB46X0HG4eeZUh3E4U8VTTd2aqK7U3t1KZvSfRQ7w6m9wSp9akwZsGjA5QENXXGmqNDPWy6JQqprNojVvAy6pwr+ODe4KrN26BjiUKE4ANhJ9t4BMlQ/xNJ8BZGtpz/XHNLkO8tJN4fsFooQhGon8JCMBt2wRqD4hFrCyt6Sb/il2C5oG61VKV9h+tre5tf7Wu1dPnDz2xluXi7IgomqmP/ndV4++efLFJ7d2nu6tb0yKotBaex0fBwJ5IN+v8/kdSsXG5TXM4ULEd/iPBILqBwANsCzGOtBjaYW2hn5uQ437TbC53gqEfs1J59jyV4ns3hj9VVjzZQf9i70SpYh4Z3ePCr50+dyZcycvXTl/4uSxaVWpUn355e373zy8+fXdBw8f81oxWSsrgzqz4xP6as5bvlh838BBFtznkvems+ne7Pi5Y6+/du7qW5eOnT46m82KSfnwwZOvPr9TlIUWkd1bS4JjfyOmaFItd0PD5ccd09quzI15LjTkE08dYuU+xR937JeEiQCSnsCTgqT+MwPQWil++81XC6UImM1mv/vw04cPvvnso8+fPn26sTZRSumk/9AVQbHdDFY28bDbA1duHmBJBn4S4FADKyFqp8H2/ufmiW4avrl5P0C2Sg3c//Q2qtHu/vLq/74HOsNdA+G+5Tw1czGl1I8c/yrfvLvaTQlgh0mJv8N35OPNcxZK7ezsbW5u/OAP3vn9P/722QunyjL0zuakzGa4e+ubv/3rX//ibz7Y2d7d2FzTlfWK9peS7TGJNABoOI9RW3VAS3cJM0jyPyXy/5Ba5oFjikSSt74DOSx2Y4EfL+Qe3NMRLNnp5XjHKxD/IxqwH/I76oZL8GH+b3N/QPzddaX8tqBT4+FCqWmlq0q/+farf/Sn33vltUvrm+vaCAG4QKIJjx89+/X7n/7N3/7q7r0Ha5trYNIEKLMtRJqBwgrIg6EVmR9BERRDsWbs7uydunLqB3/53bd/+MaRE0f6ACdRrTyub/Sh/xpIPmwylWOezma3b939D//+b/72P/xs+8nTjfU1PZuhqqiqCJqqCpUmVDSboQLpirSmqjLYEbSmqqK0t9BuAqEJoApEGlKY2ocHaWbg81Zy/wM5KK6upJt3+kT+znMf/x/3SQCth5zjv9qPeI3wJyaBqcFLcutaqo9yFVzgbbEK/3DYrn2MgwVUoXae7b359tV//t/86eWrp6d7mE5n9UqcmSaTcrLGX39x/9/83/76kw++Wt9c00YrPE4DdtXEuUsbedkoByDkAHd6tYv0LgeYgYMvYNCRABaVhVh+3Kd+UnF+QMLJxcAAyWVdDjP3CLsnQfGSWJCtBhTLea+VhFC2eFAslkOKQu3tzY4eO/JP/vkfv/eD6xrY25tW0ACHBMAAkSqLcq18urP77//9f/rZz37NpaKCNcEoSJoQb1B77f62/UHJe7OZJvqT//YPvvsn724e2djbnVazahXP54vkc1Mamn6BmSeTydp6+cXnN/7v/9f/5we/+XBzfU1PpzCRXVfuHzNUmiob8VFVJhkgTQCArqyAqHYAlAkUGiHoazj/esT7zM0JIALnOhMAxU6f6eDG/LN448QfL3yaeFCuSP4d7+bKpU253mnLecXRXFcU/kr8nUb/oiyePdn50U++9b/5H//Z1tbGzrOptkK8ma+q0nu71fETR374k7e/uffki09ubWysAVHYEdOFhMIodlOZa4M55pZuSDbIAQzk5JsL3gTodZ6jP4j+c5GSP8I4Oa0GEDl2CZGe4MQoAr1rDWUr4HtBsl2iuDAUK2ZFZvZqLw6eFMXu7uzUmRP/w7/+r669dXX72c50VlHUT3oEnzWwN52yUu9++40jx7be/+AzLgq28L1ywg/2wVBWJohLVWlsHt/6y//+z374l9+pptXe3pRg09Hq64B8VVW1u7N34uTxn/zxj+/dffDR7z7d3FiXrjPkHNsy7CNXtsUcPxmmkRbvwmekNiZBV+8SqC9gajLQSIJr021evHHij3qG/THxn2j0I1ZdYqyXYi03YQCW3Nv+P81dpbgW/X/8R9/5b/7VX+7tVtVMq0K1GEOaJ6hmWmt854dvPHrw7ItPbq+vT6KTEf5GGqKFq6s3cZKqPol5a2TEx+2BvmfIXrhIGmj/Sb22ydDcCyaDHnYosVDcdy0gy/qAJcc/uiRsFghXgmH2FAEnZFWoYjqtTp0+8a/+d//i1JkTT5/tFIXyeyBI8hU5yTai7d3dK69ePH7i6AcffK6Kwlx0IEP9ZLBy013mgitoUvy/+j/8l6995+rTb555ftHq62A1IcxKqdlsprX+wY+/9+DBw48/+nR9fR01GzKOonkC2iBWqQtXEoIvWBzPU5pMclNw6y2PpPIMela9q/fOBDBf9Oeu6B/N9OIJr1DnYl/sk7LIvqd8iCifBH1burFipYpi59nu9378zr/8H/6zvd0KAKueqtUMkMkB924/+vqLu2vrE4TxGkciYi5SeBZAouJmnSGktoxQlMs2AVRzsxmUD/Yh6M8d+sXF4EmEFMm1MsSGB1Om/A87v6reBdqvwsZ9URbYSp2UKopqhqPHjvz3//pfnDpzfGd7TxWKaorKkkCpKdhA7u5Nr1y9cOTY1gcffFqulbDkH9sBwAoBMSmlgX/8r/7k1e9c2X6yo0q1CrUHPA0A0Fr/6Pe/f/vmnS8++WJ9fQ1ABngXkD3XdKpjlbrgyVNj2+Ukr/Khn7vDrzC6qLXxEV9S/tKSrkgM+sMtK8Fw5SCcJgc8vGKifGB3RMmAmFlVM33q7Ml/9r/849kM0OAhwZSZoFHN9H/+v/jDU2dOVDPNrDhp3V2WUsxKKdePKOUeaqAHX4LK3/SdSxIkm2UwuOtwQ8yfB5+q2olr/60wyer1xJnLFkiif0pg4JghQLlmMPArSfYEFuehen1QcEGsmBU0/uk//8Oz509ub++qoqNzAoUVNTAppZ493Xnvvevf+s5bu7szpZRHH93CMKuy2H229+0/f/e7/+jd3ae7JsGsvg5+DtBaz6az//pf/oszF85Oq8pDDE4smuM/KkJ6hQ69tI2LqsZ8fOdMAEoRnp5ZgdJ1iuzTGjolasY58Z9MwB5hpMONJpUCEfEm7CbqI8LcEdnlkawJHSKslNrbnf3Zf/bD02eP7O3Netb+0dtUvLdXnTqz9Sd/+b3p7qwoFPvI7uM7+d1jEi1IQm5mKT6aiFG74TULa5AgLC+U2ZHE6DgKzxH05e+i3/Q4n2DiagNd6tBoeASYYlkYrlc4ka6fT8Ae6iHBBXB+XUpovykiLopid2f61vWr7/3grWdPdwoXmpuslfJqCczTavYHf/jexsY6zKKw70lYEStdYePY5nf/8bd2nu6xWkX/Q/OllNrb2ztz9uRf/hf/aHdvj8uCCkWsSClSJrcbMNLlAKW8XAeFFUOfIXIVbkdFF99YEb5b51hzK8pPbT/i7g4gE//j/+6bNnqGmQa/yAQ386xvRHIQUESsYEvy6d7s4pUz3/vRm8+eVsW8d2Ch1Paz2Xd/eO3ilTPVVBdKlPVi5szOEIQza0ohZUXjDXth+JFRtwcMt49r22a1ccsV9Gz6/JG/2PJyED5M7Q1BwgRDvNdPcpeGSNjAs+AFiCktBcyQQm1m+zAb/RUpe+OyYnBRFD/50/eAtrXndlM2ZprOqlOnjr/7rWt7e1NXJ1qLSFWovd3p23/85pkrp6pptQL9D10OePZ058e//8NLVy/vTWdcFBZWULU+wNWe7lLkWK+JrRUFi5VAEj1BEvi4OQfI+jFzn3NDRulIA73C4vCrtyMFtGSLdEbAsvpl2YlLSTh3ZkguhVVT/a3vvnHk2Lo2St9z9oSkNbaOrr39nddmU61YKVJk5oxyFCEzPkkYSsoUc20A4j6dF6F0OzJIhFearTQpX0onf/p8UE680lsDenqu0fGAcBLrP8pdaJAFFYKGTsoTE/JvQvPDAm4h+vsmoWA1m1UXLp29+tqF9r4Q+ZW8KGdord98++pkbY3kIIsJoMnG5M0fv17NqlU8PaRA0NFjW+/98LvTasZKmTKfPNdL3OKRLhMLlVZ7nQg2oJUjTCx9eHi4DSV8nAy6Sv7aV7cW0DDKwjxxtseecMISDRNX9tgJQoi1grwgvnDlDMagW2tNV147WxT2IjCCnkyKYFd/2UdwePVnYx/uRBwhxE+AsCjfoPnTpAxBzWvdnYe161TWFxO55bnRoRrUJRIXKcGzwPoj8o/V23RCmMIHIpT9ti0PjCAVSjXDHbKScGZSo3RVXbp8dn1j7dn2rlKsa0AkqNvB1lyRs0ofP3FsfWNtd2/KpQLDCEfrCutH14+fO6ZnFfOq/j+UXwBdvnIJYuBopOCIldWRdhLjsFYwFPzhuHJUHaHZJ+o/tOk01Ld5udvnnbO/2+AW4J5P9QvQQ//MmTFqAufZBTNkxAEkidRYbVT66NHNcxdOzqZY8A5UzNWsOn/pzNFjW2aSHFjiYhdBziFiJ/Iw65X9jKEOssC+2U8+OHdU5e8Sd0N1UVEvuYdNDVn/KyGCoOInpzpUGGeU9ApBtPCX8BYkCMjJaZd6f2JDzA3l/dRdcTyAV8x89dXzo8QIrbGxsXb69MlKaxVIa0pX+tTlkxtH1nWFFf5zSJuA6XR28dL5Y8eOVdAeTazP97zCiJN+qvs2x4PiLGE/wXZq+kgpZDTGAICM1fGQP4xeEPU8OYP7lJ+h+FOROrQItdYAFrS+Pjl2/IhRfFvsWqDZDMdObJy7eKqaQvkZcCg8w3ckaYWDbkFIUrFFQV2VOtMPNjhBMjIhmWMkpzE9ewIWUlZDnDLC5YhsEsgNJDLbLDJIm7kZIsApKIHLKB/k1EjgO057V6z+erCVVdgLMQ9RIicoxUqDNjY3Ll45M6sG1+YZqSZgMpkcPbKpNfzshxRpjSOntiYbJbBa+D2sX1rr4yeOr22sG8dfU/uDYgoQS75ydCdwwzyzIUBzWu5KKlEHxjJvGmBW89X1WPhPa3WZPAqcy4bJ+nCIf954G1RVehQJFQCTteKtb70CDaVquL8QrvDQs4q9ahNh6vhjCPCjluqig8LcGO5tjIT4k5xu+8Ao6Peq9EOqQD09+MLA85Y4jMUC6TUu+WPWaeP0iuRZ9q4KYaaixGCEvQ5gxMWLZvXMSlVTffmVc+cunJxNZ6NgMwAqrT0FzV+Deqat0sfq69B+VVUVkHpB9xM3tBJFi6IkGClO636mdO2L2zH0Oq+fa15vcw4AiKgcJNg/PJh2iwc4fJec53v4ZrNlmFFmTh3khXc4g6GUKkYiXzPzbKpfv35p88i61lCstDP8ck6vVhLIfwgn/e284637i/UNCk7xDtTy2kGJOlRadHLDwDVr7ay4a9IC7hohdCyI+T24HlKSCP0OOGlxWGCUEchDTv3bD1klHETBU1E+hIOov5eCcODM7K23L5dlsbc3OAFww7VRFEUdflWFmoN5vPo6UF+FVfswUbiy93mKegowItT/3hKEg1woUajMGk3B+7k8cuKV1jQ8kG4BmXtzSHzsLOmx+PygKeJHOL+ghkrdf1uFGhHuoiiePdm+feN+UarF23Amms308VNbJ08d0zMEyYEwhVbs15GCz5QK/pXRngjDLZimRX8e70qXCjrerK/0BVs3Rw0Cdxb/GdJnitbb+p9F/9XASbWmSenr+rYGjU7Q7rbhWEZIWoEqb+8SBD899q+868raZHLh8umq0otcDD7nKcXb27v37z0sizIMp4CyLB589XD78a4qeKXieRi/ACon5Y2vbz15ul2UJaI+wCHN7LfHJS2H2+5QZs9mzGH93Fyzt0pxZpZ+qdlYnWUCaN3RHTrmnWs2zPnfD1GD5PhUfGQ0w8yFUtO96tGDp0rxCDcgk9bY3Jq8dv3SbKaVQ/wtsURsgIUxtDOiCvOdBKxKOexywsncruiRg+zhgz5qg1pibiT6K4g/PbcLot8P2A9Y3AMBsIrwomh8hiQFSCQvWgfjSBVIenhH8Ks9C4r9lrhgBClVTfWZ8ycvXj4z3ZtlBwCDrhXzZvb29p493fGLJmaWrwr19Jtne9t7KwrQ4U0BSqkH3zwySx5poGIR7lU24MrxXtcSb/3ubIGD0i/VNgBovJudCeq8IH7M5ed+1f3ipKH4wBimZTTzFCdCKf7so5tjXQ5MVFV481uX19Yn5nWUmED6q0AuBEjGAAvdAhn9uePKSD2/uTnPphUzanG1pvEZGpE4VXA+A2WTQbQgFkH7IZEhUz4HESzIoO9SPcRsJFg6xx9TCS9oJ/tDfk0vSsaslGKlK7x5/fLm1lo7NaBn9QVgUpZ3bj3Y3t4rCiU9ropCbT/eufPp3XJ9NQc+vCmAPvzdp6yUv8ogWfycFW9oAl05dT9pUYOoE+GiaUHrvJeb7tl8/aL6r+gugg9ld4YDDTHdDKNmhdG+9RSAtfXJR7/98u6tR5NJsfg9aMYAZy+cOHZ8SxsyKNWiP2WaABObhHl5VD+Gmj8g4fUmgLspWPlTLSezmdPJHUSBeqNBqXRR7gk4DybVxRVQbwBzNZQ3vyVn9aMShpUUCvKdiWP+hLG8Uury1bPJbLZFubwlE1i3KK0//O3n7nxBdhJM/MFff6wXwJpWX88P/8FkMrl56/Zv3v/d+saaBmIslhsuHU7Ca9c91kfeJ9u9L8D+rLUPjWGcFwd35povkHPYsvYq4UuORgGRGCEhdhc5i7J4+njn53/9/tr6CGMAYqoqvXV07fKrZ6upVqoQjPPYlyal2kSjS6F1KkCDDB80mgzEMwRS7k+XVH+DfgM3QPscDSwopRWhnhhkxEPri5LQUE9mHm7dF0IkIrV0pnTI4KFBF+VF+R8wMvt9LlhVFY6fOHLh8qnptOoznm1vEQCsr0++/vLOl5/dWp9MoEFutsMgaKxtlF/8w9df/ebW2uZkRQc6XF9a6/X1yU//+uePHj8tyqIm6xZjLEnNwM0poctUI4nUaLgYQe1Y/4A0MJZG1ZLWxBpeJ1MuRrrdJgRAY/PI+i/+44cf/fbmxmap9QijYGZ+81uXg9mw1KR3gwgV1fXe2zz0L2IdjAOWFaM+QgEJNaU8qqn6ZLV9OLZUTDI/J384nSLV80I7UommiyxYZsiPnL6xRP8tuL1TAPqVkNlQFLvuCMops0wDjgA6m+qrb1w4cerIbFZx74gfXiDeuFSK93an//Gvf6XsxUAJI8r8+xf/738Q1LDV1+GI/ltbm7/54JO//pu/O7K1qTUiE2ZqYAGFf6oUF8r3B+3l/MCdryb95y6woJca6PyVUltZ2p4b2hfOOMk7LPcBYtOBalb9x3/766rSi4/jmHk6rS6/dubI0U1UpKLgz4L7z0J7wO0GwwkGitTA0ZjId41yGUJkg5ooVK1Q95BKTSokCeXgbPZuRvyF33rA9QGxcNDUEyAHULFo3UTCUk7OM3KNtsN0CsM2site1uBRpUJMBnTz4I/ygo2vXTvfH+JvhNdAANYmkw9//cW9W99MyhLmSBBCKrdNwOSrX3/97/6n/7B2ZG2gSvfq63nB/lQUxfb27v/j3/xb6+JSizq56qDJsR29wNpoDdjfGmOs/maXOsUN3UsNFMP+zF3wc8/GAjVh5OgwIFRbACZrkzs3Hjx9uGMt4BdrAfQMR46tn71wvDJcIErWnVg0AcTRArAraMEEuRpGOc83li1E/L+cVYpI6/1MCkB6aJsjfYMmaH48UM80eUg/QjRtCZArpSLXJJliRVaQtT/FihBBD47DGjABtLG5dv7iyapTnAfxHY+cWgmIiG58dVeZLZbM9QgGUaXXN9d+89MPf/Xv3l8/sk5EeoUFHfAEoLGxsf63f/ebL766tbG+5rC7PJkHSEKtRP9rAjZ1qa20Cebu/oA700A3siS/twyZ8nbtT/tHpwmDqQdmlK7RplPSFIMmUKHU9tO9rz6/W04KvfAkwKwEX/vWJV3BYv4x0K/EElMQMEhN7404HIRGtBgFc325gh3cA8+Xr4ExfiM3oeU0jAlqGI+wOYiirgOY0o4yJzQEsC2GKT9D9uqnTq1fLk0kcKls6uxzxnMKpoSFRV7/wVzY7mMoVrOpvnjl9NkLJ6bTqp16xfXNzdoFXhTq6ZPte7cflmVBOnKLCcN6O7PC2ubk3/6f//r/8z/9+3Kj3Nhcg4bWaHDwHlA34aX/s5zyXz15+uynf/vL9fWJho6IJ0ANnOB8wSNbW3Qh/0BnmM5X8W0tQjf4Y77KTse+UUCf1t+v+a3BwDXRdpkfDmdGpSyTgJUI9XUxMWtNH/3mxrd+8OrilwgzT6f61bcubB7Z0LpKBG4so8nEIZh1D0XwMoFgZsCxMB0u7IIBI1a/QFj6RRAM5JoJY36VLMdRy3azELCF+B9ueBJQ6nPN7lAjDHuRbwM4HZaJSQAMeOoreIqIUKLeZ0XRRlgsBedSj1cIN6N6ratrZgF4t20BmHMajKGwMxqmwGRSfvy7G48fba9tljN7fuVlaBa+QSCTHtY3Jr/59x88uv/4R//0vavvXi4KNd2bVTMNaLZ7zqwKRS8eSISlPvfIDFtobGyt/7v/+Hc3bt87sl7qvam4FBDCbpSCuCum1+5IRkahM3iFI3eTU2bLNyv/CX8RS5UtzvUfRISyg1fYeVZ5eMCv1dQNLTkatOOREw6imiyqu2eBclJ8/dm9Z0/2Jmsl9KLqjHqmj5/cOn5y697tR8VEMSA2kG3AAVzwsQlBmUoAkArPcbSJhCLcpW2kJCKdBOQjc6Q/Xrs80lEU4qzQphjBtSGt0bV2sqU2E7A9Al7bxzYraH6rHO6VdM07Cv1S9ZPE9J0SX06fEJSn35o0AKJyUp67eLKaaY730NBa6eQLIwYzf/35XdLJ2XB9pwYpkCZiox8MaKxvTr787Y3P3//6te++8u0/vH7htbNHj29N1tYBzaz29qbPnuy4y2SheupgxGeROnvyrQapzjNrYKLUZJQ1T1n+P9v+6c/+fjIpU+IWRGSXuzQJLJ0tJJA7OEk7DZpTEyJJD0yNaSOHyDZ1AIzWYDDwIszSrrmWNDXPgW117ScAKMvi2ePte7cevnLt3N7ObKFpsFkJPjJ57fqF219/M1krNSVClwywEATxYVE8wDweIKsUxA7YsfnC7YonlgBMQv4I8bWA+ghc8o5qpT+nS6+xTWWueo9d7EXh70t/hHDqbo6mY43wBqSHJntpKKt4xWJUzkTRPDw+7Cwc5D1cZU7NbKrPnDtx8fKp2XTGzMgPJ5rvNhifepvWCsW7O9P7dx6VhYJGsCmCc/Rhg9WZXwE0wACwtl5qwqd///nH//D5xomNc6+c2TqxNau0KtWTx89u3XqgysI+l7KMAVhPQW+Baj8ZbDNiNA+FqCpHG9QNmZxbylc0FHmgVK8pFBBCkxep/3i8JOOdFN1g3loqKqesqRQxWfkd+QB5HQHMtFfp/+47r7158ujOrFJjrFub8v+v/uaXN+7cOzKZ6OnUXfCubJMdsi17PODJkuyGuux5LQcAunZ2atcgcto+WcGfjh/JPjv6KhetDJAGoGxc9tVrLe7EMQL1ZXzrvORUK4KDIOBDROYlk32rvb3px7+58dr181gcwCKqKrzx7sVf/IePLCIFUf57U3CLnzPcfQwf4+D7yVDvBxsZwFTX8IHHyMml3Q3yQrGcUx2MKv2OQVJdWA7RM8tWBiKXmGI/dOUcZRIkhYqM/rUmJbE/Y0/tjamfcktGToKZrHy7FYjW1eyNty5ubE62n+1R1wYA55pQoYyKsixvfXH3/t3Hk0kxg44H11LED6K7BxEwY1K0tj7RTNPt6We//aqChmJNxCUXayWIoGwJATb2pn4M48sJoSRDznIWAt1Fcr7SuzNX2TJx053v8Ekmj6rGoT+YNIOFILpSwjU39lNUXj3fBXr5D+VVPFSUA9yXYtqeVe+cPvbGiaO7Mz1O9CcqCn7ybPunP//VZFICTkU4Qmbi5JhC94zWC8fhuK02L4ih4HqrnI/1nAOFs3ZSKTJbLgvta0KJctvMPSzBaq2Y67sEuFUHhULpWk6Kz353e2d7qubrsuP2s5rq0+ePHT2++eTRNhcMeHRCuUKe5YAVgv1pQ6chBMHDdaIJcJHdYD8yB9SPaz3pca0HaEDzc/MA8T2IHiouBBmBripBLY5aC0SjnazBus8oHNoJArGiSObZHFvkLbedzS9HnjJ+S8AK+LK6dPV0HphFL8NMdrnY0Aq+/OS2nlXlpGQ42hkomPnA52wQgTSYAQUiIg2AwGBFa2slMWllpuLQlhllnwhMxBp+Rc5f9iB/1Rh8EA1CvUASjyBSAZC0eg4kUOm9hnhSZJ/KSfgG5AFRZWKk8tx5y0O73DCjYjAcky6zgcVMpeI/f+VcoXivAtNY5f/GX/3t39+4c39rrdTTqQj3Lmp7RkukbYOao5KodtiAgA0dF9DQeSoinZvh5Up7tHcDHT8tFzHwmj9NAN0r0OFoBo5JVPMntrokEDn7n15zgopSPfrm6aMHz06fOzabLradz1RVevPo2qVXT//2F1+slQVM7W5PURT0xQwGou5mf/LtfMY2Af5vgf+TywF5RL2O8ocE49E8bsgQuVK91rRxVGsgvAdrw+mCB1j2sSyCSqYDDsHDL71BKGPEbmCOMJrgP6Gv8eW/cf9SktukKxw/vnXh0qnpdMYDIWOulVjMVM2qe7cfepFBhpuOa6utxV73RLm/zWDAMgAsXwEAmLSJ9U5Y1gRgIN7lyVmkCUs5Y5yJwCJHjAVZxAbifkETMpvZs7SqF1LryO/exI2IXCJU9sImBVv4wxX1mkhp0mTpWtrdj0pZhqBWUBAlM3vQSTFvz2bvnD721uljO9PZqOX/zk9/8evJpECQqvFHKcb4I9A/6a38je6FCySC604EOnGb3t/kGjzVFxciIioxLPgPddfiYYkhyW2QrH5ze/kNstxvQgyfIgVsqELtPNv97MPb5y+fmO5VoyyFvfHuxfd/8QUJTUqG2wawzsAWg3bpwU+J7WA3sUsUTYAOZxbwUbxJLjlmEudKplRYO/29XIcWWbUktAWEttTCemzxHySII7I8ypDVbRahCFRG6qQmlVbFShrJIbBYF3Aa0KyU2tuurnzr7LGTW7vbe66s5FBGxyPLun2q/AcTTSbF/ftP7tx8WJaFNgMAWPSfGaQ1M8Bg8yMNYrAOzC8/JDBINuxIiGAdD2zB4zAD/5kQK566+C7lpTh3SzWTwkBdDh9cLxIgAEZX9UeDGIHKmSZMMUHbj6bYxnqbISjkAF9Ea20M/YLaC5xvtqv/FPGfXDmriEeBc0P5/7N/uHHn/pFJWU1nwdUUQsXS0I4kuEciVQC5/JmROQdnHV3ZNXjyomxJA9TmEsw9GgK0dQDcP1APjuu1raIa4mzHoYEjiBTwhmRGEhG0YShyDQhyXEsqCvXJb2/84I+ujRL9Z3vVldfPHj+1ZcgbLruzQ3BC0BdeVu5uhhwFS26lIwJ59pDIAZRzW+QM/sOyK2CKp6ec/dVGgCgA+qKEBCzyZl4TAZ4yAdoqOXlsGBm50tpbCX6QLFaBWYg/m72B4LlGkXaR2SugSM3IiEIrfuOdi/Wmp2EU7HIDUio0gwFdFurLT+7s7kzXNksNzX6JRQJlAClT3BNDg4mUtvAKjGu86+xYtAUwaznwHkkI6U/YqClRg/uGs44ucDav1YeNWe5cTOT1P1YpVpNKI8g9DRP3NZMhxSkwmfJfk1IAsYY9LFBhO4iV5VDZtjqEfgJc+X/8+uljO7PRy//fTEpX/oeJLkhrATkLHUtb7UOEJy1GPhQPD1hiSvAOLdEomBuwPO4I90NKfgH+on0GMA40xF1PzTnigSeby7mJdzWRQnAu6FsUJhnQiB4A5UTdv/3w6eOdrWMberYYGZSpmumjJzYuXDn14T98tbZZoGL2YIAfU7Lwf3F3K3y8ExAJw3c8EnQAJPyHtpkKy+QqSv5IVUj0CPEd38i8Yg5wgSt9wCExsZxRhf/lsONAUustn7aSmb35HxUoPZHuf7RwLGVQmIUXpdsz0xpbRzcuXT09m82aBODyZNDAyQ1XpyIG6NbXD0wa9y2+4fwQNDMA7doC72PjWoGK/B4Ig6CEc6eyLaMpDMx0SwgDICziaTCTzsxg5f4G0h5GKvUFanH+tIdSNmR9ZfvS5MoyRxpREwC3V2i5wXYfQ4G0GfEgnD9FWhMzaQOU++gfgTAmZ5i7WBH/yStnxiz/gY2Njb/6+a9u3H1wZFJU06l5dfi//RggccVOPPACQzR3pTdaZvE8fH/0TwMd0NBYQ+Ce2YJB2q8fh1Nom7uGeY4ANF094MMj2zuPUPjl2kiOInynUMXTJ3s3Pr//7g+u7kynIzh1MF24euqDf/hKmECHcaXg6bAFNymYwwFC2wCAu2pQL0Vd1kAOvo6khEBp6JdEUE7VN9NhsOk8JMvNTT8dICeHwyHjWvZqmFu7B4fcIAfdlIn+fvNXIAhSDE7QQaPl4ViOL+UGMavZtDpz9djW0Q0909FHbb750AAKEVFRqKePd+7e/KYsFUwd7yB+Frc4E9iUjUzM2qxn23NOJkNIbnBYADFq87A0MZvRYH/R1/uCkclOTYPkroitSIkpJuP7Bq4V/MmjRu49S5qZxO38OjbZv6HMR1CBpWo+SWGAIIZi1ppUYeO7BpGM/pqgoLWhhAIoTPl/5sT1U6OW/4qfPNv56d/9dlIU0MjMdZ00cYD+U30DgfiIQqkGSsP2bdLsNRq3oW9Y5+aqHzRoDNA0A2gRTOflZQuQZijDnXaYgydERhUbIjk5e5rCihODXLkiESEAn/z25jvff2XxS4eZq5l+7e0Lf/PvPtCVdnd0JE4JAdtzvu+JGwMOVFnYbyO9uZsQe3lDCpUhEhZaslfgDB0rWs3NdGaB8BP0KazhcTTX9gMcELEWhSTnih0O2BH7jJJ6Z4tRKEVsHxaGMVTX5kOF19++OFkrd6a7LSlfcoEkOmTKcY8Ul+vlzQ/vPX70bG2jnOnKst6DA7T5yFoKqmuAWJNy5YpF/7W3iTWxHgRfZMNJZNiMy5BgHmRHZ48Xp1NcbrzvEDd2mQdx9hT52XXUWEa4v2KCGWg46VYGFBkUyM54NRFVVBSkiVhDKyYNVuSzKbRl9oHCogzsdFWBRkb/bfn/6xt37x+ZTPTeXiRSI9VqEIYSUZ0ZsoJPBmx3lNFQZiTmRhg6Cm79PreW/LVZcTk8YA+GhrjjyZPCP6H5IANLM0eyW7AAaaxS4K942BYdmEyKG5/ff/Zkb22t1HphFGhanTp/9MKVU198dLtcU3b9l5nNDaAtOUMuf/km2Y8ELPff1QVuQGxCvyX/2Bsg3x5ZNggLlbRISE3csvE2gCsguQO+8+swvj9gG/jZo1dinZdN88wW3rZ5Gs3VAwKfx81+IYA0Fv+T3kKChyJ3wZwfpNZ6c2vt1WvnZ7PG7b+IHJPXgQjZQRF/+dldy9CDK40JZj7gVvxtDmCC9v/WluIF0g4TJGKzRABitpvDrgoiBpQL7gwZhcFIR7JykSZLFmzTG0ZL3RftiycdAAdDPnvMwd7vzg5yTWFj9FjNp1NMWhG7kl9pwE6GwcxmAmxzQJisAlBM29PZu2dPXj8zcvn/9NnOT39pyn/tnakg/hbxXcthLzJ+V3VaSi3PSjaFx7Y7gPI5sP6GH9XKvpLQTwuC5z7IjF7Jgxv6GblQ6mUj3GkxrGjrg2tkVTTE1BGkmQpHuYEq1NNH2/dvP778xplqwZVgYxtdqnOXTnz24a0gUiD4PyBmKFcRKTcqstEfYbcnEOF9AyD+DpFYwrqI5UJFfI/ERJk4slWOrUpVMx0otKWsIN8bROtiCSw2N0BMCNy6g81fnM54IhCLJRLkh56xPi6RZPqrMB+Wdgx2ndRmDV3h2Okjx05u6ZnuRl4l3zj+voljheK9nen9W4+KQsGwWTxArIKioV0DZk2W/qUZBKUt/d8Uhybj+5kwMVfaID/sBSXAflAc3OZDFI4aPORrfznHEB5K9SUcbuCKeIqn/CFHCde3ngi7j+ZiN2tcFZEiKCpMNmR7rEx/DmVpP2bWqgp3+2o7D7BHHwArwp+8em7k8n99/a9+8Zsbdx8cmZTaoP8a4e9EtVIU+5BAUNgD1LkQJwlC7JlyzVdiU8htovxzF+OGWoTIy76lf6/Q3UYwzyL7oPwGIiwlwoPLPt+SJiiBbiJeAsiN3v0JZGbe3Zt+8tubV986Ox3jGtIVXn/7/C/++iOL98b7wOFmtQ1BhIP7PWAgWAqGM+aAIBYYj6jnYiqGd0RmWfUzpwE2mg1wV5dmLmsPTkms320ImNiuHboQ4BDHByIEBhGH28VDPb5BYY9qC/9flUI9xKlZTcoIdSKjSqnpzuzqtfMbW2s7T3f7JPsM618gjOVa+dUX9+7ffVSWSpu44GEfDSJNZgJMMMU8ALB212xwVZMiAubkswk5SgR391nDaNFCjB6SYtEKxOcwXeoQXWQ0fkHymGQ1DMmT+54jZIWY/APpGaqs3TgrIk0KVBVukMBUaSqINBNpuzppK27NPu5rUGFYoayYt6ezd86dvH7m+Mjl//buT3/5/sRk9EDp0S7uk+wDAB3AH2ix9Y1A+vczg1C4RiSxEJM6qvV2kCcLynQ2BJlIW4LQi8bDfdIE+nCAXHDv1z7UhwSOI2awVJEDmF1dIS2I5TNooJyUn//u9u6zmVKMhVeCZ3vVuVdOnblw4t6th1wyIaytBj9eX+eTBXZcPGT2hEM3A4ar8+wasFil4jr0Q7ENbsqRJ0GiTz0GXNpAXUAUNQzA51EO5b2FZhkgUobU4ksUNxEwjw+yWixWhuU1EI1/mWJvSq75qQXdoEQgmgQEBGCyVr7+9gVdaa+R0B7u05/65SoQQGVRfPHR7WpWTSYlVWB2tqX+7EAzQxtCC4FJMzTsIqgOvs4W00cYIPgjKcgBLoPrVGaAqVaSE4VVQQENyeDOyLIAKYUtmDg7EE5cHxhy2uJnAJbMqkhrC/4pMBVERFyBC1LEYeQran/2OcANA9ixPaBN+f+nr10Yu/xf+6u/e9+X/zbQa8n/cZVNSAluGCBB/2QVQEI9iA5t0HXkhADaINzQzfBBEy8wq+pUf0DZYzA7mPopQIumjQQ0NARwe/we2Q+b6xwX+m4OHJUscDhFrc/VRoCpLIv7dx7d+urBK9fOjiIMt35kcu7y8dtf31+blKafj5FqZwRGigVdTipIMTNBgarABPQNgMdQ2uSdJbgfABAOIZKEblrNdL5JXdsX6n726xaaIaoQQ9V25HVDhbRwUBCzc7R2pPkGErbyC1/snXYoODsqY+puZcOUYhVIQRyhEuZ3oXHk2OaZ88eqaRUSHzo4allxUCZSine297789E5RKNKwkp9yEEU6dPdak7IhDEYNjq2rAqzEvKOHumEAE2lPCfWlfcgQnlfFpBJFWG7cEAzbBBELiAL1mGJ9iNrkTawcs1w2rq19QTFrY8RgmFGO8k8KVDEpKEW6IiqIIUB/F+j9ghjgWbMmDSji7en0nfOnr589sczyXxN0jP9o0qbqjxUg4Oj/8P8pcR6p6Y6EQEFSKsunAZaHvb8saO+q3/PNxqaBYsiDuO33EppRQIci7wU/7CVoMLHbIAz0Q0G3MlUqscPr/B2kaDat7tx4+Or1czTKl6ar1879+m8/YxHIIosY4orCRqeVEyZbGbOLqopZg2LSD9tLrdnbMwF8oiaARUhNpgJMmW2smmYLvMiBb3fZGXk5UihCUDPH30gZaJcP/G0NyUOtXeDMkS2eHPVyhqkk/Sn9x2QVBCeVmm5Xl66e3jq6vrs9zW4ARGyfwJE0/SlruSoMKkt1/96Tx988K4z+N2mrQyWAIFvCm3igAdYmIxpiJ8g3ATrEYS8LQRSSgZmY2oAbOWCYyXIy1AXHum+1klAus4aZXLMoRpgkh+aD/RycatnWTiyYSYE1ByRQmVFwAdMVaUWkYcQ+AdIaTKyFWr29msDCqRYaivCnr18aH/3/u99a8s906k6pDsW+FsvJmkAiMUhPQids6N07EEsoUUQHorweHGqbepFuU1I7DxoDUFCbydJA+1P4x6d+enwfiFROolLfdgbK3QgaRs/RdGiGX6c5XDJhPZ8JGrrwW1RO4lop/vT9Wz/442sjbAIwz6bVlWtnj506sv1km1UQhlPEljvtxsIkTGACSdSPhkh+5nAnAjVghjJEzlD4pyu1ioR/fYy5R9tEuU8XtFBcBoZfwAhlvhG8lzLDfpvfZjcWMtFyIhYxCoWQs5f9hzOCl2OAdNQRfSiHiynFb7xzibktaphAn62y5B6AURT/8tM7O9t7a5tlhcouqoZlN+20X7TtQi3HTBObzkBbfxjSZs3LNldMYB0ggvAjkh1ArLYXqcmL45jHhiGZ4yzzA2qzAa4TgVLSJyje/rV215b8A4ayEJC7uFSg+du9X5bsmhDua00AGAXR9nT2zsXT18+fHFP5R/HT7Z2f/v0Hk6KArgiaTBOgtRkGQLvCP6SB+D+BjNthFPjFAUQH/6CD5NMp8Q/0zAT1gFz2VuJclmYcMgZh7BjkCkSkNSt3J/oZgM+cjPhyj/a/xBDYjZbA5aS4/eWDe7cenz5/rJrqxVeCjxzfuHDlxIf/8GRtowRrL96DsOoVhplC35EFx8lbWIa1X4602JoG7JzwYcROrPJBUYBCyepsbcScGdg4qN/mA+0wa4Zfh+WCSDOg2ZGjbYVtil94Ecu8cAHX93vJZy8WKtAC7g/7Y0kPoZi1xuaR9UtXT8+mlVLtWCWjXmLFv6FYzabVZx/dVooR1oIcXx0ahqNuD4YGQ8PFDCcsDJ8PAvkPNRc7CrvBVvTfR17thKDDrDhUljUHvYTHKXxX5bJY7O0QTfzgi5XojKlc9DdXuAn9VQwB2Vd0HYDBf9gPfgXvk5KdWwvEK9CfXrusiEYv/2/eub81KfVsijrzx51Wm5lsW+ARIMQ8xNikXJ4ISB1WIJk69d/8GiLx30oZSkN0txYQ5omKHoNHl9cXJyC+LTQVS9anZ926KaIdz7O9f7S7kzRTvCIgUqQjbsHguXe+fnju8onZOMJwdPHq6Q///iuODEn8kpe5Q5Xjt9uFGdMJawuO+yUn96Ehp6lZYlWM+TA7S0UR9xOQJBJWIzlcRTr+87HFLUOyJ2IVbKd12p1qU9cpMJSEuUF+9TEWtkI6WiSxDCZ8XWLGE+KFN9kosKfBmkM9m+ozV45vHV3XM83c1Dg3s4C8ILfJ2CU/e7L74M7jsmQLCgelSPen0sQaLnY4fxjtl5oYWhuCo73GDRnUDYThoz/CjqBkfJJdvI5ges5NhkXyTkdyGRNB2VjUqOeJ3wszaZdFUPN7NjHdbntpIrKFP2sb+iONB7nwlSzfmktIKaLtvem7l85eP3d6/PL/lx9MlILWAvHX0KJcFGiPS/laCAFJIhCDdFggII50LNIBL2KoR+ZoLED5p7xKaAcGs7ghTL7k78wf+Y/qOVNkN4EpqUycPpRVT4CbmnC4I8WlxJqdMKOlZtvlKpCiLz+68+3fG8cluJrp165f+Jut97XWluDPEExQxSCmSsi1RFIAbpJqdxVMPnO7tahPADge/AbMJ4TB4IzoZ6rukYpyM2FWqn4pwW/EWFqLiFNhEqBJbtKCmJW2Axjtp4bwUkeMoJYSDSD8UpfPWCrgOex8oQIapGIQWogFMesKr7/TvQBMLWoQLiVqYK2c3Prq5rOnO+W60oEvaPki5JfStalFHBMU2jFatCX8mFrSzmyDdKgdbXHYLbBjMEsKckQqkS/rOD4U51g9sQS0yjmAce1f/plVtHYMDh0AKwf4wEzlzfVgAB82cL9955rYyD/Y/IHA/Y+YP5Ts1gJQRH/61pWFLTxy5f9dU/7PoDVFacDAmbC5QSOMBMw70zqaBkuZICkcFJdSIDTSPZHX40txnr4ID5o7Xar3iCV10UBHHAi3AER1ISAtHEjMUVShqNdE5qqABpyIuOEMiATgkFrbTTufbg09mRRffnL38YPtzSNruhphJfjk+SPnr5z68uPb5Vph9H8jk0iW0r0sfF7YOcMQGa16N30M9mGx83WND+nHvwIrNyHd/kPJJiBozLtHKubZTO/tTuv3SjEpJpMSRNDadr7sHHhCq6XgZgMmH4SUBcVhVODlB4TOa/qZDO3H1y4Im74ckxAp2hFLHMGgsbE5efXNc8YAsn/hT02rAMAnH97UOsji+dAv4YDwTTfrA2lrAWNLe5sz3JBUI0gMux6LRd0YNuj8mFHMALgmi85NdyVbpEJzZOsowj6S3tKzW+syIp7EGqY1IK1IAZrI+iRogiJooDDBlFWRkVioaS2448em/H/n8rnr588sB/335B8b+m0mMFwgk+ahHRBkc4CYDcSKEZxIxVEAQoFaUz1I0K2BSYlORg16hF+UaHES4HZEn0fIFmmBW9/MZ3vDcLQrG+nZBhNFuDUcA09rt4OhhbYaACoK9fjhs1tfPXjrO5d3Z9MRV4JLjojceaTbyUESS46Wt4EhsRNAebXmGMYxZX5c+CsriBBAIWO3GkAhpXi6V+3NZqfOHL985dzpsydeefX8bFaVZfHgweOvv7h97+43N766p7Ve31gjgtamt9ees23ygb0nTNPmBPoYcOMQCyb7aMaC1c6RPWXoZjz6b8SfI8ZnrLUaPpB7xmqmT54+dvzElhSAayfUZXOAAmuyThI3v3xgBOBcxNeMwDcjo3NpMQHIuaHXrwUqCkxQszWqATHp9UMFp5wWduuCGZedkYo7giLJ2AA5IJkFyzUuJOPKBC4IzkZIBUcNKGZoPAbxV4qYSGloNjYvIMWKbBHNduOZRGHPiN21MvJqML3wn7396tLK/4meTmFivQ39iIN+AgQhM/KVjvDSKcAfVY1Y9gfUzYbsp/7PrZkDPfAfImMK3x2oGzYJ0LtE7ij5Y1lQw0LTYhvAtgSAItZsKg1ziUW/GDa//KYY2cuNagN7DeibXzx4673L43BBK7z+9oVf/PVHdtWL3Fp/PC8zuIIhCCm2kmCKzX3DkfMBghwAUszcR0Af9H27oDjpA/zf7OtrQ66nnWfT8xdP/+RPv/ut9944dnwrtlsgJtrZmX3+yY3/8P/9+4/e/0IVXJSl1lVBhamXmKEJAMxklNkInym2JZ/hcIviLhBb3VggwZvF5hr5NEDC9MQBQMYEkoINp/IYkGI1nU1fffP8xtba9tPdDAE0sxHGaCJqGAfgrx48e7ytStbQbvLnYoDW5hpza6LGyUebMYDQK6zcsAruYja8IFg2EkAM7bdGJaeQkzCNAMeTFwpNR5A+diMhILJ/RtEBSHecKBl6oyMKbYdi0tpJ93DAfJTpA7QnxEpZN0CzZrF8gDgy+xmT8UXm7b3pO1fOX7+wnPJfKVSViPsG/Q/4jyeDQgyH/YTCz/5j+n/sCZN0Ak2xG/1dHoeMAXLEoVQTAsNooL0JQRnvobmYpoIAHbt7BWEgO/51WkDelkHoctn+AO6q9BdcUarPPrj1+//4nfFWgk+evXDizq0HRelEgSIjPiu8o/3cFWG7ij1D1C01WO4u6j1gWv9yAGXtwpQs891SlWsFrFA7qgp/+pc//It/8qPNI2t7u3p7OyONoRS/9c7V6+9e/eV/+t3//P/6j48fPV1bL6tKE6OwdrTaxD5vYQIL+irlhBDYdjtOINOt+8ntFB/63QdTDrPyH1MRhfQmV94cDqbcMcRkrXzj7QtGonVIjYK6HZhxAP7sd7eme7O1shSwj1gGtTwfTwrR2nYD2i6jWKhHh9IXDhcyr+OUI0Thb6e+7F1HmKUvQ+gSkIzuWWL+9YIOnAsZEuFBvFUA4fXoYhMc/8eMjkgTlKfusFVyjsqtoGgYwT51xNy8qoZi+rN3Xhu7/F/7q797/6Z1/Z0BvvxHYIL62t9Tg0imBB0thWl/IXhuV0IKEniet9ZM4j63SkFkzVSHDoSzMbbLEGZeoD8rR8vzPD/CLECZql4l1KrYk82q7xLZSYDjWrhdMKnroYuyvH/n8e0vx1wJPnvp+M0v75WTCUPL2l+x0qhgKlTzDwpmgC5E+imq8q4qEJ+VIx038tW996OXbB+zKKtCMFWuIVAEms30f/Uv/+L3/uj60yezZ0/3lFJNXMndnSmIfvB7b125ev7/8n/6N/fvPVrfmFRVBTtxkQuRdn3KuaOZ9WBobyAe9ZTgxKNGRP+kd7S7XRybwnNsEuAG4FrjyNHN0+fsAjCay/w+A2FDGPv84zvlpLCzQeWTtFf+MQFdmwLfZQd3ybky0jIL3ZDXrhG4obr2ag1OBcFbBPk8wbJNtjMA7biZcGxLjkGfKMSkRvBJuMjuHHh7dzg3ArcLSIqMXr/rhNwacIYgHwxE7WwujY9eCgUF8fZ09s4r569fPDt2+b/7078Xq78O9vFzYPMPqwtk/6HlWRXjnkTsAcQ1J4DE4jGIhmShFUa78k9SBfcvpoXmBNfaBIWO0Uz0Z8gBr2ulZp9YOi+3PJ38Fe17cL+b4QkrEQEUED4dKcRIhNl0dufGQ1WMUmEQabr65jmllBSv4aBSE4mYscdkjBeU+dsVuBbG9962rJQt3n3IUyqQ/ZWI8so92PxdKPGdQhVMqprhv/5f/6Mf/eT6o4d7BFKqTZfJvPaTx3unzhz/3/6P/+zMmROzvaoswtMqVooLl2Bk8xGMeeU/HGKlxJ/Qs3hOlPOUIqn5E9taWgv40BMwK6VmU33p6pnNI+tVpftAkU33jUHmy7J4/PDZo4fPVGG1+lnrEK0AgnYMFjP0hfAlipiFsDQFuJji84WG1SGo4nUki06w1qxFWarBWlOlSWuuYCeWGqQr0uBKU2V/Co9ue7jD/aL7G/7B5Ekv2u/B+ifx5bD4kcNG4KxvhJIaCS4/pSh/EvtqHQAIivBn776ueB4OemP5vzb52Qef3rz7YFIoVBqC/VmHh8M3/QfXAQPypBMf3KLxf1i5kP4gYd3Tlchci+PcoNxdGyjWfJLCKhFn8R9u0uxUg+I4Ov5Q+5/kiVMSlb+A3FF3ZLvAhxLXFeTRR/QmJRUvMPNinBQgUgV/+v6taqbHXAk+sVnNtDAm5NS9Nvq+FDyTwY788DP2w1Lm/5XNAWbfxsZ3myrIfZ8LRYpZMRU+Mcx2q//yv/3zH/7kraePp0WhenbXRaF2t6cnTx/77/71f3Hs+JHZDIUq5Osy+9zD4m+5xGs1Om3QV8yx5BsFHVBBWyJWUFLdiMTaF0t/S7E68MY7F1nxAu0c+aHTpCy//OTOzvYuKw7toxOO98Yf7m87h2IBFLCPlVFY0aQraA2jNmMjLDkxMgphSAIUDrO2b6QK34+GmRGvUeoZyCdJcA9N0DBvCb4EBuQbNm9L50aj4ZsUTRd86UVx6EeujAWMrvbO3vT6pXPXL58fv/z/5fsTpVBpcTzN8Q/HxKdeF+7NTJjkPjAguari43hDGL8KkOAiHDzgAqrWGe57ZYj4p5z9I1eDgs3zvFV+G4aTTwFtjQVCwBbbIXAokI7fXvxzQSF2Lp7uf8hL+1ngNXDbocuJuv3V/Xu3HheTYtGP7laCr1w7O5tqVooEMTHIF1gs21nXKuZE3FKcHJMG5B+OBXA8p0fCPuZ5lcsHPvSXqpzuVt/78fUf/uStJ4+nQ/seVfDO9vTM+eP/5J//hDS7d2RzjPLR32QFm3hcg8IBhuIogjv9Zj+75nSI7UeQzIn6TDAG8N1SNdPHT21defXMbM86AHNv/hrXSiTFvDedffrhLaVYAP0uWmkd+Ya4NWDyAIInk7iNIbjSXuDFgmwua3btV1nShiAK8YGoXi9jxQNC6yBSkRbaZxUQyd9r6ApJORwGpC7ck8hbwT0xD+vXEG1EzEgRRRXTn33n2rLKf6Xgj7M/Sq5XAyIukCSJWuyedExalXSguntw0IoT0HUM40gFrHq87hPr0fJTbitZTdPcjd70LusXAIh07TvxZjisHJNvtHTs1yDVm4i0TNmN/QrAinee7d35+mFRKmCE642Zrr55znV+Uqctku6kSJi/FvgE95HiHtJlDBtMlcspilkpZYEhE/3t/4UvgDa3Nv70n/5gNtM811ytKNSzp9Pv/PCNN995ZW+3KiwQVCgqTNBXXJgPolz0V8LFV0UevmJAYtsd4+XCwrIy9EzKzXgjBfpYIUgpNZ3qC5dOHju+Wc10x/ipRw4oSn72ZOfenUdFwWYTC3FhYcF/vyNKUYXhdwNsWQ2POIOgta/lpZ+U0B5gCTtEXBTBLIJQL5Cx3icP1P6Q+LcPgqGKb+jzZXD0t6fWyKO7AtaXo46uE6CYd6az65fPX798fmdvOnr5XyoFrSWwE2VcAYJBQF4+v1PlBF9jd3hkBPgQBWKgY0TadEwS7dVMVO8O9O0PUH2gm9bAv1CqQKOZgJb8iuC3gDBSS0B/KdIRg/6J0oeOiF2KvvjoziiFhqlAz146ubG1pjW54MaRuBcnOwFRd8CyD3Bh0VX0FjWxswJl2D6KRbkt4H6TIQpmpQz+o8q93eq9H7915tyx6V7FaqGC6g/+5DulKv3sQbFiKmz0d39cSgh/XGKTbYH74xg+SrYyPpEkMJo/WJCiRjZaXLx6uo5r8pAxgCeirJXlzS/vP3u6owoFced7OSB7sZl44UI7qD4ItXJBNa9BTagkCGOHwaQdpblKABwgGgb4+MU6ilYpOKNjWouWa7dOekFrCeygfmsnPbzrtGXERzLaHVghGk+JP/vOm2OX/2s/e//TG3furxVsYC6h8ONln4Gk6hfof/jUqRic/5A67ns8AR3S0y6CMBqNOjnLpOxCeOI8QfVxMWc7g3L4aSLJGOhPVc1tNNdJSxwxPaPhNzxxkrxbAPs0oJ2VODzBLgaIhC+PkxoHUJbqq0/ujLgSfObC0fNXTn3x8a3JWgFEajVMpKC0w92IYNwCQZUlXjgzSbErm6xMOQwFvgIWJB8LAQXURfncQLy2tvbOd17TGot8RMW8t1e98vq5S1fO3LpxvygLDSP1YgxezX42a2gjXA9/Nq0mPpHxweVax8WpbRmHj+OFLsRoXGobWf4PbWyuvfbW+dmsajU65p68ZACffHATWoMKBMsnEQg9EVRIxBGi4t+TFMIYiwXMCa+X6qg+YofFwQ7+tkDK0YzWIRPr5Zw3oRLG2m5HBV56CG5T26yf26MOYiWMySRhSrJFgUbYur04DZfW9t7snVcvXr8yevlvXH8N+IMwSkmnIG4lOF3u9t0AobYLBjnrzsPhYosHuhbzeLi9V4+dgO5VLQsfqXkxnoUAouZfCK5rFDW39cVB4cWAxJSBQpcQ5skUIMxAG9KqVI8fPrv91YNyUiyOAgFUlOr1d87rCoL7E0sWi5GQtTcRlE2P5gfc3P0x9b7bJPPTXQ8HufEvK8WqYFW4/yyKQs/o3LmTF6+cmi4ofmcIrxvlqTMndEVKFUxKThrke2DxiSwcRELNJ4aCOHKwUdEoWDCmFKno191Sm2KeTWcXLp86dfZYNa16JfJWFEgV6tnT3Rtf3i/LwhqYOODDmaF5gj8oGjWJ9SH2kuYgX0xqsxXlnic8PCwl+V7Ck4sQsHg/+NWkdR7m1HGV6rNP7ZHpmNfX9ZDbT1pCOhHeXXc9F6B2QDs4ER3n+qTTWGL8+XevK+axy/9Pbtx9sFYUclQuwR+RGOSAREewmxGwo0S0rsb6DwshWUddTstdV78jOwmgJiXgofhPo5iD6hvKaxfTnHB/U55AJD3fsMeCaN5rG2uNcN9YTBZR24YcETX08xr6xhcPFkJFZHyscO7Sycla6fbYwioAC0jHBHRX+Sqx1aWcsblngXI8R7ZQiaJAtikivKVQAodRrAouqhm+/wdvrW9OtMYoezWXr55VlDJBPdTjOamuC3EraWwjuFMhkrxVqVnNwSJATAuCyWUyO2M2+xXnL50oJwWGrzbWA0dZFvfvPn76eJsL44NgMUlob4jpFTtsDypGWaKKJDkitp5PHJjJQmomU3IKYcN0gIWIRplTLEA0zMwMCUjHczb56o0Rv8bbRkcFLLS+JXwh9IUUK6V2prPrr1y4/sr5nemY5f+TYPtVibm3jlE1Ctk3lqOQCRXJkEPuaQPN5TxHR6+N58PNdM8mhKdnJmhMBmoI7p/MtlAfeSUHqCfwV3upYNDsd23CBCCay4QfBNVWL9oN7Zg/2tHrKF3aA4pCffbBzd3tmVoYerQrwZdPnjp7dDbTiiPl+njeb1lYruyV9bFgzoSMYTg2LmpSIFKqhPZjGfTsuP9qNtXnLp769g9f29sdgVenmPd2q/d+7/VzF09VU13YJiBIePr373iiLIhABthRTuMhh2JyhOyTkPsRyUM0Ds4UsZyUr791IaP/045EcA4jAhWF+vjDm3vTmRNrFt1piOlWJj5Iv9sg4jJBWDgymqkiuBOQKMMIrlpqShVnBUQ8n1jHWBhp1fKBSFH+OxFHOk48FIH+kfB9RlMgZvfIbiAZfbFYZnRlly3/37uumIExy/+fv/+xK/91SvGEWPgS0FBE29WizI//gWS5AYiVgOQSwIh0T0EbbyV69kwGahSeT43sidYUEVOlWmYFjZ2ETkT/67Nfkq/s29UwjNP+bisn6v6dR7e+fFCujYACaY31rfK1ty86JXpOon9g70iGTETudHNeB/6oMDINpTQ7vj+TYiiROXzAtbU5NP3wj66PMOQIXY7e3Fr74U+u6xmUChtnLHfQ3DTCr6GZd0Xy46fO7yqiyZJrIPySs4QPxGaAUjybVmcunDh/+WSLAmjPUTAIYQG4VLYE8Qv/hiYftnwj8j5cgCFJ+4m0BOTqEMJvpBKRTIJdSnJqgBraAIoWtXI1WSizdMq1dgZ6geEaOJ3ZexKoe8/UUimnIo/CyMdjo+Yflvxz9cL1V0ZG/59s7zjufxVZPNYRMOgg5KG1X+wQ6L+mTMQXUS+duwbBznBm5XYYd6YB6sv6b+R55hhE8R+FgeF9zjzRsg8WI5e1yicy+dLxdzSJEG8Tg/aQai0fhZ5dvK4mptl09un7N0dcCb549ZRSJtgpUaeH/SYKMjeuZo+YoCRZQBScUkJ8d5EzTAvcyNcDQYVipSs6fvzo9e9c2dsdwfrG1W28uzN79wdXz186racouLB7Z6HqVypm9Csixco3LkpwlpRfV5ZYmY3+LM0eQ4LxYtdQxoSwqvS5iyc2Ntege2YxbrlWJ5Py1o1v7t95XEyKUAEK8o+GBqoIHPHiEGIPxSojBXDGgY7iYodkvWVAHnG9s8OaOLiJIX4ARfSUaOIrSyaRcbQXUvRytIHkI4tZKUtXy6hUB3wo2YGPo5I4CWBWzH/+vbdHR/9//v4nN+7cXzPaDzn0P0rM0M7ZU36TRMWpxUlskgUFqF2qQXj31It34hxbp+f+1zzDgEYpiAVSbyeSVP8GMp2kT8EBBfIqK5oc8y5kBYf15GnMlsNl9z3kraahueA7Nx5W0zFWghXPptX5yyePHt+qZiCO0QwJ7cfZ2c2EQ4SMkD9f/rty2A8AosjoFCDMvwtVVlNc/86VI8c2qpmmkRIcEekKW0fWXr9+cTZDUZRh9ziZA1NoDiyfVe4P1/ac3Ye3eBe5lsFjX9IyLJCriJnV1TfOOq7KwM/J6SVcFsWdmw9ns5kMlmHT1/P/Ha4S2EFx2Q650eIJpDoSieEIvg97wJa0JvBoIAPEJoPfqB5CLUMQ4nxQSzbS2yTd0m/A99OFvBTiZ28OzCy/D2tEpHb2ptevXrj+yoWxy3+D/hfC5leW/xb58eNf6EwLZQp/pPgPReV8VrLfu0JIq7YMKbN9QyIxiBbWR306BqArGTSPPtEt/NAtAtGF8cQOvmKzDpnDiQz1LQaFIkEIyDabIgkJqe4KACgnxa2v7t+/+2SElWCiaqaPndq88sbZ2bQSBT17DD8a70aOXewZ8UzxCIDY820sx19Q7z3pnom9/g9zAdDmkY3v/eGbVaXHKv/9tGO6p7/z49ePHt2EJrcCZj+gWA8uFCsybzWEfqFfJHeiKUwLXIekyD7Yz4eVKCxtuNeVPn5y65XXz82mM+5wAO7+ATPNZtUnv7vFBaEGber0MrM2UQ5hF6LGcokRwZoozLREURPdrumryQ3V2iRAVOpSMyWHBVHgzom6NX0eIIPxoxZN2KEccsYrjOYiFCixblOMwH4hpfjPv/fOEsr/j2/cub9WKkjZZyQGALWN0hZuVTixuUxpxVY5Xd/suPQ6K/emDrZ9GCB3iduu+rGkINq1H/qKBSHQOnUkE5GgnuIClbpcZMp8pFe3O/c6mWD7PGFWgj97/9ZYK8FEdPXNswyOOSupdLMB/5X4jqvuJbWmEKzKaH7gUCG/CxbU35hUqdR0V3/r+6+euXB0tlfRmPGfiGk2rc5ePPbu91+d7lZFYZaRlVk+ZuVzAEfrXWKM4baIrZyRx7VEl6MSzigFGpAZOysmZsWzqb5w6eTRY9ECcOctla+iQOWkuHv70a2v71tmMEcMCJKXjrycyDEmdSwW49n95EJ5uDIJ+a1K5ED/5jlZxCWN+wMdhyfEUjzJ3AFoKhyFIWWo4pESOmsuwQkMHZs5M7EqDPp/6frVJZT/f/f+pChQCZV/HVj/pt5HsIEU4qCgHJkKQo9GsM+Tzd6AwCXO74gJUQkFVkbq/gpxPR5QHw4nM4B5Ef/5EgZaUoVQViW5pOgHVylLOVjuaaE7ThRzIKIrHUJP1PN7zf8y3fzi3igLiG4l+MTG1gSaOOK5KxU0D2x8FHaOssj1nJlAjXe6CUEDwm/YFp4eyszEhVLQfOTIxvd+8sZsOnL5HyhPU/3eH7yxdXQDmgsVVnmtMmfYYg5GLoHj7yt6DrqegedD/jMKfxg3E5bvwUiFX3zl9BwZrp4DABRFcefmw53tPWUE4BCFZMiyGTWyvQj0cIQTkF3tDSYtcmCQ5JE4wiN36yChQaS1VSxS5j+Ym0/I50UiZZMjr2ct1ETpL+UMa9q3ntMcGSM56haxIv7z77+9lPL/7gNR/guuVCL2KVeChQBcrPHpzXPktnPtoqhfX2ile9bh/nqYTkuXPot1TRpBOQgoz9QZEOzHShLpyEtqPkeCEI4pV6tW0g8R5LgQzrOOFV3tCAG6nKhbXz148mi7KNUIwnDT6syFY+cun5pNtYp2WT2hX4VpAFmLc9E1S6V7Ueyb5sD+LVXYCvLfNBC8KqZ71Tvfv3p6GeW/bwL2qjMXjr77vavT3UqpQso/GDDKw0F2YOHoPcpLmnoXM1LyY/o9L3JDDqmsVwQBCYamjc311946X1Vhyi3A5t45QDz880/vBNF/F+wlBSRmSurgEhYCpJusshtZOdpJpCDgixqKhCbqfsN5qn47C5OytAstfIAz21h2JzmdT4Z/wIY16QnMDcWmX+xTqQAgO/T/1UvXr15cTvmvTPkvGZ/B/0tAPUh3voRYjJTByOw7gLiGiUWBKWEEDQF5GoUfmBIb1K4o38bqzofyBpx/AJiTe7oFkoSUFXfXMbQwAdbpjURiKVhqnrjKC4gGBqpQj755+uXHd0ddCb6ACh7flopmgt4uyJ0UJqhyUKzS7wf1TbFIHNkAMHFZlte+dWkc6mdrE/DdP3j9yNEN0mR30EiK/xSuUynEckA07QgWCZ7bE4+7Y/Jr2BczwnfVtLpw+eSpc8eqWZrneIAQnP0qSvXom2dffnqnnKhYBViMlmqAJAUNHedAx3GJTULLvEZFr11vRlymFuGRIfcg30xroUpfLwfhBtcx8uMRDOb8Matvs8QDGp/K7TdV+m9WZuXV/kMp9ec/WAL6/9uPb9w15J/Ax4VQ/hEIgp/pxLp4QZFbztgbyD+CDJaxA2eKteGGEjpb1IH6cj3FMIDrCQAD0msC7w+s/XttmcE3uDoh+FMsNS5oy4GPTV4nDkjlDSEZcLV1BdLQ+ouPbo+6EnyitFNlFm4mEc9dqiOoXNAvhKNLKKht01AYgqWKhNWKgtV0R7/65vlLr5+a7s6Wgf9ETcD5o+987+psD0VRcCYHBJxKkS3u3Udj/wH9+w+hguWBUkoskppsYGpLaHOc1SBfT24IH5NJefPGg8ePn5lpUF0eMyZ4IFQYVuQ9WVSUGqKIdIKjskZGFh3hzhkvlVDno5lfkY4H4kfoTLMggYsEdYhiB6REQYD+/SqL1PVIJwEQUOjOdLaU8n9Hkn8S2EcudvmxsJ3e12m4oFqzJ5sAZKkq0vJFnG7Opc+8xMO8xP/2kp/zLZoajvv3iOiNj2jbC8hfz6C09YUWu/Y6UOecQq3YpEz4usZqRiM3fjAuwXdufLO7PR1xJfj02WPVtAqgP0kJZ8GKEFiPEhYrXhnCy+uTDaNeFUcW/p5ao5QqvveHr1u746V+MekK1751oSgKQnCqETkg8JTYTbbJr62R22Bw/y5YxYtyHDbonLKQe2VFRGVZvH79vF6A5BqpQDPd/OqBE3yQEo/xdqx0luNYkSp1QpHlOuKC29pKRYC75ERzAuTIokijCR3SqPfOtT3VJgmyGrefBb5BHr6PbY2czlNuDqxkehAS4KwUL6X8/41b/a105LCmk/Vp8XcyP9dJ3KdoFzqyOZMGg5RxNc8yO5vqkPpOQD4dDCX+d0FAXcycdnfHHLaTIR/PPRmuo0DiBotqNFn+67AfKb60UGDRya9DF5Pi7s2Ht778ZsSV4FffvlBV4GC7KO4TIrsp5ne7xJZvfLsE2WTlcoCwilRCI0gVqpjt6lffOvfKm2f3dmaLeGP15oPOLr566tU3z832tCoKv4dM4m2LFMXWqoyCsIXTu1ZicUzmAKViNQjbUiieTfWZC8fPXT5pGbc9xrwtOUAp3tmZfvq7m2WhNKJwj0gKRi6Piv1zWNdfErZEtiyJfGCR01R3G0Icd7cNd092YoukFAXy4wF09Q0cJwOnZAhqoPpENkUi1qt6JmBSXNjy//IS0H+3+qurmvi2YwiKHiteBwqGB9bmwWdcq+cTRsHpKoB3xAwmtMmUciD+I0V+bK5FHdvh2FSvwW24LWeoUQg/6BwjxLIQOV5xmjkziuQR2T92eYwUt9w9qeUujA5yLkDqFeaIQLPZ7NP3bxTjrQRfuHqSOXU6dAKWYXdX1P4q0oBT7MmRctE3aEXYfxsaZmF/pNR7f/Q6M9Gyy393upTi9/7wdeV9IkX5H0lEWNIqeW9LARszp1hWJG5BQfzHlp3MrCt99uKJ9c1SazSBOz0nAQDKSXnr6wf375oFYJ0I0CJW0AfF+1lhEiAZl9YLQGLs9X7Xbws1CCB2xeu2uRly/9FQp4pYETALB7zBx3QSvpzmP5RbKrJT4pTLJryflQGCloX+G+HPUgkPtVjkJ/JXsDIPwUrKCT9QllOLmoxAHUXjZpOverjHvPhPdntsnnnAMMC7HevpzfkRhVTK28msIkN6+0JeyaifDU3yWeVcLmzmJENpLUbBWhV8+8bD2bgrwSe2dAUxupRLW5IYEx4gN2mVUBJ1AdRFf2UK58JzaZRSsz396vXzr1w7M91devnvP+ne7uyVa2euXjs73a0s/9PtKgduqHfEtG9YRnz2+1916VBFdsodyEJur6JgdfXa2VZRmt45AKwKZRaAmSMxKbF9ogUAlHSiGonTeUQOFOJhDHA6mUcyMQ5s85Z4jTzTh2p7XEF9AAm3B3KJ1y9nUeAeu/ltwgViC/sEFNNeklCqFomiNGDL/9eWRv5RlvoJL/QG4f+VKCaRnMN7nqGG7NaaFyaiqYks/P1+QIIL5dQ90eXh3l7Ld0L+DUZjQQsIPVAdWixPdA0SqHF+gFwHUB9AU+BGo+7/FaA+SFWvNB/osBL8uBxxJfj1M7M97U3SQxdta2E/OxOqyJH5lUpRIDs9NfGxCKaQrJRSpPn69y/vB/ofnytmeu8PXzNdiJJAluX/COVqm/CKSMGUWHiEFX4nwEd/Dz17QElXOHZ888rrZ2bTau5U539NMelZ9cnvbirFjqyZjJE0kp0SaQ2GsFYiPaLC6JAJTJrSrfQ60BOTDdFe+yOjKiNiSotHSzLnckgCiBJB7sBuce2p47CrgP5LnMcgdkaxyTxARXNgVSwH/X//4xt3fPmfWF1GtX9GwDgpRH0sIXKeOUh5iJGCXiYaI424jaV7ZjKcVvQdog4sz+cQl2DVL4rPKQgxT5LwgE3bNQ8h/aYhoCF3QyYOSRRWNc16gNXj1UIflADQElaCX3vnvCmKBfVTDHWjNWAP6QQKjR2ceo0dVYh5srD9YqVYVVOcuXDsyhun9/b2qfxPm4A3z053daGENpEt+Qs/oC7MtrCj8ZBNY4X3gFSBEGWPDwm9PNsnKZ5N9ZU3zh493msBuDOBmQXgm187a6CIVZysoKciy8lwMGiImSwc2XcnxWSO7tmO+0ughlG/qftmjlw4QDoAiKg7pLyJUVLdm9U9hZADJP4TvlMotbO3JPR/96d/9/7ERX8EsU9H/pGCqaEbcHsAwvoYqe2IGJ44F4jY6NExblsaBfQs7VumVFJJqV0Iur8xAKtecj59lZs7pSAwQCsu4UoTKGZVy8lWHP2dDiPC2liE5Ek+KKKNM0AT48YX90cJ/gYFuvjq6a2j67pCgH2CTjTHam5OD46cx7plyLBQ0WHlzdaZBK2IlSqqKb79+69uHV1DtZ/1v2gCfvJqocJHCE4GHBwCiKRgnET9hdO9nRILhwMb/e2BMrXLK2+c5QbQZ9A02C0AP9rd3mPFiRe7RswNTFV9EmVysyplPUeFSJxQ2EQyl0Xtko6RIc6UmNl0gdwNGttRgeSCAHOUEryBqesJILF+z/tMOQqKjAyOitmfAfdXPpeoQi2r/L8nyn/UinokZgBIeT46TuXa8qmQgUXkjJ3zDl0ZOB4RbAPOxVIeQfuzxvVsnAc4T+CWKI+2yUT7PdcrZ2QLk/QXWF7sCU3CgZvs/m1XOJl9Bud4Su1ubCawV9Bld4eXE3Xrq/tPHm1vbI4goK9n2Dq6fvr8sa8+uVeuKaeioojJGoTC3lZw4iGcg7Q5rI9Fi2PkJTZVUU31mQvH3nzv4u7uvpb/PttN96oLV0+eOnf0wZ0naqJIkwYRV4qUhlasNBETFEGTZnvw85/XKWCbGlFGfyurB43NzbWzF49XVcPAhut9eN4N2A/LP//kNpHU4BfibpDanvFGEPxibcayFJwWU3ESqGs/pHccet9FOXYPC1KpvcpSvqLF/VnEDhvCkK0xPcov4R2lHCjkwB/fCrgHFIXans7eef2VpZT/VvffCX9al8dYJDVB/82igLRjsyFfrHqEwX8LHuFpQkxejjzlgGZJCtyawztZHNzV+LU+klpnAG2VfC/PlmwzgX7ntKMdEbIpoNS6zfgx6boxpFCGCO28jsS8tHEJfvTg6Zcf35mMsxKMyZp67e0LWsPy252cWSC6xKh3bZlekK4lWEQxF0ipaoZv//7Vza3Jcyj/LQkGa+vluz96RVckyvnCv3MVm4WFjQfHIwkImJCEU0It1QHUXM1w7vKpM+ePVtMRfA7CAvCacjGDctLigkkWWUxA2zpdbn7JpjbD3qyvxtSRgKw8WzwgblLs4abyLSwmyplBUNZ2gp0qZnmas6RUzNuyhC/YuO+XuF0msGdShfL/h0tD/43rbzACTwQ+Y9E3HdO7dGL7lSx1xCcNNT+39joYnTQezncSfS0B+j+G+spBdy7tZkSE5jEXbh4ZZFyCUwUs4dNNtaZaCPZalz4tHQSEzhdF3T2gSX8+0kqwEUt45c2zG1trWlvZH0pdc+N9YCeQ6WUyldP3V5Huv+DYMOupPnPx2FvPqfwPk4C92VvvXTx9/mg1Q0z8DzlAUP6DDmiQkRDjECVsA2L+qIKm166fK0q1OFgHHRaAVaGCfnhsAwux0xthPuz2S+o/oniB11WJ9ZsRvc9YLyqnpTVlkOJInUzi+AERSvx7lXTvErV/GAZA+XpfxaTPgAUVRbE07r93/Y1Xf1MHzXiBzts9Jt8XpEK4DWE3NPdVPJAVe4j0Ibih7s6GafQO4n24nsk8oMX7CGpMjc82tH9IbonYPkhuJCRbAlJDyw6ENQnTx5qVA7KaueRfFygKdefGNztjrAQTk57poyc3jp/cRKXZ+IR59meq6aZi7/gglO9lPiOipKupC1VUU7r61tmN51f+27NTYXNr8u3fu2rcIqMhhyPzhDF44nogPqtXOgoDEmEWRuCyLM5eOO4xup7qb418UKabX97XTjuG4pIm2AAkm0UMysR9nVT3bilMp0PgSCwAfbBUNOH8nIv+FMd6/80YABLrXd5hRwx+IzjbU4DqcFAQe023wJQyT7hE9P/uN2tlASHqGZY+I51nQfYnSvwVkhlijh3UsKKac3JHFIuz0H3L/pekas0rBB09pHEkoJrHvoO3w1rDfOsAuNtQMuXvC/9I4cPt3X6j6Y+W675SIEj0dMJSGLqcqLs3vxnRJXhjc/LKm+dmrihWcmlSCkKQ93+v5QPLllFBB1QgKtC0dXT97R9cni5H+XlQE7C7O3vrvQunzx2tTA6QOJUN4gVTIY3DMh+ZMqiXWYFWSlUzfers0XOXj09j/IfnmgYrxbvb009/d7MojACcgAYQGww5Ij8Jg9JYIs4srCSK/4LZKWfWMeufiaiZAMoZPxYfaDBgQmAaW0AubaUDYV/+J/xOklygeBIQGgIlln6VKP+nS1v9/cBx//397WmgOkL/dbz6axmfiPfz5PZo1swLLsYn5sDIt2PZTeB8zd404u2t/YDBKFDGEGY+pc9eawSNDUbTc+tsd4uoFZBbAq4X19qLCBGFrOBvZA2jzKtdteD4oG62P53NPnn/5jgrwUyVxqtvn19bK2FIFcEhPaj3uO8XLIhATMo7fwkAvZArxIVSs1395nsXTp8/Uk0rep7x3zYB61uTb//eK3pqmgAhVeRXwFionwZc2cMHBXlzG7Es5nQgWFd49a1z65sTaPQ5/u1VZDkpb379wCx/WLagNAJO/KWDdCSS1UKKJ8C1Xd/UUzc/tkPDe5fSyzkkOcObZo5GwY3lporK/8BQk5W+BeHE4lhc/tvzo1L8Z7nl/yRe/XXlv5T30bH/u9Yx86dmAykNFtKZZyJhIM8E+hXmyY8a98RySSK37tsP6G95XG9DGAyDiZqShKR4SgPTeskfP5m2wL39h47PUzQ0CCrtNqoLjSBKF7rjViDAR2VZfPa7mzvPxhGGq6b61LkjR45tkCZWsWwKM3MU0CNipNfWDy5aYXBqoHOAN46sf+v3rjz38j9MAnZnb7534cyFY3qKwOO0Tr+FgHQsf5XCp3aeOX7t2WoKxfKSSl145cSA89KKqhSF+vR3N6ezmbuIxGQQ9YVB0mITLF5H1xFfxImDClRYBhIRV6Ixw5BhQIeqD9dTAgLEDwHyxO6+woXIdJ4hNUv5PjnsDQ/w/96H8n/3p7/8wKL/QdZflP9xJoDcBdOakpXQ1O8nKeo5E+E4bphSf+AWdYdcaK5PhtE19ZWSfO3yD/WpAEA1LaA5oH/dWz4Ijbmc8rY0Mu3omEsU84okgKcTc1VKjbqRaEQHb0iRroqSH3/z7NE3z4pyhFmwrvTmkbULV0/NTECMzH49qV8FX3hBsHBpoAiwuJCRUEpNd6s337tw6tyBKP99E7CxNXnlzTPVDEVh4r6Vqg6rv2JTLJ57B5G7YAQm1IF0RceObZy7eDy7ANxnGJDIf85m1e2b36iCHXwvywrUNUsolnomZz/nRZrB3nkusS8NPsD1ylF3yv4AnfdSJvpLTbeMFrGDHlWGfiagCRO3HRCkEjUIJ9fNCgk6RAxmXlb5/+mNew/WClH+E2p7AG4yHG11CWXQtLuDU4eOdbj9mc90UkgDfTIilggPZScBixH/BRo4dCqgBm38Dk8Vg9TlkIGJ4EXfdGIeScHSy9vkOcGWFPwTyA+56XBE5dYIdjEAwMzbz3Y//92tcjLOSjAzv/r2WaV886xkHAzfCe5ZcvzrS+BCyGqSQf+PHF3/1u9dPiDlv/+w06m+/oOLm0c2UBHLyYdFdQrnX5Z2PC7uJz2QmyQrVU315ddOHzu50AKwt7UtJ8X9u49vmQVgHax9Y6aAKFNyAgLUDckgXU1PbLuimxe9o3xn0OBYL6A/+cfrPYhZri9RSCgCCSAIShDZ9qH8//v3A/ofeX4hZw8ob3fnASDPi/1/jUhGgFPQLuroEvSfwsZXpx5DRt2ThwwDBqz7UmPSItXhA9kYzgcrQzTgnfWfh6mb0EGX2zOShRvGOBGeg6i/9pGdpH13bB0cXTWAJrDij3/79XRvBJo5K57OqgtXT24dWYd2LofS3Teq9AvBjCwiDD0i0hSFUrM9ffna6QNV/tuxx7Q6ff7Im989P93VStlVACmAmtCfQkPg/xCLNBn8A0B85Y0z88TEemcGFEXx6e9ubW/vMTOkcGydC5LI6YfRrxADiCXBKHIxyoUytjJBnVwfpGzBeJk4o/hIwduL84cgiOo1KTyTEuW/1ISQim/Kl//RKFiU/3+xpPL/jij/tbihI7n/dAvMUYCosb5NQhOHlI0Um+GuC663uwuaKvqewE5nUsjnA4WslnMbs7MLl2yY+daeLms2kPv1IKuI7KwdsU2AaM8tOYhq/s2IzPOEICgFMlE5UfduP3r6eFeVvLgwHGbYOrp26vxRPYMjv3MYnAlNOA6Wv75kFsKZfveGFBEXRXHtuxeqZfo+LtIEvPujy5tH1knDNzFydyGeA3vrEP/ZlQDKbKCCps3N9TMXj1ZVW8fDTQqJOfzxxlf3jHMvYhUYcoYSJOjCsUSor9+lDhwkUxnRDgFFmvKc35BskkqPFJ2TexldiY/dlloSNeRxieYBJtwT1Re7/G5XNBJQ8Jnd8hhUUaplov+e+w84wZ+4xg8szxT9j3ifFG+LIuHwppmXxI4Yez4Vp1E9/JsTNah6XOa5fb7iBQKmPnLQKQTUOIltqP+R8fKa0wW+yQem2SAmwPYRjCfYv4i1hOT7TvigkAMCsddv/5cVPXuy/fXn98ZaCS4nxdXrZ6HJaaF5J/TA7YlL4Kg6DjCIeXzB1R4uXzt15c1T073xfB/HqtOYqml16vzWte+en+6iKJQ3vVEcNQH2QmTpFK8kSubNBgulqhnOXTp2+tyR2bRi7jMga3tAWRZPHj+7+fWDcqIMTIx4MijGS8EzVwsvCsRCwJCKDtlrxpmqIyf9Q80b/aC+MjA5Nmc9+3ljL0Tlf9jtCvtcLFHsFP23+3mQWFAwBlBUFMsq/+8+WCsL2cM7FChBfnSqNE/1XSBKlF7TE2vKgw7yD+Vzshy3cM7dpZs7tAQIqMYCGqT3iUQiohb85/CWQRuHyNXm+bsLCavHC0JEXDByYwBnBmr7Q9IkdGMFQYmggU9++/VYM4DZTF+5dnpjcw2avA2WDHCO/BL41EIYLgirBUd1Vt/+/Ss0qvGLKkdrJZh5Oq3e/dGlza01VJzMPCTkpYwaqKA5RR2DeZjbeLj61pmiVANEqppCicZkUnzx6d1H3zxVhULq8061hiByqPbQDWKtt1hANIb7eXjy5QgMmDOdc4hAqRi9k6eykd0whSJuCQs5BxWPBJTdLhauFj5DqEJt783eefXSEsv/Svv7WKwG6TqyG5stS5DZ/Yg9jTBBpLlOWMlAcvMIf9ZMNxN1Z+ZWA+Gh14eU/gjXohp+CrocJDvsIqnGsG03manlhiDAomPqblo/xYRTcXsjmctJtl9QltbQ5UR9/fm9Z092VaEWXwmuZvroiY2jJzd15YUfpLSDL3gFO55VIg1t8Z9CzXb1lWsnL107MabxC+jel9ujoUlM1VSfPL957b3zsz3NSuz3Ssnr2vKoF0C1IxCPhoEnZXnmwtH5Ia8YdFXMX3x6W0uXRyQlovy3TnyhRAghSIw4F/3jcaEWOYbyxlIUGY20TwjEMDkp/9G4hsoMYbjsvd0R6o+A/luXmBz5B6nxbyj/1fLIP3e/WbO27577X1MBkm4wkqProd/E5y2a+iIR/xFieYlpc49Yj07hh34QUFNN37Lu25USlCiu57eEbEsSdfHV1nyiG3sOZHW1SKQdqfsXj+Bi//egDh7LfyBt/JVSTx8/u3f78ShcIGisb5ZXrp2qZtptdXk83PfbKnUF4LoWAjOUKop3/+CywXbHCdeKZ1P9y//59vbDqSpGelomXeHVt88UpeAGiuUG0dmYP3brjbkgEnxZUsyFnuHk2a2zl45JB2CeNwcoxTvb09s3HhZW/wdiiCSLDPJuX2Bh7ijRoShYaEcSgd/RRRRUMoVOVOlwBxrXJgdUa/0j5WdB/kEdLCICq9TAXSlSDFZQKpSlnhHkdbtVZAijimJnb3Z9qeW/1mG1PyDB/s7WkcyDdnzdgP5rSpTgUU8DWYSOo2webIFlwY5mI8am08kNTj3zQUAkrGbaBgNqiOZDp55/ryReg416wM9ImaARzysIvIVBm20FgzJoLPxJqWF0svNvn5Rpb2/2yW9vjLYSXOlX3jpTTkqGXYNSfmpmop5kQzrpY2XRocJTIWdTfeHq8Yuvj1b+Q1O5xrc+fvrNrd3P//5RORnHUIyZp3vV+avHLr9+arZrLOPtrlG01Jaw0KXpMTlDMcXVDFfeOL2+WSYLwO3SWU215GRS3vz6wZ07D8uJ0jEpwUUSHakK5hqFdHneyoI2dQBUJwX1gUTbGgCJAagU/a/jZLYvcIV93dpFgj+ecUZMHOkT2mEvorFw2AE2q79/sQzlnw8+vXH3m7VSSSceFwAE3C9sXoLiG6E2DdRZn69ov1sjBXhALdE8NQlAS50u7d2z2p/cGhIH5QOK8R/7K/1N4bs3g3ssEEgaXaMNZDz31RlatBSAk4tiSGTgBDEoeMH4Rj7ohugg/hirRkGXpRpxJXg21acvHT19/kg1Iw5NAEs+qDRVD0a4iY+Y5qvvnBmtTifigveeVR///Jv1reLL3zx+eGevmIz05CBW/O7vX2JVuCWvIAEdmCVuGGDgfpEbXAcAXlsrX3nrdFXpQWV/NgcAVBT8ye9uzmYVsS8EpRtIClRCKD9TXH9IhwBJ9xBTgUw507ARBlBj9ZmVIEMzCU8Yewl6T2gIEtv3iNzp0TgIuF/8SNBAI/Sfl1n+74TyX1sNlzAA8NsAofz3vE9BEPFSccHGORB6c4cyDuUR95/zUnxtc110MHzatR/aAv7QfECDTOEXAYjQkSEiTnXHq7uUoBv66ESdUSOyjAdFOl8BLELUQ4ZuQZX86JunY60EQ2Ntszh94ZiuSKnCwzt+GzaMfKUvmHdIJ1aq0DM6dW7r9e+eme5VY5X/k3X+8jePH93Zm2yonafVF/8wXhOgeLo7u/jG8UtvnJjualW4zyuQn9gaQbBdyQtCMCraPLp+8uxmNUOd8jTsKLBZANa3b32jFCPs7drrQguBEFFkerfAaDPAuYBpX/gDmbLJxQwduEANDUHT1d8kH4AYxmkW/rTp2Gj7cCTwQAjxRclNYJAk/wSQJ0jCqQT99+X/u0sp/+98s1YWMfc/uH2Rrrk8Jn+CFlByhuPULGeIFOM5hAzdk7gVuukz9+/EfyjlmfaXf2jWDlI9trh6for2xNAJ71BNIyjZGGjrOaSPp5gL+EV90d15wi8hlYpIyz0AUEzbz3Y+G28lmEAXXz9hpZKDdWJuEyoeC/tsoWe4/uMLG1vlWMrPpvz/9BcPywlDo5zw7U+e7j6ruBhttszM7/7eRaUKb/PLUYsjVT9FJ2SBL6WU0jM6f+XY+pFSV7prvtvVBIAma8X9u49ufn2/nKhIo8r/JS1CUKcNhgveuj/WMALhU5HW6BiSqxpZHugaEkSrv4LzI7eCSVnEmmtwkBnwpuSfZAvM23d69J939qbXX710/eqFpQh/FlnhT4SGIFIBdpYAEQNcp8o/uib5UI/FniIUVf31tQzOCz/0GQb0L+TR+MguFYg0MSgxem3y881K9NRBnkV6iObHxj4w4d9IjHkggClp9aYDSdh9EB183txlYsZD9u8ktZBS/Ml4K8Gzqb7w2vGjJzZQIQif1XFwMTKV6m/VFCfPHXntO2f2dscr/9f4y988fnx3r5gwNBUTfnhn78vfPJ6sM/QYCUY0AbNdXRSFr/FJiNyF7QdZcPptOKVeeetU+ynoeTjMAvAnH93a2d5TwgGYZJMaDKkJqf9T9FN/EcoFscgBOIIPwqi5rpNL7QhPy5BAxHo0xBCEqWC0+ovA+YnKfzjzojr5xy39qtj4xaD/SpVLQ//vPAjlP/zMxalDajf7ixz/qIEI5CK6hlQUC2hCIAxyrlqtdWRtOwHtQ1o7N+Zswhg69R2IAqm+wA46hlb9ZSGoXWMiMZ3MrwjHJZiUCUJi/0txRa8JLe/QqT36gTFpDV1M1N3xVoL1TG8dWztz6Ug1I6OWHCqHVBWnMFqYjg+jCqWg6fqPz6+PV/4Tk9a4+eETLsKNUE7401883Bu7CXjn986rwsINfg+grgUklUHtRLKijSNrZ68cnc30OGkPdOPL+6Zy1yS2AQXZzJU+OiGJwYcNTmjIQLwAbKAYySXNFvGR72O8N4rm6iiLJ4Pyyj9oIP8Ek4C4/Efd+lFu/6ps+c/K2n4tCf3/0JX/Tso/1PIUC3/qjJwrEiPHlP3hlDwQivtErKFR9597uLt05fOmJ6mjOkRt674tKQH5BDBX2d425c0ehuYGo10SSOZi4cKaLRMC6B/rRSO7zhnygReartuQEaCV4mdPdsZaCTbn5eyVo8EUzA4/6/iPj4V2LRYVHTm2/srbJ2Z7ejz0X935bPveVzuTNeULoGLCj+6O3ATM9qqzV46eOLOFGZQSTFBfSQq2q1yPKIpCV3Ty7Nbm0Qlm6KyCOlGgslRPHm3fuvGgnBRaR4zhOvwYKnm5F8ZpFRLF8cgCBNRnAdLTB3uxgMKn8gL9YQmgaUjguOQc1f4J7OPjO8WAjyD/KLkIlpT/rJT6i++/u/TyXxh5kDB/j2igOtniiImhkDodySTAOz1DgvMxfpLEXDTAO2iOyE3nebF134GDAdW/bG+9FIEkMQygh2bL/xw9CEaexbs/2kVe+ao6ti1OqWFhSBQygucHyT0AoxEUyjqtP/7t1+MU3MxVhYvXTqxvTqClJ6JU/8/Uwkqpag9X3j65eXRNz/Q4txcTAZ/87AE0kk539CYAGpP14s3vnalmJCTeAugvtAUiGooiRRVdfvNEzzFMew4wDsBffn734YNnYgMAsl5I3UOjwj/WK5TzIh9RODKEqXEIEYZmDQYvTeRoNBSLNfhIaEFnhD/J9QRxUPBxX6qSpxteCfqvovJ/qeh/yaL8R9gC07EIhBYSQFb5x51YjRjDI9QlH+pHGRHFRFKsMmV15ypvZhjQvvcxjNXTmD8abhzVOlLKFuxtkp8NFX4XxAT0Y/4kqJTQZcz4iEWQXk3mxeA8WiNb9fuFYA0CtC7Xiq8+vfPowTMvQrBIzK2m+viZjdMXj+gZCo7MsIwTFnNiCqaMDtr6kbW3fnS20hhF+ceU/7c/27792bPJOrsFJvgm4LFpAtbGmwTsVa9+59Sp81t6BjEETiXhnEeMXYaApvWttYuvH5vNRvjgJlh//MGNxPYjWgn10cFdCFowyeVOYrKJTmFZTMIGOoeXZue6aFr9pZAtkM93vvxHFoHw15Gr/VUy+I32eJ37o/KzGGTIP5EH5HLJP3cf2NVfeaK05+tq6QybLnH7BxByCjaxx2+0XOQPpLGB7646MCiC1wpzbtRxqyWeVnWI1pTAPWcA7c1nn9EuJBifIWPG988gvwFQfYc77Mggath12BIwk+BE2iXx+nCmY3JJUBX8+OHTW189GAcFAoqST17YIm3HAILpn/8yvo+vffvUiXMb1d5Iys+2/L9PqcuFrWiLkj775cPprh5LagIVNrbKN39wVs/CB48E7+pMUAN8nVjfOj7Rs74bAC2PKgr17Onu11/cL0trAODQfhNONEUTwxBRkhqCUqs7KeUPKUZCte0tNJRcLRry4N7Tbo/1Sz8v+SOuE4RE0E/jOxMbpc8s+cealqpC7Uyn119bUvn/4cQKPziiRpWIQCQnzSiASraHFJAPhPEY/aeM4oJk8IaqH60z4aYt4lb8J+B0SePQGskb3N65j4KQk4KYg7QzFN7RmeFB7rLv3ikLNO0kyXjOTk3ZIvJwCoxvyf6WG2Di1bV0ENNa3/jiHqtxIq+ucPHa8bIsCTHxMUffVcykafPI5NoPz8xGMn4BaLKmbn3y7M5n25N1lanxQcWEn9zfu//1djleE7C3W1399okT5zarKRLqZ2KH6f5H6YouvHa0vgDcpxmuf+qyLO7defz08bYqWMfpXzrHIVoWEV5eiDJBeGKWWSEjY9VJAG1hATXOA+rCn17+gWOxGDcKRpYeHsE7kQQ0K6MMqsJiRpCGZp9dwEoVxbLQ/3ve9Tem9Ei4P9L914bsJfwdYm4oNCVKwVGhmqzl1crubsnlQVzP9guYm6qAdrwoNqZE01tVqVxeO7DTqumGQemhDUZqKPnraQk6MXKRln06tYKG2BgR1mBeGkgsDgBR36Khi1J9+sGNne3xVoIvbp44v6lnpJQTwEkWYv0fVcz26Oq3Tx0/t1ZN9TjlP0gV9OVvHmmNJoUSMGmNj3/2DWE0vwFUWN8q3vzBGVRmJ1jV8a4I+wJPJuWla8f1GJ4HDCoK/viDG3vTKbGsMzSl5B/AiToIx1C/RSqEJTnFdiQ1Ob7cGwv/qBQUYUE3pwlkK8sQfwVdJMkWYZPIr25R2PMyThOu3odzchMYkXI4kkf/lSP/LKf8V0b4E2EDAInwp44EHgz6L0KakJKx3F1kpr61E2LkFpKTiSwaUztFjKhCz+xtIR0YdIv+DxoRt7cPHgLKMzCH1f7ozRZqtB+ImJ9o4A6luqC5A+TN3ij2A9CB+o+M5IecCol0on1CKSfq/p1Ht758UK4VowjDTTbVyXObuiKVKYTFFzFpWlsvXv/+qWo2DvrveT63P3tarFFVwTTM8g8AXaFcV7c/fXr702eTdTWoAG+lA+HK28e2jk1QUa32r336ijaPTo6fXR/lsxsBuM8+vl2UhRMMl6OfdLVFiMT5mUCo9K3nO+QOAUVWAYBBj+vXakYjiNFoEo7cCMFvdVEg/6A+FSAR4tMlEyZFkLV8OhNmpN4v5h8FfFYgg/7zX3z/nSWW/0L5h3L/dnm5iqp+IooIgRGaIwb/JDWfgPwUZcGKvvsxrahOQxjvwQNtnS2rvvBP5kKcHxpq1YTo8giT9gDI9BVkRRy1hLMplmuHV5ALvA4dLJ9yJpFENJ1Wt298U4xHjT/32pHIIz53g6pCVVM688qRY6fXquk4lTiAcsIf/6f7O0+mrCjiR9X+aFQf/fz+iE2AnmHjaHn5+vHZlKMRSMRDVGYBuJrx6ctb61uFnmvvIRltFKV6/PDZo4fPVKnSCRASqzjKrAHLySEnVncS59G+Nm+RPGwWeEAr7JOs8mYRIRcdTICWGJE3AGCv/+OJoSrd9lJFtvxH0OnYr/LfqTvUDCBjoqe2/l/IrPRR3BAIr0dzqjN0ewPuxW0Zt6o+RMsB1Ive04vX1mdLIBLyiwc2oQ9JnkzVIJgGKbchxpC59KAHjA3kDqZ4ycy6srQBhVB+Cs+UwvrRvFdU/O5hmoKZjPjsBCKogj55/8Zsphe/yFnxbIqzr25tnZh0cDpBxOraj06zGk2drZioh3f2Pv/1w3Kdq0qj+UtXulxXNz95fOvTp5P1YpwmgKmqcO2HJzc2C6rQDqUqRZfePMpMi6cfAGWpPvvo9s4zswAstcKRWwKQejGCb8ACLBLlZEAfOZbyR3Phz73JFj76h1+MpdyyfT+ZYE3Z6ZLd9ZVbYCQ2ALi2/KXYacN5bSpH/vn+0sg/se2XQHOdFITX/dc6UvGklLWbIfvX1rSRQXhypyiCdxoYOn3V+XnZ676NrvOcsoAIffoBKZg55wJBCuV3CUI0CZRmDWQ8nUMT1cWFrJOMDgMjHYrByPg19hOCLifFra/u37v1qJwUo6wEbx4tT17cmE3RQLMBK5ru6vOvb55/fXO6q0cZQRs46+Nf3Nt5tkcKllQh/5D5I6y1oX/3s3vQNBb7qNrD8bNrr3zr2HQXjR+KSVdY3ypOX96YTTFC0mWeTvXHH95UBQNyd6he+JPwjgobwmJByOkPAKkVEYedMqrbR0FqBGXwTDRAvsgTtTlMMf0BsuQfssgPxWa/7lj4PQBOpR2k0L8TLJf9gcgNqlA70+r6q5eXqPxjbb/q5b+u6f77LX5NWudknMKsX4xmclib4AkF5Z9G4Le3bk8vw966aTP1U4hr30bOdsbpzddv7tsSyWtazzlTlxa5iYZ1sGRCkKhxJVlBioJ6UqhGuhsgb2khKevTRugg3MSYFe0827399cOiVGOtBJ+6uNExKme+9qPToxm/gIqJ+ub29ue/elCusa50xkDPr9qZRZqqKtb51qeP7n75ZLJWjGSQSbMp3vjBybWtoknTgpmqGY6dWVs/Uo7SeaiSnz7ZvXfnsTl9nv4poEfy02C/Bw4pHCO9fNPLVUP4vKfE5EAW6miZ5bUBbogmkZYDxz5fFL+4W/2NvUGQGoFJiD/hgAqTOrcZYCmhlvyjloX+3xXCn9EAT4e9z2DtEov4Ewnuv5gZcBTfo79t9c892FrcRd7qvcSLLvU27jZ16TEY4KYcoLLSyv3gHd1kG9OlDNHhIFz7ZqpKl3KtQxOeSQlytzNSZRECcakJuHSGkTueIGL64uNbo1zoZiX4wrUjTfNVVizK/2q88r+4+cnj7Wd7VJAOQH/mj8wKs6r66sOHPJ5TWDW1TcBetglg0wHQhWtHRxGmhsakLL7+4t7Tp9uqSDaCIoVnXcN/yM57SQqGAzGFkImconQtMrj1YEbjklc9OPQAhUBiycunTXYFPtVqTz8qCAU+BSMXFVv+MufnxlH5v0z033P/Y4OXaPVXaoI67oLw6CQrCCH8Ye1RkkuAiYEXRA3itwQST/iAqbecJU5XvZse1u4cgP4QUCon1aoOLdRA0a3m1lm/54J58+Sg5RfRrBonnWBEYtDZOYGu4f6yr9eRGSS5hQAtCaBi5mzHDOWk+OLj2+OtBOPo6bWTFzfy7H6AFV/70akxfR8L3nk2/fiX91RJuqoQYn1+/Gtc1XRVFWvq03+4/+jOdjFRo7wZ3wRsHKk1ASaYVphsqHOvbc1mC+E/LJLfxx/elAog0QaRUxMmSIfZSHQ4+FFHIdhrkEh/F0S1STOEgGaBh8YDZ9KJqtn8JmGAQ/nvJD8VggyrisXFCMKPOc0B9fKfl13+e+5/xttdoP/pLW4PtBwIeqHIAPvEexqS/CMU+EDUfUqi5YmeIjwtiZ3n9PmaZzAQOgA0U8466UFpjNcNyJALtNnhcMurdgiUItMzpItgJBb3tQM3AF1782KjHN4sTEu1IFXyk0fPbn39oBxvJfjE+Q1d1c6aSw+nr2yOJ/2GtfXis1/d/+b2U1WSDf0e6ql3ANBAZeRUSGH72d6H/+nuaL4ITNUUx86unXtta7pnm4Doyqho6/hk6/hEVyO8WlGoZ0/3vv7ivhGAQ3L1JsnAzX0jM9G4LHAD4TjSx6MpqxjKebif6nawcQJpKu6QiMfE6p6IlH/cXa4Yth4NI1+WOm5KUZ0LFBFAVaz7Xyy5/BfCnzLQJ8o/vpDT9s72Zm5IRN+CLA3l6OicbvlG6BANV2fLxjRIIlcrqgNB5eIem2W12RF6ZQU1AP3vThE9ZCHyWFFWWbRlI0zIecq7MbyK1GfX5Lg9Sd53DaN1lyDSdQiIwpNYZwKt9Y3P76vRVoLpwrUjRclJfcjM1Qyvf+/EWAR8V/7PPvz5bRP9pWJWlAPE+Fd7g6WqKtf501/d/Wa8JoCYUNEr3z5uODmSGMNMsxnOv7a1tjHCxwdQlOrencdPn2wrleN3hhIQ9dY1YIkyvnMQlaWGJa9Yzzm3a8SBU9TWH8s9L8RzXRHpBTode7X7cJLHAZw+d8TCjck/iQCc0f1fXvl/z6H/khMojR51YtmgRfIVDsCUY6VIOxeOhSLQTv5pgu/RnQz6p42+RJ6Bg4HcbICJVW1OPoS9M4Dc2YIOZR6n2/hFqO+u+TJdItexeAtJ9+AaA0RyQb2PvKbaKgCgi1J99uEN6xK88BhgNtUnL24cTTj+TNVUHzu79sq3j0/HLP/LT39178Gdp2pCWjuEJwT6yv6BgIYAT7JjRdtP9z78+e2xmgBmmu7pC69vnX1tc7obk2tBRcnn3zgySvlPxgH4w5vTvSkzJ6qxkv/j075mufEbqAdiyTwqaWTVnigdSr5JjN1nokf7KDhzr7htL7C0loiSREb4k60yHLEKtb+KvL0SaT7pBSZcf5dQ/v+9Kf8rD+4CsvzPMXW16+lNMogMZmPGIKhpFZX8LCc4K3DyzRq83my42MT9R59kQL21HxpQIHBPrEhlB67RVz9xiCwo1OYBE9X0/X0oM4ITiO81UG3kKxp8jZjo4sVBw5aI0IURALHPEUWp7t95dOvr8VaC19WFa0eqKmy6MvNsijd+2EaSmaP8336y98HPb6qSKi1Ke1v+VzH+U9nvkFnCqTR0patynT/51Z1vbo/XBICI+c0fn05K2mqG42fXTl3cWHAAYPtcxTvbs88+vlOURQUde79EnhNB/gEZOWgKJjCJiXW4bnWGABq+tCECcVcPzwmqL+T+6+W/X/QNGg8S/Te/WFP+UUxKQdkZMnvj3zDpjTAfuRG2tNXfiSv/Vcz9l2I+DqbV9bo1MgaIfyojmYB3dCzNmtzOQI8KHSF19CrJufd+gOd19WkR0Cve155B9bpFOySdOyEhNCkOpcPuRmZQMqUI/C1kGwvfmMc7BE75R+p/o6b8kzLE5ahZA8Q0nVZ3bjxUxWiz2VMXN5Ly/8S59Ve+dXwsJU5oTNaKm58+fHD7aVEaGWxt47uYBAD1ObCN/iZbsKJnT/d+98vb5UjeOHbR4bXN869tTvfsooPZFDtxbn0yBv5DoLJUjx4+e/TwqSo4gvuFQ2hGC0suk6dChkmREQgIDTelSS1ZojYyo+D4t7OWq8YKBr5WDbv9LGfFqfCnF4VWLKa+DmUW9i+IaKBhOUAVamnl/+5P/14q/8DUHmn5r1PXXziZII/sJpRQt7/HlJXyi/qyeASTNXrsXmbNkoqap77caR7QDAEN3s3hRA0UrbTOZtZ/9Jnm04RoEoSo7eAK173GlCDoHbHaT+LoREL2OaruJbkokLshLij3IKX4k/dvVOOtBJ+8tLF5tDQrwab8f/W94+vjlf9mqerjf7jDCvGMNyS8hiGwt0rWGlWlZ8WEvvrowc6z6YhukaEJEB/37KtHRsmvZgH484/v2AVgiuoGiL4w3XFMRGQ5o/EpZMezJLfgat0XCm7kCMXlv8rGk8j1O9SkXhTaA8FxfPfIPhG5/V5Z/lsHT7H6u6Ty/7OI+y9kG8W/Y0vmGtab2sUm+DH7H3PADzgB87rJMB2nra0S78NZG8LnyayPDZgNqP6Sn/WNuogWMYQ41JkYok3MHBkUqfOXRiIakfey11GFIOd/qRJanAngVaYJ0OWauvX1g3u3HhUjrQRvHZ+cfXXLrAQbvczzbxyZTccyfsFkvbz56TdffnS/WONKRwV+MvuV0d/9GzYZEDS0Kun+7cef/OrO2ljKEIqmu/rca5sXXt8yAw9dYet4ee7q5ogLwJ98eJMLSra9ksiR7PrWoZ4gEC3kpRCvpqdrw7HwWLZvBzVqQuQp4LbKTLn/QgY4xH2kXobSDFJs+cb2XiQcGaQxpCqKnb1qaeW/X/316Kyu4XA6AEHkdP8FWzR2CmGSRsApHz2u0xMPgMxxa5FWbiLq1DNKez5o0aEbTPHsgwKpFkevYfPczNggM31veA6dWTNORjjpu0KuQUsBHyEEFy0I+4hW6+sp9JlImskgPcTMO89279wYbyWY6NyrW2akt7erX/nW8RPn1kdTfmYi0K//f19pXdmP4EF/CwFVmT/kBgBUJclAlfTbn329+2w2WhNApBS/8q3jurL7AacubmweLXU18gKwhmMLQId138Ah0bH9tAX9rXB0JPhWNwms5fUg3ZMRU+zkm4Sl9iQekSQr1n5ZuVGwVYJTcT0YL3Mxxcbu5KAeFQlCROQf2q/yHzWTd1eiROL+NWYn6mMACWJHdp814U9uLf257ZzJkN13OaB10XdAS9FTNCLzDKp1ktCpCYEmbkJdwyceA/QaJssmugZHJYaRFF0LgISGguc7KLdoJpdJtHSPcf7yWpMOYDFs2/jFR7dHWoniqsLx8xtrm0rPsLFVvPHDkyOW/2vr5dcfP/jq4/uTdaUrL/IDtwJWGb4/xYLQUR/gmgNAa42iVPduP/noH26vr5djycNN93D+ta3jZ9cMsHby4uY4uqcak7K48eX9Z0934gEAIVaAkBSTUCuyv2JyhDQIQnES3Jt1eGMWUJMyejrmTSdl8kdSA5Li1SRyHr+ySvUc/0JFLvCu/EeQpo02wmz5f3Vp6H+hUFVuwBtp/ef04Hz5H0TfAG8SGev1RZaDmY3LeBJZWwjoiMI9oi36PBLRgwdRPJOT27tdUIM4+EMQnnzgbp4noN72ok7KFlZeiQAQ4pGB4/V7+h6Je9amBLn1E5ghwRpQC4dY6TQDQJcT9eUnd5482i7KhTcCnC7CyUsbO0+mr3z7+PGzayOW/9D41d98qbWje8rtXxffK9KVtdqrYixITIntr1eVroqSfvOzr0ecBEBj40hx7Qcnp3t6sllceGOr+v+3965NkhzZdeA9nlnVwGCeGA7JGXI4DxFDUiNKoqTVrmlNpPhlf6FsbfVJuybJ1kwyfZBptbYy25WMNA1FzhvAADODd6Mb6PcDQKO7uqvCz36IcPfrHu4RHpERWdWNTGsDuqsyI+Phfh/n3ntOQyyUYLzzxnWbAgFB8iWOGC2zVBCi0EBPEdzXemT0W9FKAkng32si6eMEfan3qNM/RaEdw4/6ESNy45jzB23soWfBPCtcJAGvwn+YDf7s768T/t+5f7zpE3969N+mdeAQ/seD/9qIaNIwhG6d8Oz0D6FC/KyJHyCDq6J8kIUGfWXsW8YZILxrMWXDTDuRFsIOVI2j0H/Ql3CkVMAcrdxA9cJ3/XuRUN8q7MJdq1v+k4JwGBpg5ITMBp98/OnVd29vj5aAwsnN1nztWy9sL5klw3/y6Hh7/cpHH7xzZ3PJWKvj+g7naf/eRf0SekD9NIDzE44WQizZbLa4e/OTt169cXy8WBLw5DG/+UdffOGLR1/4yvEXXjxuzhY47GZrPr7/6IP3726OTA/0Y2bCyzt7ULT6FAutayp8sYEsOru4OYr5xG/wTehI6wHRjKhqPNHhf4RFIGr2950nyhnQGESATxL+C1Yc/XXNP9a38Cs530gCzNl9oehu3o6nw6ZtH6LD/1ihObWhSRsoeyNUMpnLU3d5jsvzyjgPXTWyX18hMPWijIUlna0flPMCilbeqGn8HyMf8mW9eO5bFOSvwSjH45uclI1lQy07LEjt/HjKjCR55e1bstBIMC1f+PLRt//elz//1UsL6j5uNrj8q1tnTUM4Qy/WStNdTov1R2WAyEN4suioTUjY0Irhe2/cso1dTC3S8tLnNt/+4y994cXjReYMaLk92ty4fv+Tjx+ajWEYB1SdnZ7oI6M+3XGHWC3yhTgboCiFWSUgmCxQyWIArKgHeCwJWto3eyAg6QVSIpEZQjfjw38moL9Jh8Ja3RhjVkP/297/aNzX5lR/bfiVBnZsDN2FcrEH8+DG+dWTS+qILAA1o3yfHCgIxJQMlUhO7aDAgOh8rWPY5qpTUBnTQK9SH70aTX9yuRQyH2FYxSxlPaQPk533bkn+gA7JQcvm1zY7oX3CnUdo0WBYCiiWYuCGgBA1/rthaagGNPgkwNy+fu/xwzNjdt0SAM7O+OXffu6FLx81p1YW033c3L316ZuvXtseG9s0nQNrfZso2jumciUQUCRgBwBItHVFwooYke2xufb+vQ/evfe7f+vFJydnWGAuuiuAP3nUnD2xi5gYA7l29Z6l3Xie/hAKxoi/nyDJZwmWAT1oF4nYwMWfW8KahAr5ncKhFiAqj+L4PpM+nygtUHbf6IYfEeOhHp8WhISgA5y1EkCE/xgRbIx5dNr8wbe/sW74r5l/rEb/JcLnJDCYKK6mJPy3EWtwVKNBvosklYJJQKSBsrBUB80oV1tLh0HO4k6yN0MlYlMEdnLCSKO4/xiRXO6z/Z4jjanmTi+RBtOEndnWI3oGiED84I2BHwnusA5GFT7fj2a1PnAnE39kbl//6OaSI8GbF758bBfCvkkeHZnXf3z14cPHgfKju5xutqtxXG86/LcdKNT4MTGr3yaBQ6Jpml/86AopyyYBX/iNS4vchG4A+O1bm02H/9jsiF+MBfWTAJGO+ceD0FZzx0ATT8WcVCHwJ7KtEpABbsh8ZoAk5vNzvxLr+kqYAfbRlOf6N0BLDiox8adJBEm9k4DBSsw/bfNPi/9I1PZjtdaj1YP5Kvy3KgFLKCAR6zS3QaDXc5YE8g8ECrofFH2gpr7NZoASfwAIqrfpCfdD/dBASgVRNO5aMi8r2Fs1NDByG5hD/ycgQlEvRq8JqcP9VenAAd/U6h/plHLgBI4oAzQqCeHZWXP5jesLjgRzse0l2+PN3VufvvXqh0fHprG2kc7EN2wasZa26ZotGk0AR0UD5+CgxlIp77kWDWvt0SVz9Z3bH7xz53ihdiBxfB2L2Jft0ebGtft3b7cNoL32QCYzvSSCaGysBZYtGNh+8MK0kDvQCDSUZFMn9J7wBxqcjgfEkrYfAduasGjWT10HdoCH8VhQogPjuR/EGHNyevbSt357FeafX7x51Fp/q5hZNNtjUHW3Sc+5HwSLRBwk4XaGqtaXmsh1fycHjWaP/Ac9OQFUyLuPNIfNRvYxtUJgZEi2uoD7JzJfVYQQLNXfBuzAuLgMszplZPJ/STR+taoAByRhLXsTKc44tSxp2MjNa/fPTi0Wa4hfLLzaGPP6j648/PQxjLgyL7t95qfsVUTfsEn+tE1BjViKzw+axs8GS0NhY+2rP3x/wSRguVsgZoNb1z8+PW3a0K8HEltJJlfce9BrUbPOxkTLPhfas1cizpSthnXF4Q5aWFUUNakrsXYgPDWQKgIb8bXcVOpL13s19Rvi8H8V4s+jn75x+dqte8cb08VjYoMuXxu1KbKHKMNn7H8zQ7/Sq9nDqTekvP95G1pbjJWKyYD4/dNYPLPcD5wOCOWPbkaBHdZJvxQEGkddS7/9rn+UKDdP0Ore4awSJhD2sgTfsuQVg5IZQmccbcoNQD//GbCg7dbc/PDe/dsPFhkJXvBltubTByfv/PLG9hiNbRzztcZwgulP6YBcw5TGf0hrxdWQHVFoY5vtJXP1nTsfvLtkErDIC5DmzL771k2zERtmvnr0n7nqoZ/ybUN4K5H6l9C1+VNzTKXqYJn5Lw61/0fNPEWnBuZCulAMaxkg2jnhbigMQepdsuNg8WiYm/5t8wZjNienZy9987dX7P23ntXHB1pWNV6JKvOG6fVA3tgVe4OVj41ImAFVDjq2733mnxoaOA5b2IlGmdWfGmrulKl/TCXZ54Bk2FjLv0yoFlDSHs5ScSwD3Sh9me5NvrnTFwDEeo1R5jgDtYQkI74g9c9QGICRk4dPLr95Y8GR4EWQ9KPjzbu/uvngk0fYwHX7dM087HT2VI9/O/Tbk4b3ShzWpejuv26ajBSxDe2rf/O+tbxASQBlc7S5c+vBjWv3N0eGNsz9iqvzdGo/0VpScKKWnXVrScM8OshkPyjsWYnRDc5S0BlYnVv3EBcEAvJjxHNSevg+dPpDxfgRIoQ+FzTcFLEBRYwxa/X+3753vN3SKjzHan1uq8J/m5vvVaq/8dBGXG531XvEVAIJPYZUsLCl9p3Fxhhm/QEnuISoBXWg+WcnCGhbrkpjsO0ndp+aYom9tZs/BEf7iyjsqEzAckMRu2YfWod+utQc9PApVfMGumYetCCPEUsxgeZXrBUDoWmji64vqE0LDGkJQ9UOJMJrV+5erPB/g5OHp7/44WVjSOswfYf4B/pr+iq39Mk/QNCJogKeOlIsxNC0anuA2Ea2R+balbv373z65a++sFgD6+4I2Mbcuv7x44ePjz5nmiZlE+4yIs0zSU0VJYTEGUNY7CWIwa199iKVkdWflwyLgB2GmjilG+MK5OES6H0MIukP1c9DrQLWhfmi9F5MGksaGJhHp2d/8J3feembv71O+L9x4bwexLbRHAAptlGjv3oSNFJjiFR/o2I8hDa+7yyU3TBipqGeGWSofI8hy5aChazr4QmHnmFuRhTBhp8ZZ/J9xmPzw9rCHDg4s3pKpRPQHI42ngvUYYJVjXxW8xl1AJHYABP3qwJusmxzZG58ePfBxycLjAQvFP4fX9q++eqHd29+sjk2Lsyns/5O5dE2pG7yaZglBersY0PNBsEwUdyIFfDk5PSXP726vUhpkIhcefdW6951qpokfJJJATXW7+d4FZuUJD4hqMZDt55FBDMF4z+q+QGVGWTtb9vwY3SzIOg8AbpKgGarjzAEdCzQSAaGvZLwiuH/nfvH2431xp252VPbRAKQ6XAnY46HJJNPXXaR9z/ThlED/nAgbK9o/nGDHTIDwOkTf84cBzOl8uy0ibB82SD3Fi3DnC0jMJkutn0eCJvp9XQTOf1n2+1hG9B/1ekZug7E+hkxrw7PLEtMaBslabHBJ/c+vfrurWVGgpcI/x89PH3tR++bLaxtQ6amreJ6ea9oBliyasB0VHHxdFjbOepqJG1TUEO7PTa/fvXDu7cebC9GLWSzNZ/cf3T18p2OAM51cOmxPqKAakKzSga2KFHNBtEKh7Y08XpHrv0zzRjyCKdDhr1lZ5B69+8w8XuSvwTmZ+MonU0nGBCRAsUEQc6gmI05eXL60u99fZXw/xcO/deE3FZN4FgbwrCA/ru+oI6WN+4moQv0E3wu5YfIVXqHmP0Ssa0xMIcyt5OnCN1gwqcxqUJgyrT/HMD9M0MDPYq4YpQ/dOfsuPvp0YzGnUCRtEsQ+fKDAGFs2MaAQEYfXPSweSIlr2YFLHn1nZtyARIAWh4db9985cM7Nz/eHsFx+3ROy0/2tpfTkv80dKmAZwES24ibEG4Jt1z12Nn9roDs2SNg+OjTk1/8+MpikvG73YTt0ebG9Y8+/viR2aINIaPSjnPz4oQEtS6QZGbB9IKOkokCgz/L+lEcQVXbFN+gtwHiVp+2lVMKJqIN/I2f84oDfGNE0kqALg7DyQmYjfmzP1mN+HNjrCr/SpjytTH6nwv/NfqvzT2Su6WZf9hn/vHOUhFpjAHpc8RYyiz/nGDX44PMwIEyl7QtD6EhOc+aQrj/rB2gPOlmSvVhUUDQRqH/LjePRoLj2gBb+LQl+4VpR4vZdnJAvHG3gG+KRQf0WysWAksDoQWN0ArRgv/oUGNrrdng1rWPFhkJ3jX8N3jy+Oz1n75vttLYKHL3THDRGGVMcqfvM7t5YEDoA0WBgDSysWLb2WojQkFjcXTJvPHqB3/nH33zi1/+XHN2zpUAQK5fvdfOcus2M+ulXULZUQJnOKiTRRUCkLkcVlR5yfeou0IYS6KwNl7QzNkKDtsQv0tC47+XhAwWH9q4SyYYhKsNIFQCuo8YYx6dnq6G/r9xtDG2CURvZJg/YUY/sI2ygjJzfH+Tub0IhYsrMCyg/yxg5RwBc/o1WmZbIViHyLOmAFERQUyxGIPI/wBoPw0UykD4sZzMQI6QU14t3SkfmNteL7bSiRQbNrloEYmwHP2kSUAcSavmCVQp1W6OcPv6/Zsf3l9kJHinyPd4c/3Kvbu3Ptls0TbsizDM7gZuH4/sO+hfmlgQWAH90uUHdKRALhv3qjKNpRWDh58+vghJgDF4/Ojsvbdvmi06Sqe0ccT22sVtVANgFP77sXGtLO7AZKZ2BUUpx6jPh8zB/fHcgJ7/ik1/Wlj27sHoT0UUZig4A0RocgcQEWKAP/uTP1yN+NOE1MsqhmdJVNrY6byL6t1NCFttUt1LEAGlFpgn9B8wu9PAH0yd5Mo2khZxG+rfFxGjzNDA0MmYQY5PZoj9SyY+704rvEKO67/XnVloS43FZ2zU8q9rClaFebFkHDWyHykAS0wCKt2MgJ8SsHoy+uzs7L03ri04Ejwr7hVSXvnrd61t/MBXkH4Mc79kBOufde4tFoVn6Pt03deixgK0dpiQ0ljbtEnAnZvnWQlIBoDDtVMpx6XiRY7pIeICsr3eAddGilAPiAnNWRr9dR2cQ+S9HAgO+/rv1AqRnv9HH9DZfUGeETrBMVR92BicPDl76VvfeOn3Vgn/j82mA3+sTeoy7PNAUAL6b+NJbRvY/0mb6c9KOWbYQ+oLCgED2N0CylwzcBvpmfm6Y42NlZk6M61Qt0KxeGBiYND3hUmPtHwQvfq1ATLCZRVpl9vVIYQIb416zeJAL5R2JXzciljVL6iO7/mkxVoSG7l17X5zfiPBbfPP1XduX3nn1tYxPzOMevlib1sBDoW2EPUH/NXGFKGqLKwyg4DOOvZQGPn0wcn7b906zySgHQC+8dHpWSOgjfRkk6piVHxUDz2RfmRUeupGw7IoTSCAi2IQjMR843t/+OPQ+I9r/xcNaivVF43/SDKV2pp/6Zp//sEfGlkF/Y/KvzaoPFKX7TzrJ9lidlH4L2Xer9CM3sK9kBL6H9XbkaF5GMHP4xCbqAZkkLKETvUKlAI3xfQuoPkNP2naULbxhQJy4fA1WFMhjYjekTSAxpzvgb1LqwR7ZrjOrFvHBmyDfjpDBhBiSbvZmhsf3L17jiPBEFJe/ut3G+srvcFwU8M7rgtIW3ZHhNd4bQBPyGtDxhM0YYKopG38QRrbbI7w+s+vPHp4ajbn4wn9ADCM2FgAQClLBaJhgdOKSBlBpDcKLrE2pJoljKP7rnNItR3mbUGxPRTjkDEkU/eCahPSvZ6i8gAtJBB1DXUtQzDm5MnpS9/6+ku/9/U1ev+j2m8bnSnKB1/+VSF8OhXMIOylgABdNY9betjnbIgnfjkeObNmAwY8rdR4MyU2LxaZOaOVqOhpRqkgbF2/v6jHVlkqsLnu32x5YKiWkDQuuVi+7y0ct5SI1vplUjZQw/1+GDgIidBD/8EatpZUjDx6+Pjym9fPZSS4Df+vvHP7/bdvbC+Zpun6/Z0nCLT+vhJAnxP4/3YKwK4diL7x3/X8SF8tsnFdQx2+tDnC7esfvfHqh+fDDEHZHm3u3Prkxof3t0dwxRzrof/Q9hvTiel6eF/HtEsOIJqIsg8kaLCAw/E73DhiYQu3al3C1LKjs2ZIJII7aEhS6eC4d0hj/RLzQosOew3wZ3/yR2Y5ODMQf9661w5/KejfBk8QJi2oerIlpYPuCEFtxBcQ0z8E496neaih+smQ08/o4eGu5G5JR6/ShJj5p+chtpR6Hq/S3HNumbsGCYjUVcAlN+IMQX+yW0/Xg5q5u9MDEIjjJWh/1iWD7Y9aNvvWE7RZM1tqTyEJS6IdEu7ADZhOGQpWxHTzwOK7gNr3dDHItffvnEv4D4i1fOWv37HWgvBGua/5RWkCJZyit9OSAHC0uXCoAigASDHoQAFChDSApYWAgCUgaGxjjvDKj9/73h9/Y7PBnl1hOwB88/rHjx49PnresEmlpKiZPOCqI1FBSDVAM0Z+mOOGj/rOPKSJYnRfaPKhVn7v1Q9SpCJqQTHRyWh8X9v9RC8s1R/vfmiAk8enf/Ddb770ra+fPF6a+PPVN463xto+249NFQjDIGYgIonQf4mUmcI9DcP+NrrvCe8/+w1CVX04ZQvGavNZjxQVmgXKJhRjjfb9z5kB3F8yDTnZZCGH8MTdc2NlhsFOpGIhQXqu32+mROPJal4XG/E7u9JS2g/uhSN9HhADCFSAMm0b/N748O6Djx7teySYsjna3L/z6Yfv394cwzZOypFUATuDILA0Sv2xmwujG/0lI4a4RlKBeDdT5j4oOoewlnazxZ0bH73x6gfnkgSQcuW9W+Ldc1z1tVmhU2aVABRQCdXsozwlwZgcIlgVZvcOxvpNpJwRoM8MgwgPghvyEj8ArCL9mIoSmhRIIvYIwPzpP/wjg8Wct+b9D+E/JRR121Wppr0UI59r8pE4/NdPTCSd0nNBKH0yFE1mcIjwRxIAh4MzAZmwGvWo0ThuMwsLngYBjWcxdgIJBJma5sgdlDqHVClYeqXgYutRf5vpVtL+rywjbCcwRvSNhaUK8F0BwEZM5Ck/vjH4+N6DDy7f3h7vdSS4JSV97cfvnTx6Igg9mm3Dj4d3mpbMWWjJptfV05Xhwp+GSkGezmdQiQfEk8Oh48iySwL2XwnYbM2DT06uXL7dDQBT2wyrm3cZyP5sTOeZThxJII9nkgKn8Cg5lN+isGd608LMJBnIFwAS1VnR+E9QBPPMEGk2IGqAoO39f3L6vW9/43vf+sbJ4yfGLBr+v/Km6/33cL9qLtHQP0N3sasMuwpO0nWlC4D9Hk3E/wjPaIzwp6aBh0Mmtx2ugC4JzINuRHKtnNPEGoevyGQo/sfI/cfKBoX35/s565hHW7KeoUwizabZ1zejRm+pXYIeL0l4aQNoQNWx7P+pA22xlvadX30o+wQ+WtT75oNfvXJle8lYG9E7x7ouVg/0OgfWWKbW3Lf6OIi/8Z0/jUvdu8mARECm1ZmxdrPF7Zsf/frVD46O95cE0PLoaHPl8u2PP3qIjXjgQGvLxtF9zPDRNpxTt//TjXRpKmgh6PVle6a84KOLmHPP9GuEB2VgSJDY/VRQXk0PYOyzfhrWGPzpP/zbK4T/7127c+/IGJeIqhFf7aaTJE0HhZq53e9jD/tYfTuZQ/+ZKcKMYPqVDTwV5paCofB8RkyPBRih2wwgU/Oi1kgdZIDId//YIa/AohHPCw+oZk/mMgmrQjaXPUY92mpL26Syp9MU3devxkusKKxcgq331t+r7NLSmiN8+P6thw+emM2eUCCS22Pz6o/e+fTBIzEeLtXtOg6u8SccCgNefdWPdIUfWjU34JyBnwVT1WDdSNoxTzRWGjF8+1fXrOXe+mLblr/3373VdFwX7fyoVQ27mnNAL+b25mgacGf9A4eEiw+QcBcm0U1vfaNs/dGrJ/vtHjF6SpiXj1iLe7F8XCRk0uKJXOWuY40WY3Dy+Mn3vv073/v2OuG/ARX3Suj+TOA3j/tTo/82DGmIROg/+1Q/iMTYGBOG9YAKzjLru9YDakCbmU64xgmErzVD8XuRvT/rNYo4kU0+EqfNMlIh6BXK0kyiXBVg1GfRjwGjOpSKSURj/wEFaoIRCaNVQS+F1hojn3zy8M7Nj/bUCE/ZHm1uX//kVy9fObrkZN81LBMYIBpSEat7069UX8jEEzTWduWEllTOJpWDTlRAtYq6ltPGNkfH5oPLt668c+toX5WAVgH4xvX7ZmPcWcW9JlE3l6tFBjZ6m7Sc6QbnLiJAVPANEASSIqJLbQd4HZDFfKBJ4L2urQ7SY7obpPVFZ/qHpAU0TKQyD4M1wv+jn/76vQ9v39O9/zrMJyMFUr0X9bR+Hv3XMp2SEH9SmdGCTc8C+ih32OffyRGDzsXR/DlOqXTk2kGwuMg6VIzNWvD8gLES6SiI50lRdZKJY0i+rv+FNikoeBJQRtqQosSzFOeltneuHmA1iUn7K8jjx0/e+fWH+2mAacP/1392+dNPH2Ij1p2Jjs1D/BvcFRunDxMRwCWEoOJvgp8KdjlWl1i4n3cK8p1IpHW0GWf27Gd/8/aELrPdbsXR0eb6tXu3bt7fbGH92Sr6biUibq0a8lIxgY3FwkR/KgnY4y6dXu1rQPkLJbgfQyrBySyxtzuJTU8Cwf73In0nRczGnJw8+d53fud73/mdpcP/xz945Y2jjYmaziLld/c00gHgaJY0W1uUJAlDD6SRmJMqmoge79fJWEzmBF7mKTsOR+rpzFp9mbeiq0CHTYPzujlbXEMN1H9cQ2/u4/62nFLYXgk5zhJiACrg/oH0S+/zhBbCxsCXlgrRCWr7tsZDmF4xsbHNZov33rp28vDUmNVpIcwGjz598t4b1zZbNE3TUnt6EEZT+rgQS3f0KxSrhwX5IbLgBiTCu8IRwj2xqoOosY09Ot5cfvvG++/curR+EkDKZoN33rp+enYmSATuaQP2HCBnSUbBGYhjGTTj3BqClwLtV2htEvgXUeUen0+wbYlJCiE8+qUF9MEc06sJq3pxdHB4FkboOUkD/Ok/+jsrhf/HZkPF/RAZfW3xFTNE4H33k9fdZrbKXKHH+BXTvQxdDAryv/OKw8sObU1v7Sl4GmRm0xDTQWesexbxT+xsX7Z3hP1tqLOoOErMXu9dAj/pRuJ82mLbPvfO5FtVVEpIgKmjRd28JAHzYcBJOoJl37bW/cRscP/eJx/df7jdmlVtHi0vPbf91ctXbly/Z47QsIf/tN07cqakHxnN9AZtd6udASOiN+UqdPU4biJqWnLpcMyOUPrMNj/967f2IBkPyNmZvXH9XjcA7JUPtCP3EF9s962G75EZcCfayEMVo1oFGEhGBqA0+otykw8kH8V7/riBgTHEWohM0oJC8qGMngFOHj/53nfXCP+f/LeXf31koFaH9QPmHvBRCtzClETGBgpHRdGUtOkmLYFRU1ZMHJNxCeQgMCSD9ct1wB/Koo2hGQ3pAQioHtvhmKBXvbyMahgtiqT1+v31sy/L0DPVGbYiEmTdfRbKQCsV9yVYNQCsuCLUTECQTWcjhg8fnlx+68O1ywBmg4efPvn5D9/cHIm1sa5L1OXpChjSKE5/VenVXUwSEUd7JN0mgvI6n5C4DVRhUI1tji6Z9965fnnlJICUo6PN3dufXPvw7uYIje9Q6iocjHsEaEPBX2xsdWzURNBJffWgxdDTaRMGiBwnhKr3xkszFA9QxnwGm0v6rRISk7slVj9juiAiRuRP/4c/Xrz55ye/eufarbvHmw2bJp606Q9jWDcOFvXipa0p1sbt/+ovmeYfGefbGb5g3cSZWPMJJEkT7fjIM8AM4d8Bz2bqe/w5WrCNJJfTIm9uZKzUN1pQhSw5JEa3jdHsmJ/O1H0aVqKKnz/jJgsEeQF06zJYKo5lS6Vg1HbBG771q6unTxqs1gFju/D//Vs37m22aGzowKEH95mOaKlmUD/HYClsQm+rJ4zTmEnTqrKGOiojXQFNFKGGkF1yYJuf/vWbq0rGtwPAb791/eHDx2LEK9VQmmDxfXOJp/bTWQJ77LNULOJxzEnEHCTMRllMoi8OFAOYskZb5N/n+naiQJ5Zy5CeELK72kAenTz53nd/9w+++7vLo/8v/+poY9iKPoZ4X91vPYIZKm6qDdQmDB1KaSHcNNvR8KEX/id4uiRyLj0HUTKnw1qMw2NiiMQf5/RxLlA3LkqMbVmsHXNWkZk5SquR6WfGbQoMc3xIehzc8yQSRm/HT4BotySKMY4HCp41QjoaKaUe4wi/Wi0RRZcNS0KkIdEJxQAQa6WBALQQawWw1mxx88bdBw9OPv/555qzVQzfZoOHnz752d+8aVrrn23kj0w/VW+on1+zpBCWTLNoOICjvVctmGUFAhrSolNfMgJLBzSzcTTFALvmbLDZHm2uvn/r7p0HL37186ersaWS8sHVOx2Thy9E05l+Kv4+lwpEDFQI48BEVBWLVAEixuHIygcqcgaxIyk3gFJTpqQl5cLOypELMRGJLHwl4zIp2wfrfOef/5O/L25XLBP+P3fpL376y2u3779w6cieufA/6Khq2S+XRatRy6gOaDOYnNu+IoioWTkA9eQD7TpihhHwJwsWceY6zo1tTKxPVLUIoZ8BDHdzjnA/ZCicqYpjU7CgEsEnZbD3NKF/6ItWpsNl+tw8A7BEei9NaFrukGXGVKCqGNBF3xZGPn3w8IPLN7dHG7sCCmQtjy9tX3/58s0bdzbbFv1v1PRv2qEf9Sn5gV4/ZGmp5nipePObbl/6fzL0AqkeUG9kqaXku6EwWsI+PDl5+cfvrCcZv92aTz559OG125ujNhny0X2w+zYimxfXEevXSOAf8FXfZBjYsX72cvWSAtRg+/8A5jOUKwhyxQZJmSOzszQ9egIDPDp5/E//xz/+w9//vYXD/4ePf/DzXx0Z42hnGc/kSSB+oEL5Je4CsTE5k/g+jp7qi7uDDGSfeeLPOXE0MamwO7nAu1iAPwtJzqp1lUChUU6ejP0dogOyWaEZ9f8iUJQ08GSfjmsZshJagrrpIEmmQ+MBUYkaBy0DI4nDuK0yprqqpXCPN3/5/kr2DpCm4RuvvS+GcatP47g8Gx3zBoGXEIAxYDguGIuzh3YuoKE/WpDscwiYKgCEoWKtKSaNnwl47ZV3b938+Ohos/gtsZZHR5vL7928f/8Ts4HV0w+hvZX+GrXHopTA5m6129AO5K0/e//NEZJgqBiXhP8jYtnFYqQfCkO2gBwbjR47O/Dkyelvfe3F/+Wf/eOTkycwy6RmtHzu0qWf/PLtazfvHm+Mi0CaWP7FPwGJywBCvS8l2/ivZ8GSVlHmai85Q8lFZrUGSrizjPiuWwNTiYBUBlBLAzFLG3KIDiirIJ+9oZQyga4npA6Abewn6EtMbgOmvEAqxLC+TuiGnpoAjvuumCbi0gkEao21zWaLK5evf/rgyWZjlm0GbdH/y29fv/Le9e3x5sy6oJtnmrKt8wexgBc7+v52Jiya4fIdQY4UutH7tQllA7YNpgpDT1MNOsl47xVg+ODBw5/96K2j41WSAEDee/dao77RxtLHXtdMtQI7gU9YRSMeon4b9yMQafwZVCH15Jcq7bJgx7X1p6TFxbRByOgfm6jXPYwaMGPUODQn2R7i7Ozsn/5Pf++Fzz3XNHYR80+RzQYPHp784Ge/OtqYLhsMgzQJA3eYTw/YpKj5IKsDS337rSf7jBEuV+nod9OnHVn1/fi9sa9xHF92+IOCpuNieyXlAsp37LB+PGDQKySl4ELHTm9yOCH/TtuJ4q/OLXvmh9ES/T7RzR4SqzyqHlBpi8NhgN2hJTYAzZ4LgWIbNrLhxx8/uH3j7uK9QC34+aMfvH7anEbN/tSM/466x/P1swNkvBpM40Z2GYvDOAFIauzIbVAtiGYjomlpKImesNcbaM5sc3Rp84uX37114+Oj44WTAGPw6NHptWt3zQYNz0L52g/36kwoCBon+nHUE3+MW87aqkCy6oj+BvATA0Xrn65d1DTutXsELLf1lWsMknaJduG/nJ2dvfiVL/7d77/0+PHpUt0KXfj/+lvXbt053hrHHeWtv5r8CrMlih8iUgRTYm62N/SD2Gd6hgyREQXCAYafTKIwLbaPG7Em4jPkoMXG2J+ZLseM2fJEPZU2ytAGGH8Gf1N852Aaoae5yspkjLSAg34EPb+zp25nEvzZZD7IKiJh/SeWVWk0FtTGoSJ8/PjkjV9d3mywoLlrw/9337z29ptXW+GXLvaXvpi7avqkxnAa303dScZTCSAns3jBDVDpA1PpxUeqkzaQY3clgYZNQ9vQipFPPv30Jz9842hRj0jy6Hjz4Yd3rt247QaAm9CYpEiwGRP/qVXhjI1uHqOeMyTz+H6PEg5F3rakXYGhoaEA1mfqv71Motdx18ansfR8Cty2BsoAT56c/u43fvOLX3jh7OxsmdpvCP9/ebzZOJJZpSzXAoo+0LLqDYm8N3sSsGBvvIuZJkFtf6mKkTOKqMzmAqPWfyj0xvJVgZ3wHym3gZZj/UErz/yslkhpbiy9bWPEcCNMdGrQtzeNzGDfde2PFGnC5teUcFbiTgX9pxG2VDkeMNc6WY09M1u8/cb7jx6eGrMYCtQKv/zwr35xxjMG/jVreaZkvJpYuddqCTM/1eU7YUJyEzs56WiRJAxGMJKHbLnh/DyE9Ra/4w1tmiBD1pzZ06NLm1dfefvm9Y8WrASQsjV4882rp2enBBPJYv2XmNzC5wSNCvl9DTaaEleNxs44IWo97mu5lEJ1DpeCc2zSjErNA3IlvvxZmH5iBm396le/vGCncgj/b9w52hjbNB0c2HUmR0RTonIwBfs4ghVd+NXqnKL+a0XJBrBwc5AbusO4ueYSxYB627305Ff9yZspwA4LuMt44F9sJSJZq/0bxX2ZrqH+Z5myh0tYUzaUoFULgtUpDhUnYWfZvYHsi+u2qUDjwt7GGLl79/5H9x8sNRLc6j6+/97Nt9+8enxsGnsWJrNC+00TsKC2PKB43ILtDiwODSOaVUaukaGVnlHUT90L1NA2qspqaRvR59P9geEnDz59+80PFqwEAHLW8MNrt8VIY5vGPw6hVcMKHtfSJUWbjCRBsQO10qFgzDRPh++zP83LQcnfSLYcZeWvzEcSQmfmfQmk4H/avmd/ltGow7e/+fXFrH8X/j/6wY9fO9oYe9ZE7RHKuMe2PsrB4n5/r7cUF1+YKXjkZb/8Q5vKzJMxlRwH7qUKmcFomWH9zp8oAyjKdg3XWjnQn9NHb2x+iDdsrAG6aaZZQzLvl3MVqTpY6DgST0BHMkwEh58r69eejLWBMVga96dTAWt056VVM7TW0siDTx/++pfvbrdYxN61e+xXr71zevpEBftncRXaKQAHspXGNSY5kUgGVYM2bLeSorOuutvx/is1Mfdb51ca8d2falSYSnHeKQo0ttkemZ/85I2Hnz7ZLCEU0w4AX79+7+qHNzdHxrFAezGRJoy8iXNR6tK8FqYGFOiFo+Pl19WEi7O0xdgxnf6FFMleSpk2yngxo86eDENOpkEvREFnZ83C4f9rb314804n++VCBSo2Rd+LqyWIUukNUcow3ZaF2twQPYwX8WP3+NRkkpEs2dZ6uccq8w0Z7CvdsWg8WiHoQUBxs84g9X9eM5v1lA9SpxNQbB8dwf01+WekH+qWfHBFoT7dRfkpR1gjvh9USYQpHnxGzMmt1bM2CnulufbhTUB2n+Ag5fh4c/P6/Z//9NebS+bMNo00ja64OrPe0PqfN74J0l2I33aBD1noTLz0CwA2mZxSNBJuJLjRdBruV40nyXDa8c0Zz8wW167feuXlt597bmvt7veE2625fef+g4cP0eE/TXfJIey0QSOhPTfYgDgwFYrx+aLVwgABY9Fy461BZ8YwI2vHKVnrr/l8kkihQF7AfKKb8GIyfbun1HdXvN1ulgv/zacPH/23H/+iG/3tnGzjCr+NaCqpQMlqQ6+n9xaWiQhbN60pCgGOafUy6P/QGN5UU74O7BMe/NrIj/Q05cMfU3E/8pa/D7eQxUmxMv1/ouySbe6yWVoIkmWYyNG86OpxlE9YirU2GjoUrRiuRxLZJAVwceKI1J2XPLM8s9Za2/kAAR88+PTx47PdkdbW2P3ytXc/+eQBDK09tfbMdn0+XfTd2A72YahRU3N22tDDE40+OKC/UWRdTSgACF3F2FfrvLBMiOh8VVwDU41YVwduOeMa2cgvfvH2kydnS6HPH338gB35RNOExKihTneoewG8JxOJgAY6DdoO5dfNwUWIP8oeuhg/E7mAMjLhNYjq5H9FxUyUJS9jQnuoKS1I3rl7f6nw/9Lx0Y9effPajTvHG9M+h66TtumYQbxfjiXaxIsVOU8QqyxDeWEt/OJ8g82i/2RFRD2jWahgUrnnou6Sr225L2pGzoPCfHvrwzPHR3/J5gkkekqeRCvYFNsRTUNBzyZBel0quDHB9lfd6L6QgFiKgTRCI9bQWFgIDNlWF9uCifXFE4BiLWEAq4T4KE0bD0PEbHDt2o2HD598rm213vnZXb92i2KtbRpPd+PUGRUCE0YBXJzeKDegtI7DRLRldJNDAAaB0FBoYCzFoAUAjQUhNGzo7ltbV+mCXNoWxUV4UJ0bMRvcunP/4cMnzz+/zD15/+qN9m40UbmbnQCyJxmIWKwZtA0k5EaeGoTRUoyCGGeNkO/tGekCQvbnaU87+hABei6n93sIQ9mC3fKnJwEC1cRPGxhcuXJtd3NCEWPMo5PH//0nrx0ZuF6wVJFT4Y56wtLq/tR2JwpUgbcvBaPI4Ji1+LWjvyUgjhObhbJ8/eV3Fx3VJN8wP53pOQCWZ9knfzdr3k+VmzF6G2MX0j1jU8BB1eGKvyUdeTp9Gax1BgjPriNGsc4rGJJEyztlCfjAyYIitl2fLQeJY7+Jl097CCsbs3nw8OGd2/e++N1vnJ1xdsxLijE4OTm9ees2Nmx45gLbhin9Z6NrvAqToSPIlKj5nYr0JpQ2u8lSVzQUCCwtYBpaA9OSlRmKhRE2xmmyQkJvnnH+UNpu487zEjAPHn56585H3/728zvdExFjzMnJ6a07d80GZ9090RR4pG89oZ/z6AobEgEKQWeCCBODzMAtEmscxerkRetPKcyFTTA2yNkNXZPoOIgYXBc79DwA/yQI0orFdmNu3br76OSxMWYXFiCSl46P3r78wY2bd463GzdtorkfLDPd/daV5xTcrxLsLlazmhEb3RW5VZqO/ro15sK/XTCfOcZ0uvXGKl9RbIIqFYE5hwXIeq6fkUyKqhRcAzSlt0J1bffpfRzWz0xJIBGUi1u6O4tg1ai/HhOlUvsKPZGMplkcOuR74RUhj1jLM4p9dPLw5Zdf32ywy9Ml7fHx5vJ7165evb45wpk9axuNutmuqPraJQRNrO5rpe1ZEsUPGlqelKqBrgFY16rn5B7b3tdA/NlYNhZ0I7i+5KvHcYOSsJWmYSNiH508euUXb+3IPEPL42Pz7vvXr1y7sTlCY8+YEKCy8RxjSoiku7qG1oI2lpIOUiO6rNUrzzLu+elWFUqxIdNyJGIWz0rYJ0L0tZ+WPGMuE6L2mDXB8ni7vXr1xjvvXr10fMyhvVkRnWzwyutvn52ewgf+jWIY8bfZ4/7B3NvOB1hFFt2mo7ab1M7Q8bW1X+i4saUjjAmxa0S/Jox6ZckbMDFomVFs2A35qR0EK3LBjV5TVd042UEck/PNJ3qZ96i0KtWM0QVhiZsMNI277/ah4pHWyjCq/hn00AOHPkM8bjtNLvrGm7NLz21/9KOf37hx/+h4p7IngL/8yx+e2lM99Nv5AIm6gKxou0/NA6HaL/xOFasVkkFfoaMamm0FXijS6PS+uzvehdBK09YS2AXjrUdsHCmFtWzObHP83PbHP3vt5q2Pjo83u9wTA/zFX/3kzJ7FemehxN3EfEehESgWfZM43o/Cf6gqSGf9mdnVGEDq43cj1ZLP4Z3sH4d9+UHEtKR9lnxPgaUyPR8pQcSeNX/xFz/cBYWz5KXj7c3b937089cvHW2aRpV2qTW/UpFmtcpsNJkTaLpE1eDZp3MgmUd+6pH0GYO+mbfPsdpYOsJI5gAATfpJREFUw5bPOurm85d+axbc1MIoqPusnmOEDOmeSYkNFaUT6n6L8tm2qmjR2bZnESQzEMO6bW0c3bm2n26V1dTZB3HV9tNARnljszEPH52cPDz5B//gj05P5ygENE3zhS9c+slPfvlf/utfX7q0bewZtfavNFRcFNQWP6DhJEkEaRRV/vXk6rYHLFNXBNBCzGIoHW7j7k5YCu0/WmLtzkIhvMGHq2ZjHj06efTo8Z/83ZdOT+2se2K/8PnjH/38jf/3L//m0qVtw8ju6zyA1OrNfqKNnv9Z08RKaDqhCNvoKM0pIUqclzHvGzLIDNwk68CccF8RTEl60bWOE+72thxBUYdf4LhH9yvHFB1a1LuftyuZ5PHx0bUbd772tRe/853fPTl5bIyZ+iBIee6543//f/3X997/8NLRtqP+18O9uhLAFJBTXItBXSmq/UYFqWTyS9n9ZDigBlvnQEP+Gu03spBS/O5OIrrkzecv/WaV4UfxLk77CKSsll2uIyOpfvWLaUSyc/RJQrsrbaTES2dGwknezEMzLQJ6kKPjve/snOoVQagHC0keHW8vX776lS+/+L2XfufRydkk6KNp7PPPX7p1696//tf/4cnpE7RqJ76fp+vDsTrqD7iHHv0VlWBTVzu1Ylob3jKtNToLjWDj3W0yVD4A7AqYUSW/FVtQkzlCcnu0uXL12pe/9KXf/+5vn8y5J8e37tz/P/7tf3xydgp4i+/5hQNOpYlLO0FQ2rbY2CcBFU0P3nIqaKJA+PAfrnaLOCFIHAB9yJ+F2DPAEZCUgunvuzPiMKJmiiLTL6az7jRq6AjeRSsf4Bc5+e57H3z/+y998Yuff/Jk8oP44hc/94Mfvvqf/8tff+7SsW2spu+PFPOi7mLGVLwxTCsScTxQ8tLfOvUZjdwr1FrqWN6Gh8UG/rD/7ZjB8LOCw9i8kHcAWbudHVMblK0bbIpAbT4EycZZvVOL84A03mfsJAAkOQFcrhAO2MX+opwB/E7sdhAiSQ6dXHqgarvdvPzK61/5you///u/c3JyCqAm7G0t3Z079/+3f/Fv7t2/d3S0bewZlciJ9d2oOs2mJkIIdAi6B6az+j4KLkMZUH4+iMWIkhv0xkXpjfiHRvVAvLvsmC035uXX3vjKl7/8+9/57ZOTU8DUZALdPbl7/5//y3937+OPj442TZf3kGIb2xBR7E9ai9D26hhAqZtcHdcb3RAwnVlXwHPExABHHYGBXFU0L3Rf7DcPHAVV93Bw40yIgV+Tgp6JN2n+GmtgKdbosFm43W4ePjx57bW3nA84rckDSLG2+eIXXvjvP3r1//z3//nSdhvqYp7yM1CEKIq3MEiuGoESeZ4I/FHgXDb8D4O4vb+U7CZ3KfBm+z5nWmhUfl2hhX8J8lHZfP7S1yajUhhFQLMuAP2flrMGFI42ABOh4FNAF/NHdTNEyAQQm7dIURXBZEPlA+qbKYkHYvz9MAY/+/lrL37lq3/wvd958oTW2hBa96FVS5Jf+MLxrVv3/td/8a9u3b5zfOnorDkLZUz2gtyUollT95C0rfKXDZOuNiqPd+2ySitHIFr7ENH9iiA0nTIhcZ++v8QJbznsGBAY/OwXv/7Kl7/8vb/19Sen1lpbviXunnz++Nad+//8X/7bW3fvXbq0PW2aADareN9b/waNErUnSYtY81momN26RiAR/ZNsPwV79T9QBQLUrUGYkh8DjHNlAdrQ3gcuPgGNGMYEAtDz+isDoTG7ECuhg1qOjo4++eTBa6+/9f3vv/Tii196/PhJ6J3LPwhrDL70xc/91d+8+m/+3f99vN1AhNa27QIJryepcwKr2kdCfBKg/9CRUahKhqE5ylTrmbHdu0D/9QhMbJpWYEOvB3yyNYDfnOmiMsZ2ZJX3YRwMCOBleTEw/F1EPvMIkpABsIDWcvXWLSAcCPstSgiUbwgqGh5DQhBeinoyYADIy6+8/uDB45d+/9svvHDJWmmahr0XgOeeOzo+3vzwR6/87//q39+9f//Sc8dnTaPzZ8vAuxlJ7Wm5R0+4FQRYrZ7gjkDTTim3V+FShQ1l4BjAsMhNqmekaClTEgXXmggDGHnl9TcefPr4pe9884XPHQ/dk0tHx0ebv/nZa//y3/7Hux99dOnS0ZltInV7H4Uyqj96PMLSEnTgj1gX7IdZo7Y3MSXuT6Rg0pSIGewxbgxFne5jAhYp5IdQNltU3GdCwKsQf9dca5QLT3yAf1IALY+Ojx48ePjzl3/5hc+/8K1vfWO73TQdiVT62mw2zz//3Onp6X/4T3/5n/6fv9yajRHYxkZtelSxv/67ZaHwq7j/E+nHHhlr5B76FeBh9J+louOMSbFlLDVWhnjGT+C3vvD9+YkL5qJAMUxTCDfy2QBQ/m0KBGmEp7vFRkWqDgVqn4QxHpbrXgZiAAAbCABjBMZsAAOBgYFsDAxgjBi0f4GBGOP+ArSHNdK+xxgIHj06+cbXf/vP/+yf/Mnf+ztf+tLn0Rt3e/To9O13L/+X//pXv/z1m2ZjjrbbxirrTwroUX4/WqODfRvQHquaWGzX0+lFcxASauYdu4fAdB7U3SVjNg40ay+2/YPubogx7a+6/7p/hp+4F/Ho5MnXf+tr/+x//kd/8v0//NIXX+gvh0cnp29fvvL//eCHr7/xjtmYo+2mvSdBZKRNcTocTEglChbeoGhoOm6fiA1CSIs2PeoUA1oAVw1Qdf7ABg/RX2yMrTwSeXEOF9MSB+BCeIVvdFXcLjMQw+6ZGAHa4jC6jMGIATcQaZ/Jpl3mAhFj/BFgjAjMZnN61jSWf/CH3/1nf/6Pv/udbz7//HN0vs/Pgnz88YOXX33jL//bj69fv/38c5dc+0BGoqts/VWLdY9gntaNYcQEQUEP1ub44GocQIZ3hvWmLluGmNP6yV08ywrpw29+4W/n8csJvgAYRIEK/0Duf/n3RGapCCCh3BSEENGH3xr3E+MvwcBIZ9ydI3DGS2QDwLQ2LriEjbf7MM4TdL9qfw4YZx8FBsYY8+TJ2dnZ2W989cVvffObX/uNr37nO988O222R5u7dz+6/P6Vm7fuXLn6obV87vlLlBYs6kyYh25Cak3GHA9WD7haZf1FpBMA6AyXltFLxhT03XM1R5jgBYKb7O5D99/OF7Y+QFl/gcGmdSTtvWqzJ/crGGOePDk9bZrfePErv/eNr3/tqy9+55vfOGvsdmvu3Pvo8tUPbt6+d+X69cba55877iab05tAC6soj3xC4J0lLQIDEp34e3tXbYuNOeEX71fE+Fi0M3Pe+ks6Ehw5gLRkhbQ+VMwGAvRvJLQPRRg3Nt43mC45CBbflbOMEYCtxXe/bZ9PsP7+SZr2CW/E4NHJE2zM7/7ub33ta1/9vd/7+osvfunsrNluN+9d/vD27XtXrl6/e/ej7XZzfHTUrsxQqs1Zf2r7ru59ZPf14E22q9xF/ZaV1p/DI1acZ0w59a08JxvP+t8EBzC/UKEw4SkdRCj7gGyLXLYijRxGhJ4/aH+1UQfttlCcBGjrZrzB8mari5VaU+7MuhEDbFQeEGycSwXC0Vqb2LqBs7PmyZPTpCRCytHR9uhoC6CxQcBAemFVaPF0aH6nUiZWiRp2wi9UYZUoVuQwIhr1rsTVjtYHwHcgwkBFoXB5gI7627sU0iD4m+N/Iu7vXVBrjAH8PVFgE0Vku93oe6IMjJ/hyiDN7ZRf5x0RDaRq/mc9ZhhZf4U4O/l4sX1lRwxYf7UEe9a/PDys4v3WmBlVDOiehRAm6vI0qtjb3eO2c1QZ/ZCGmc7HOE54GEOIGGOMociT07OzsyZ0ELkrOT4+2m437eBMt14lqtC6+ZCEas8G9R0//2VjElDPDm2VILCIrgxHIn6YEftzvgPgzoZ4egKxiqR4/NrOPQfEb2Jo78hIYGUhHmYQUJTeg7Q+oFnO4/4EIP2U+7f1vsCx3HTbFV2Hu+YcsgID1zvkEAALbFpeI2tpjBWKdZ+0QoCgaXv/ANOaYIgxoAvkLASWBhbGmOeeP0bwZGHAvbFncXuzM0mURK1et1Z4l+AxIvERbpc9KEJIBOxHy5uokq/nTbLtxDhcvNsyB7jN1AiM5yGwbDsJYSkQGrRNoC0ZBEHj26ZAiNhgtKy1AjHy3POX4lWE9t6e2Ub3e/uCY+cC4Rp4umBfoQxdkUC09ZfY+ovjm4wns7qfMkV1yvsga/17sT+H6sBRTxnD9oq2m4hSGYLrvvULid1kirsCOOtsaQzanMcYsVYAMVaAzqDbrhR/vN1cOtpGeiFtW2pLdRhNy/WYO+lJflR7jzB45LRgYEUPgmkyOD8YLOKYgqbQPMgAv9sUurOFrX9lYE2s7wa2WR2iWWRw5U59sr8roIJNRtBolgkrY9NReKhULdTufejOovtFa9MtJLCgUGw7XeOPb0iBFUJghBQ0QtO12dEIrLUGsEb8gbqvs2ybsWlgSLTd5G3whmD4jLUNdPE0ZrtzrfoSqZiRItYiErVXIntK5VFjPp7fgh0pmPYEkqHqC84HaF2g7Xof6UJOGjc9J6QVmNZltl8H0IgIYTsiIGNpfXdVG5d2KREdrkQDQCg2piVgWCtRBKgJnFtswDrWUqIt5irtwR7ns9W6b+wogLyPjCVo2W/7USpgEU1hqbqrbRZrdxjZHwsgBUYNnHQPqfPUyRomu0hfR8feB9DKBvFAfZiYJBsKBDYfv+XmsILp1yUBaztXEdWEmfgGlaNqyk+1z7OR/mj4z11M+GjfDleO3SGSwWeX/a7tZPte/ICNo5SBLv8eO4pyBchM1jDbsxXsefpbKB+A2ClFb+7Omca1TZAtGSgMpCO5bMtcBkIagKYN6iEgADE0VlofAC/ICjEQGjGN0Ihppy5bG+oSdQGs0NFxM8ypUWKlVwX+iO9TJP2Oifvs/N+tCGzX2KOtf5dX+ykwtXfYA7K7REsXMlWSZFsfYDtZUStiulAOIoSFhRiw5ftsbzHQeiA4H+A7dAmBDcOygFoRVEp0gTbfhaA28QcRYbWChqx2GPC9sN08hLNSLb1w1/XvxEg0DQ0LrcZZ64+Jsb8MUFQ6yUd4dxgdHYyzcelbxvCAraUBxEhDGog1fmabDAvRkYkix3/NuC2HkYPO/elZ/+BbFY+21SVfSWjkOWCUuKv1xwwCTFR0MLLc0rgUsI9djrKlj79Hej6nskbHbJ1FzlEm/Tyk5HWXshMdLZyQHt2x+aJn8emHwrxcnggtYJR7oONRbAmQu6QaYkljYQ1NBxDTWnTDoIYGsJ0DaIEgEDTWUVW1nsAF276F0obG7Oi8NMossVKNMJnplRQWF2kjONVfnYv9laCC5vHMFN7ppqaTYJLOB7R5QFdMZAMYdDcEYGvdDQi0vZ+6tQXGzVapmQKm+IlqVQozo11WpMAc2zk2TS0WCsUubAg9r24yIKrZ+XFoX/sdlnuUHjt0fttwkDoMOZei/YfPVX1ggtiw+50DZ7xZMJAdSmQ7eK+z/uxmVtlxTridS5WkMiXg1M1RunNf4fgh8MgVeJnMA/ukTzGxWqof9p0QOSiyxqphsLVwFlQRqk1JSBbJKpIMgDlji4pzjD6TQpXFxocCrYQPaoaKAZJy4Lboeo4iosN8Iq7b/kWGUEQFudZzRdDvLgjEtjzRLelBwD1oLcQQFGOkaYHXRtACJaChuzmupmaYkikhyWDCN0tQMOs2GToEPFL3QCTzEiE/bi+KH7OBDqxFc+z6SgkEtsvq2l5I+tlpethZLGi89SCt6VBjKw797z5FV3Pv0DA3mkerh/uAhGERzvuIpq3W/JCZZEgFpWo4NVj/0HnezoUFQnqJ6QiSmq0Ho9kHa/sJ1Eh0hPKGYFc3SfQxkk92EJF/dEgidGRiZmiL7ScNbDxTqlnZB/XTPewZZnc1p0aPdGrE+vcKv2lrD2vj74klzN1mgydB/zNNO4QreajNC8e/MQWMmnQpGDsABn+PscpENLxbepue4HU/SDq0QSEcx0r0/clnQ2AUUw8Bubq4Xsj0SbqDaKJtIVFNLdCR2miiRjH7U2GoTDvvBKJ6RnWFTpjm2K4dPvy8Ze+RCAf3hJRqSJrxE2DcukV/yUkHZEcR4eBej0JD4TMREYzVgbwvIHaeALF2m2YOD42e+t7a0GHe6afEItJKEkRNQWcaGhgFeRjte2CJMTS79g1682VISN8kIavS/HEhJlMt0VD1gghI7aMlVIKSer30cFyr+fR6BRqRiOF51PqnLZ6MYMq+3m/fK8wA/VmyZDMGa9er19ZzPkx2AF+tMu6o/SlksFVidDY4B6EOfiNyPiD2ELGBRtSv2m0L9ubR/A4M8Idvjgk7rqvTBg4ALQ4mEVYhgTje2z699m1HS602DRm4E4MOQcxkoGqhwRSKkrm38ETAlinnlkIKEhMVc12k0xdx+3ukytPWjXUri745GuJq4RpQw/GR7ASyWLIwIvf3f0Tie2IVmbM3NmoOIKb171oVqIViwgIFk2C/d3UYSqBHeUDV3yz6tKDaiEMbhLC2w7Sw9seuWuUjemYdFZX6meTlcPoMDYkdlxRiTAP/EIrEVd+I9N+b9azE8dIl34Une6VAO7EUnDTvrIb+bGurvnmtR06vB0gJ45c4MZW64kQAMYiclp54+MJj3exAf/UFThRMfN03gDJdj4+FQGzDts2/tTcWbe0XaEgjBhBYV90kKAZoXANou2WtsJucEhYcF1US4VpVA5c7fMuFVrWVALU6UcOwNSlRetH2vQZ0W+uzof/ECcUC5+oo7GosLcJvWhHIdgCJXaurlY7frQWVCRjvKLtO9TahYIePEbGgB7SwW6jBBraw0CLlU4dw1bYr4Basf1JiyVh/JtFyVmZ8rDF0MMTMwdX07e2IXWvo82zr7Qrx90BQ92BavI3Kdzls1qt3RhvS194YymaM8De3s6yuIYgeJWEEVaoKfSJUYNlv9QlX7rNQtbKlzPXPbDMgJyhtLcm/wDLKh6V8ESYBXTVdQJx0QkQ5zmevC6HQ/Y9sx2d/tEPE9zsPloUVfM5c1qBqwuzLfsYKcyHcF19GI2zb1dn+wtIadDwspHStomIsLMhuLLaz8o1Dc9Gi207Iw0pEz5i9G6GBQDW9MNpzitQz6haNMw9PwcYImEq8sioC6xG6UJVwOo/Oc7Gri4jtyr/d0IAjiRbQ0gFurefqIH6go4Nrq8JARMcXF++0XmWEUCD8rNM36ZrPg7CXSowsEWMTSKw/deRJFXVSNX1WW39IZTGghyaNGSkmzWxBFrujqXBCiYDycaAnrrZdw0/3uPx+BHTTV/ehXNtPVAqWOMDw74yDkyhK0fBe++02nkZHJ+OtSj+JHibGQX+MmXkumxfsDv5MU7DElAU25ACk2IA/EstzvDDADCBK6TUwDN8FO4a46dYZxOXsZBjBG6B0JiB04XSRF+G7X0IJ2SofIAaWNCbEwkLCdXwCMG1s7DLw9pDGjef4eBpxF1C2PcH63R2oK7vcgIHOn0yncaLBMe0Kk87PpNoZNQUhSsasbxUMvUzwowC+bk4gEPV296Mrg4T+Hz9XrKwOSjYv4xcjYxLaZGPTr8rmrv9VWSYwtmVU20t/Uz6uR6/3DKja10g6H1BuGFFzd8kjQ/gMLdsCVndTjDf9xq0oG8x5NwMTWFqDRmULWhqEBosC2BLtMt0XxFi8RaKEgJGyo3U7TB3He3QWAv/sEACmm2AuaYv3WgsYxMQ5/VS25bdWxC3IW9teO1DS21miHYr04NHvN8h/zPem92cEU9yKvuSFJNIMSuYSZJ/YTsC2Pe5dCt0hHu0OaicpWyTCug4W7QYAMSDc5CzbLpgETWfxuhD36vg82zf5iIRym1C1ruuqg6oAq31DXQkACumV+y3cYQUBSG4vMwSUjhPK5T3taISY9nOKHLpbHqAJ4gyiWYmQRjiIWsF9pyZbek/onAbJ6IOFdoehOs2u6V9cRTqe+yV7c7wq7gZrDP2A3jh7ha5acXLtadxMNi070qaoed/pFVG1tLmh9ECmn5yO1XVv9grazATcWkpH0g4Dxzol6c8lTPn2rT/7nD8i5TLAgtZ/hi3OYaf7cgg7JhbbifcJU95fjuM05TmKdRzoQbCyv4kOCykggHHK3M1zmfhNtpv/hY/uLNR0cbdv2Dazm86swrSuw6UChpF5bLMGN/dEryAGZdvK9xG6HyV08vQ2nAr8VepMpSLutqCaf1BJBnsLWmsC+LqBKwm0DtKG9AGdWiTZkWRTS8IEr9v6vy4apcOUoQaOwtxFtNfjf1KSQTAFFFFhYuomdACft/7OwvTaonT/pKqQZwrCOQwfCXjWf1sd1ovU3umGtEhuHq6grsjpfINm6EfwLsB0TrMDVxnmAKLVhjTGd98TjzYkiRnjBlpv+n1CYNWIxVjsn3b4cAGLvrwp5u5WeMGq9NRDzIWAxj7CYbXIGJ3vgfnIoawoFAPieQ9PflJ2A4oIyHbQZ3i3dUXjDVW1C+E84crIjlGOFoANWh5NWwZwpq/txwxkcxLJefQwSw/aRsRVCvAIQItvm1FkucGyaeuPgCPFLUAyNOGhgSDjsjr64VjXUNtNQLc5EAQtHNQNCAu8+oseIWjPqqfM0B7NZtShmbLzK6VG+JuTdLs68McDPTbC/YPIO3O6BXGPUH4IgKWuN5bLZynC09staYAfbSPVRNWZbCswriKiUpbIB0hIBdh1/bcX7qMa1YGh4fgkvkJMpZx2bcYdnIxwIWEPn0szhuj/+f5OqG9EqTVlunXl3IIwC/tmT5UAGSx/1HiCLWdDQKL4UTApOUDPzuvoHgXwl16AcQQ4yvHB9coGLXtd14ai2CP88m20D+g45mgCVu8qnBB0HGdAOzjc9rihNYKuyRFtasFYcXJoHEiH6YhCfhW6quQgGc0kQ+7UuNgtKmYyveFWChMVjvKOPifw6JSqJ3oigbaU4jtOOlhafDVA4lIjHeVQcNvMwSO9tD8NF3WzUKA7VZkQXAWFMRaURFDsLVVKBYUkCyEYx6q7EQshBqIlo95vJWBqtisv0SOZWqQ6tp5Qte3OdyLNRNkDfwCtHZ2m3THVRdn0q60cjWBqx+7KW6UJOHKCfUMJDJ4doUuf1+M8kJ6qahNyJbReBlC8NVV0QExXTD46Gm8pZdQLp/HxHLqG8on4uRaWYwRVNuiMlmsCDGBF6wOMb8dj18RpHD+aX66mqwhQII3AKKPV0CvOBzJDiUcRdDmidIetMtiKIii0Qqp9B8bUKXnQn/l1nKVdgq7rRHCQapfv+HNoAlbROULT8uMpngGVyOhwNc7b2FMpYIhq4TQmJSJNgo5Lu4ZIRpL3qjs2ZemhnrhkXNTtYLBULhdEMdIfKzTmapdZ2jXFyZyIY4kD21yE0nq0tmaFaFcmqUC3dOirN7rtVUvGR1xszFWC0bP7/fwgMOompeN4rWZjf8l+agcDvozxZcU48fmi//17kyFqngQBVbiEfJNPoYeHw/EOJMpLs2eCbHnIdzxkIsrone0ZmGDTyNgH2MQHUKxhJAzJ0OwICkDbQj0hTXVtM1p2kvHgbKkmQiZYhM4AoCkTFdoaga8l0F/xxki5hMUoswIVlGCS5MALQTIK310+1PXCusjT5RM+GXInaHRQiNi1xw5Mom70gEBL6EdHb+pNoUPpMRPoP8I1ovr0QNemzXQw5NYv5uxgkmnNlmlB2D2qNpkzgekjsyWVN41olkFQVP44YAQYlQGkh5kx9QSIe4Ri6y8y1vmTm7k+D9y//itwoU603yGz+dzxi4VTxQ4Hj0xA6W3oRz3lc0h1lcb6fMuiMcjkHq4aTBRP0JM2J/sfmpU3ZoX0v0LUVhEJXbvjuWjVixG2Ml6QeCZAAomxQrRtPN/LRJQ8ameMY3/E0ZzGC9BTOgzIGrR6bRdZQ9VA/UWhA/sltBnCyQUHTD9hhXf3xrppL6dlDI16eTjeKxwo099xUYdqir4tqpaJHLgdqHUi6++GRKQAexLIQA9565/hk8gsbD8SqfWXgwq8z0LUOjd9NNZEjzsrVtPtC+RitOSPZFIKohezaDrtlOK2ZP05YP3d2rkYpp+r2edV+B4GvmxSFxCqb0pUqkK+VxXMVrqGvoaVBWEZ0hjIlLcsm1b5S0VLHZzKboDAkDQddWVnF0CofqFOI8mx6nYsyF23fxhCg4KFoVZ46qWsJKiPMI6AfIe7ivqhaHZUG6cygmkOqzuGki6gAALrIoGhs0hRm5DrMLcuOYDK6R0oZANDGY2n1AtWBcy62B7on5ayGeAdZ29i3S6rx54loXcOeWNs/aVAglNIfTP8oBz+IEuBWaofiai6m/Cl+yTZC7+EPKDjrFXD9XHqELae6h1Kyx25k0uxoH6VRI2DVZj+ovVHcljs1UojexSO4tnruxssdaBtMApjUBAmVIkZ7QyMWXO9sJAZSpJUUYNJo0hWjEapAvT7glL2Rjq+/taG+eGvDpSgBYztFKwkhJYKo3JgaTv61I5/Na7Lom0DpWfv8tBQFCqyX4bLFRWjcpxGwZnbiJQi6N/bdBkIWrMBi+cKdY4SOXwh5UmjRvvgZ+l6jEwcJtjygDtdUKzHIzQChhTzQYyhYbA4BmHc0ZIuHFOzQ3OGoW/9S2wBiO1vqATEtzKUs9SEsGN1EM8MHTxcXFYBotYBEU3IGxUM+teaV1fshfwZ069GjhnoWdIbpUd/yMWsP+Y4gUKRbF/5wZpkQjkuIEoWaeEEID4NEIbIIaIJGwzt/36NuTcdkE0yUC4DhIJlq93lCJBVWmLdkm3J/4MsliiqYkViRKgl7mjREKgZqevAMb858hEI0kpuxAQges9BUg4dJAF+/7PZeZaIQ9sNO0e+kzFfDOjjfOs4ugVB8KCbUtUOGhLxsTE2mojQqijyTWqOieNQxd5+Z2fU2KPrnBEPhF6UYxPv060/Bqw/MYzZpqFNeKqqJhxKAogChND3mYmlROVnyeobvlpGNTUpmX537enkNZktz+VrABUmbsWQvLLt56IAVTWvMQhoSNirDP7kIlYAQ+9komua/5akV1OAsdYgxIlr2kvq7SncjFjofE+E99peCwpMN8AOFQWrwBT95CK0ucD3+iHW2kJuwdMp4uZKi1HPD1K+BEZmOg7WCv0K6MMS6fgV4HHwuPPT/yWMEzG14K0OWtjxznOg7/cicTT1PzD086AvR6ETAklruRIPNwSnq1XGFTUphkxMvy2Hg5wEyPmxATPAXG0s4YToo8FWETnAD23k+HyAXBTvptShzmGEepOlFDUOJRPtOWp3U8T9R60/9mlL12v6xDm6impR+FpyuzymkDP8zPuAqDuj0OSTpMZDaBx72QNzwFSHeHtJk8DXFvHHmbbrBzAqlMm4AWfETHK9KpCHxHSLFeuDMUs9s7c9Nn+MlKXh3Jh2PSlAFD7eb3t0HEpRMuG6g1RVoLtY6zIifwkmrhHp8DTuuUTUP09kBFeSMoCDqzKj1IwY8hUIDQUWSaYFqKYelRjpHHfbEO7PgYgfvT1E3T+a81LtsjVx1KJ1pyNQSGI+Em3QMeitBl1CPMIoSb9vvEw5YP2nlSBXNaPn2PK/FBjEkgOoRvaZLYxUVoah+NdK2wG52D3zLVqyaIT/Jx6aj6oIBfpoS4uO+qcThlTGxzHTsWV17piMCabZQGd5GxETY1eM5XV19o1C4mNjG9Df/8oa2t6+ikxnzOPYA5XjEDx8NeIZOfWTFHMPiFBaR2izBzsUWWfytsyIpmr+AeNKBvs1gPSD6CVZKuTHmPVHGob0IpihS2NKLhT/ug/+lLMK6pm1RDSmY69ClPS0KB7IDJwGBnH5eFMMI+lDVA0sBiYl6z9M/IBBa8hVzWgWBzv/Bv9FnMc237sz8LGBcd2xzCCOHzN4k3RzVf3bzixXcCX/T7JBkdYe+op81p9nS5xoFDFy6E6gUxJrTUuYrdehvSVj2p/8HaBk2tyAXn2MsP0BRzJDWhADor6BErl3kiMYH1NEKK0KhPgXsT+Ivs434qRyKflQs1dhZnKxkhVojIRuephPlBxQa4HVWv8S+pCF79ErU6G6rQOlJKOfOpvUJFrP9daer9EbgJonyHsRZjS6h+oRZUY2VkA6hfcoPY7FWPR3MZIlsoeLOY8w+Tu3Y29mcRNgNA3DaCqR+6WVKF0tQlGM2n1K/D/I+u6IhAXM+QDdAUmrFH3jS+j01juxW8fvG5F3qVjb7TcU5gmziIHallFd2of8SCPcXrbA3m3j0FdnRZl7Br1NBYwEqVnFpqnzoV45AQkencJZ/RHcNEhhvpCEopBvErcT7CFFVXDzwMQPi9MppO/fzNc7Bn+o4xZEKVXk6fujxfTtQ+qGA3E3dTJchgzXQp9PQspmHKOmH6MfW9j0YznzuQBX2359BsYdwFwyuNwcb6kbB5mYrq4gzAG6TOQlrPKZJAqhZaHnqbPsBgpyZTQtoxmkvRswEoZa2uZ/AgVDH2ktaUWD/t1ir0OWpX3WR+179RjKoBsv579MtB5zVQGJpquiZEjyTXW+VDB1BcfN/ioVAJMyUpzhWMkmDeWBRGTAehY8Vr88y2IXe4X119Vr9EAVJwDpVwGR0/XUDsMXktBjpu7302VSkDJoj6ykU2abp7gQ6moAo4Zx4c6fi4D7r+4zdtADGI3lcybbizcW3xAt7gGgJkb2a8iic6rtEeN05nJa4SqjLSAjBW5NXUmyEcd54Bazm6gySVcMU2pDZBE4Ff+2qovJboyJVBGF/bYUyCcVYBWW5ZIAZFOBJL9w+i49WiiNNsTfj3y4h7JnQg7nKcX7OYOSN/0YX/hRVIyyu40PwGG1ryr9ryEsWg8l9MYqUYqFiISD1O0hlqx9hWB4tvd/FAbYxfRj/JzK7+PTYP334TO2u9/pmjIAe+EMBkW+4qU87GzYExCJn31aScunAoyryoja5W1cuqAaLUPvGyM1x4AEMwAxKllH0tOhwJpR+U+qbj7tAEmW4vciXFGZBLBYFeiNjCGdvyO13Fa//UkPg6Bk1rPgT8aIx5oTinkC/dRheBcR/UYdZBCSHITBIa82av57XZt9sARe5Ki3IUx5r/p2O+SMb/RAzIA37aFDEssJFNK10dbPWvuGHUwhKhd8nfV/6grC2gGMB/GTOCGq0ogeiNnb0UWUqSRO39VhE4A+Z+76VWz282Fm4CBkOiCDirn+agUN9dxDYIJDqnwSB44ozLhl4OEBwCeeHUMpsKyksIx5bBgF8mqkE6nnjr8dZcgjB/EPWPe8HYl9A/N4DkfXMgdsfPQbZG1igdp1YLCmEBQl4L4ijo6mA5NeoNwWS3+SMeixexltysy0Qw2UjnOHqzH9Q6yRi79mxP5Y7Lv27wB6e6nmTk9tA81uhXTwkwMf78vz9SO11NIPU4GOphGl9eshb8b8lEmVuA+/+BmH6MSYJ7wruVLmK7TMj54yY9DyIE/0D2Syh3JuR0kzutBsqtGz/J5BvibBPBDPLFtFH5pWA73oW+ahJYGY1xIzNq1maMiiOqhQD2be+kvZu0QSjz3zqjilR06cZUGRTH5SUbmpknXEKgZ2qjkeR47PE65Z2GcwDwGN99+mIHwuDkKFw9DM8sU9GQiqkGtT7cf2umE0IlrAGKDEfCycFm9bigH0qB+phtRycH4JAUjGKxgD+nkwJ+QfzJtpFp00SwWS7MifDIex+UxIdaQET4CC2IDGSdJ55rTnjFk2yijzkl57jwSfzJTAHxlrNojaj20O9K7N9B1z7hEAA9a/d1NQXFAlAnVxysBDvgcTLdWgG2OZSJp7tet1X8VVje25+ozCJUE7AI6h96PZclTVQRkJGhMJyLgPDq5R5lIBSciCJKJT77kMpIw8uVYf6WEdRMo47SQ2nLyt7qxQl8EaFJ7p+LVuoCw1ShfR3FmriEMCc8hiJv1RIog4/fVMrND/iojuGanFz7A/cWQyxwsoIOte8rZ7NDzsL0j03oSS3x/wspmIKu4jyjW+paSIPfwnG9dHknT1XVgYWbMDdmSg5sJzNI9Pi/Vf/gZtp5AnVeD74904SdSpk4AaJ8Gan/d8gPTKVQNBcYAO4lafXMzu6sH98kCXExCZQBNCQRljYXLwgVuJoaSN/XGk0Vi+bvFwkHmJSQRbMe5PADVrrkTulv8sKMOCJvnYHhmjjIHfZgE39dzy3LVZxbzMkJmNDjilsBmegynsLcZ8cr20Y0AjZBJSMNy1ybnWFphir6b4jWnnw1l67BfitZ1g3CttcUYUrCTRq/SK8qzRcVOQE5ctegim4zCQHnl6qSzdZ5aO+lVZ4N/S06leKp2RCkfM1IagfiVjfq7vVBNWCWUdJmTpiWlDBgieGEox03EITfSIrN3U9M4DBqW4PfOZDSOLUii6DnuRxNVV9Jtw9L7nASXkYn/R/FND1h/x15eWAHvGHb0rRy7hZhaurFthLHwGffmweYa6vhVlgXyg7rSevmrwduyEpvT4j7iBQoQTGZAZvaHIWfKsioD0UoFMVYBpjpI84VFsve0YapTeb9KBw15wyPgIGMOFRoN26CHp6tXGivmJYXbYrEXOkM1lvAHq1tlwS0+u13PutpvASlZm9Rn1AzlCp/4ZDMX+A6OQhZwgZMWj0OyU2mwljjLT1mEKbrlP678KMrO3c92OrYAZvG8xpIrx1IGhH5/lNajUpUd8QGS3e/DSMIFoniCBecyEPWgIfa/G9IvQ4zvLDjHEWIEgi0Iwb0qmmPKiTUP1KsSEZZJDctKjIQHWWbFrpukFcuDihyu96L11yn0qnnwvkeLo/cQwDDvcaISQgUsuNGLW5vbIIQavfwJB5wT4cU2DuJiMzHm4jVlXv83QERej/+JAAAbCdtZGiwyNOmXakP6IVfaMc/PB1YpmQ/w8PUqcrLGWfrAvBToZZvxKHzzOdnBWRtCsGXvJGw1MdQajy7Vkyos0sTP3YcFqV7SfsB5n50iIn9ONzJErMI1wMb/1fGBHYtJ9HKsuDR8KwjlnP9vsckfjuQ9lxwuZRWyHjHvVhC9kuHciTTWH0gtKVkA429PGdEwx3r0x7y16cBASkSxU+wBJ6Sky4iT5U4qurqYLqNLjD1WSe7kWpgA+mYxO307kDzt8KIwYiMnrmENLTErNndmbIzW0ECIFKYaaOkzsu2OhAqTWf6qVH7f+Na0+qH4iGL/bM54upj/98jJb2n08a71Bo1QQc2sAMhVHCgpWqPTOWu26ZMJiTbAeQUSiCzjSGlTKiZDCSsx1DfVtDAtN3UV+Ho4kClIoWpa0HoeX9niPEPOhfN8WDDqbebkLqowMq2zNwFRwZrZuGr1PVvexeBol6z8mzFeVtIxOn6HuyNW+dsqnZuE1GL8zg184ndh/wRzhQviSSYpg9TWAGmeAMhyRbQmKgRxokzhILdfTBGNqcwe0ZVCDFbCYRmQjQCbFgELyNWh8J4phoGov1XyGiSpApv6yC16Lsjupti0smCTIINXaqCPBYOXACWJGwWf/xPpI4TjuP8n6o9b6ozacH19HQ6sR81bk2KNZApbkcHvThYRslj7ZKXMAKdFKtZVnViiApZZKKegRFqw3lSD7sInr08KlAlI9Q8EpaYHuJWV2bmDoQUJK+k8Yj8pH8BxW8GvWSdoOGaoh0nzM2SDRwsH4nmBtLFyB9iBRE5Pe6NZYDQY9UxMFDBCJRgwZ0aNi0PpjovVfM/DH0IJezuijesBojhXNwggXFe5ZslIxfQ4gFYas4wJiiexNylzPFoLaWbBiKpB8K5M+65Kx5pDRRx0uxkFf0j8+y2Ojo1XiaugGk0CeOT9M6gTVXgdD6zAVfqkLh4pE1lnjkpz8lIhrwlxYnCSwR3iHUXxjhvVHH3PcCRcq3iXsbK/Gxgr2gr5gEKN4ll7bsuLX4PMY5FieDvvkV0/COYxhN1ADB0mR6hUZlKbY35mF8rM5QbmldVSNa5yEleNhOUZhnN02LaeX9cqOEBP2G2fal0lxKwaGD4ausJgN5FvlZ7ZLTrH+rDTuc3ChwpPDxMsZfs5LRb27Tp+dL2q0/PVux97PiSwR5ZEVlieCJU6Nkd8d42R9OTgIJY+DjE1HJohHHnoaukvMVvwQV3FRtfqz662XKGRC3b7cCqf0cxSUNGVfrXKYZfGr5MOqvrrYNVTlZCtiR30+fi1kXTxGB01HyBtYadwnv2Ge9a9uzcGiC0hm0R3s1dWcA1y0nXUlI0NefT6yKXNGzPkATEAkmMF58m/rMdfnxP0qS8SjCE869sWU1wFzH+p4XT3/w/RSOXmoKT/ZxNGmzGn5zQAtBHa2M1MBn9ETwARzUJ7qhgwgadWI0GKBP6YY6Z2sP6c8u+rxsXNo81/ky1b3IluZOsSZntYUbR1KXUCaykD2JHwrFCWlSkzGKb0UvEcGkKn0AQkDHUbtbL/qgCG4hrmGkgm9Q9VPmIPsYPWbeYFepsm2uOqd2Hm3jZ3HKGu0SD7CyW6WOuvPGocx3/SXp38wwyBylsGsXt5PMWy/uxfhmAPgQFy2lBOreTKljqCI4D5KBcYDVpujb8u6gQyBUKFEPFweKF1goIfjEMiDHF7GMdJeTjmfARbP2ncOrDBUrOd8gb0U5s+bRh5xBhgDfMbNX21yVtDkKt61IUYoVnA8rG39CxncZLu/C8JTDUU+m5TOS7qQ7VzbXYk/6IB8+Lkxn40jcVCjqQB6H08I/fOXGXNAs9eyh1kJUN8byXS4Rjev9FlLR7oThww3409mL2sCxhJ5bI6uKyy6mEd+xRGUaR68g0HXkrVx6I19oIYxom978z1CrLfvmGYpita/yvRzt6hy+rTX+qYfz4R/2U65kbsOgjHnMFDlcqKG/UFChexWt3km596nQkMSBjGpTO9mvfyk5Cq6k8XosvdhhJNjvJbbjV9wAvHvoFvHtA2+tDMojiXV1kXHrX/WNuVl8nK9oeVwfkRD3q00VCIpiyA//fNnldGXJZqClud1OLwWF4QZTQs4WnMbKIcmAoQYwyWGhraGE4hebUBKU7tpjD7hZg7TrI/2iY4maJxFrMNBJompuzhVHq4w36yQKBzNRfK/4oRwHtOSg1E7nNULG37uSv+9fK9yiQYm3a7a8TEOBfLzJn5nNz5Mtf7nQvPGiz9K4OYAUt74mkJ+5QQAimZcSoBFlSKYUmxhHSiYZU8bQqXoQBLkKaLTDqIe2oNe/Fff+plldUYVtjN1uWP6ccoEc5x6Dot08ggHULAe3ebEU0L9+wvy17W1BORDixwWT/Q3xVj4X0F2NHJ/K3teF2gDnRhxcOHjrXigOcdfy2nMEYThNHOTW8LpOHHZ3BeVwiI4iEU4CMM41ViG4tUZWzcwiSxIxvQGJikyZqVj4q5bTDPiWJLnuXIRT6N9Z2mgA0PWVgoi76gFcCZayX40g6JrGrxpKP6QSeQ1UFnF4tafowDgSi/UvYNrrNXag+0rml+LhG6766EmKACPphCsJX5QPycpGICDBqAenz4ztu1FK++lHIFRI57T+B0coNgRugl1ChaOAAxsHEzOBrjE3P/UNc+SH1sCAxgXjyx7WXVHaqcK6lpu+iq8QNGUZzZjnfWfY/pnRLjLAj6DmgNPNbP/Hn3JpCKwDA1ojofzozZdaorAJeM3bVhsJNcZ0wOgl3cf2Dq614UTrzd+w2xhlgpGz4ISw6TD7uAMULf2Bjd7ubSAqjU0hfF4rAqa+0UNc1wWDkLuRkhhamyg8QKTxph3C/wxax1M5Qva60zvBUkC1oKAJhHsDfJUSh8MrRNmHeaKGap6pnSeJV3JsW8d7RYtNGgqySQgNy3MGB8fAmnj+S9WcuXXY0rTzTQqDjKjz6dkqlDMEot5P6oD+aVy5orlXTFLXDUsxoGEIOFRxHB0r49kau7PZEWXGQDRDJI4zv74wQcUHUB1sF9jFgvWvNTkPyUqL39KMTikqcCI8xjoFq02oKFO0AH0gBnbWEXJlzSkpNRzOE5xXTOcQYX9wzr7E4sRAdWfG4tXNbTZiSKnw4ChzylN1j0dTu3Bxeg2nzBJMC/qn9cX9AxINl54B7DQLS9H9BwKcSby2JTPlsXOiaHe0IIgLTD9mtlJlY0k5xl/EN0J5hCMHn0wyu4Ek59bNTAVHG/F9mXtXayMoHd1BhiKLDGAkHBEIH7q4FgtkDW4EjPzJ5M445gHs2aa/hl2vzoTmWn99+E0lksC9p1LbCfv+pponcVFVr5W1rXlFEw5s+TvWVWZerIEipCDU8QYxYjSrV3R9pOZAGKWK1umWtalujN3+YIcR3+FicH8s0X1Jiva66yATCUFdHVyM/m2Y4gTa8KM2+6mf6rdR61RuTAmfo940rKvMS4gjhhzPeI0cRKYwzY/H9qzzqqgDqWh2FzbRKHGm2/wt4mC46gPK30XhH1pF9QCTcNpGhfijarZ7fUyL4WJ4jL6MXF3TEckUE1dlLH+KHn+MdM8KA+5sFkYU/QYdofr6EROAHmWdSR7NMsXtRIwzgVUwOczCfJkWojphC8F49ITeymSPOdwHlcYqJ8vHUg7RpmF6o5WNpFjWUK+wXTkBPJ9q7EfHcnFp0pzDFNGV/mP2oW9SmFgHALlKD6TB5qwgL2RauifygMNa3gtdF4TrP8SetYXJ+B+yrRiYgiIMhzeTOOgV2+aTPw1tUk0215fAtAFArLf3zLcBDmQE1R+RH9ljX5vTcI/uhjHwS4WbRqr5lR30eZeqZdvggx6OcUZlwse1GAZ4ObMpNNjZH75H2LaGoFkQjlUy9rs3tovMkn5bMLcxsWDiDAbzTo/BzDZuC9hzctYztD817wfMtct2ntDxTiY+ucIk8TMemxhFGtcazd/XbNOplLdpZyszdgxrDc7u+98zFz24yR506ZTx652AeuPAmCFVLQi+6W7F2+nPskdnc0Fqwhc8LSgmg6aNVNFE4GdFMtB3QlMGhgeirKR8dY7aX7Vif3KhDdgakmA054OJgR7c3YXdgB5lk0KUDoJlm9A9MFqfeBeCynmgiy7Wn/U3ZOx1GzSU5nBMr0jYdxTUgO+mGnBFCoIjg6+TKSCmP+t9azLQyXWcsPojklP9RzptNsxQ+yl9gsmQjl9XG8nLKjqrBYeMpjAUM/dMovyuwbBn0Ws/2QG77l1gBkDwLPrujsqyTw1r324iYlUEOPjqfl7zcEu0Skh9gT7XvcTP8sLTIj66wP/8c+yQuhxiqjyYN4wP42bFenv4TgTPsIV9t/YXPRSP1nG+k/jiV5+GmBeijDhjYeW0GmLehYVRBVhe3EWYPCTg1xAVXQ1c3yACNiTLUMtjDPPhk6iAh3QUOf+GBnBc9tgOzkGTtpZUzQDZOTXQ82gGMwGpI5yY276OpkZdLdpgF3s/rNo7s+vZxQDGQCn7RLsZH1mWTTOJcRnPQ8FM8K/pftSE/hPM/TTLg07ftcquM0yln2iledwMjqCeahJdWCxzbVg7D8DRZlREphq1mvaqrHe0nkWwvtzLwZs69nd5tr5WmvODGdEzRKb5wPGbTejtpQsYlO8wDpYexcZll4T1QxRxtqe7KpKMtbZ3S3+VcEFxNmTAbWK8NP+OSkbqLHIOzbSoCoYnzMItpfo/MJ6jSWgUy6+Z+odwPzPlpOAGt6wTJhWdUX1NWFigWpz4glQjdhkDD12eqS7dMR6E1k+/51BfA7FjhxrOZ+6npmHU0ayBD0ON2aCq8z9Usyjsz4PLPw9+x8Eu5g+4WmfG5hy/tslzn8E7peos2wShs5dasUceUOfQGukrktldzDeOTlJ/GshccfJ8fusqgZmftms1Ty9Fls+A4uy68Ny22tZqGcaKDSXlmcPg2CylMdarmHhwmcUa2NE23Gpldo7N0kNRmYawTE94YlA0CQLmLTuZNN71lD4L2PQscKxZxxqRxB/0lKvGlAqhh4TDEHK/DNbIH412zSJMXRgRqzqVqyYEVS/Hevez6cHYVrWJWynYP31VeIel9BOT6K+bXTKT4r0nZP5i3qub2Lgj9nnMGHsFnk4yP+Oe8qpscK+RXolsyz+QgYDu39wVkfQQJC+t2kA2bnbBzvcx89Gn2jS97CjPxjjAppjl1cKP2dbqElR/7wvHWLywSRSmtXAFeas/Dn3aCwxPcABUz7ZJlZYDNQYLAwG5qg1xBiAYiqrxJjeP7pjoWD6O1cx+s98r1EmNJjhDNbmAhowXzPkfysDfJlo8XdngBj6VZVLqDHxZaq73a0nRr8RyzJ5LWTu10JXisAWF/mSQWGZWdjLROs/8woq1+fcceiZj/LQVzpyIzjRASwWdU6gS+tH0rWPdqxysCS2MZXqJ387GPhERXUrobWzWPgRVDkMrtfJUrClRDEI5p63TNkSsfaCByCRsX7QEes/BgfJdG64+kc4ueOzvkK+SLB/MP3ztyYjB7DTRNd4MZYthe5cCsYJ5n5mXD+PAWLZqFaDev1ha6CS0RMTT3VpIV9OeCczwXWp+IoaxGNXG8EFttoEpugJ9hQTkZ/Jd2PY+qM6YVoB5zm8VvMKC7aBymhZeLB5u9qykwXe0J3WFocGGuYxAg2/odaRMFx25VbOCmFOd2Cp2vAMm74X6oiJDmwHKS4UiEIHgJ1JTEFTigE75mLDKMq6k8CH1wV6TSSDq+0ErWoQYtVqqfcBu+cuqYFm+YOLLew65ZahH2LYCp+rwcVOf+cAi/OEOHrqwBeqwvmcMxhal5NHAXbrl5oQ60+3/mu0ci0DbBxeEx1ASZW7QrhzXrP/GFI0ZgERvbeedFMWbQca7b8kxgP/2SNa2V8Pz/fuTkO059x0VoS+4+GXaA0qj31PI5Zb7rbEP9rPMPDizTkXzdo/A96HaQbAJCitSw6mPOoq1ssRH8DpHy/St3GY4ZK7YUrTM+bpHAnY/S0B5+HTva5njKTNpIKoZLrHuuE/sOtFLfDblSeBz8Xo1qpRegPIia3zF2i/rNgGOlMCpgjvzEP5+0gO5/YTcCI3lgbQlwr8x5IYTLszxbVZB9EsoNaChf4+/kgmkv8M/BrLIE21372IjUVp/1RQQWAhYzP/04ubfix6UdjTfVgq7NcQ0MpQwLz4epdBrfXoH2rOYe9lz4FTwt5X0znyaE3wQPWdVAvBJmvYyXoB4YzIfbVTXADMmatXsLwa6OElw3oA61kJTAORQtQ+DxPhboNgO18v8v5gkDd1EblHfoYX+46lYCx9IgsNtdZjRznrz/GPLA4Vze74nM8Xu3S+8hl67e4A6jt/MOEIEzToF+fR3F0LfiE3syAoj5l7eRW4ZvEv3WesvR4T3K7Wv5CcFUsF89bE9PrHiob7EOCv7gAWpM2ZWFooVmjn+YBF2mC4R+6jevfLaTXKNet2i96gWWqx2OHsJ39obt/R5J+gIl7udUlMHhNbxPpPhIYgKz+jw2vXDGAeI7RMRn4WSERmm3ju3ES4YCWAMzkwNE/gYPZw0bfPAooxSYxbbwfPo4RTOTCMkUNw1wucOwwskzA0LEGYengt5gCmi8JP8AeTSGeyre31EmD7CcZ3M/QXY+kvWbxdGRfiDmfHSrOD5Z7EqHHPjAejyj6O8UMsb/2XN/27LeOD9V/hZeL9ov/sEntl3rdDByx3/PYCdTarj8Hd70D2FnPCoTjxbdPs7LRn8RRvxfWi/oEW4TLcgVH+tXzNgSPbFcuf/C5GGe7P4XXxMoAdIuJ5UMcc1az5QwCVb2BMPTCrS3VOvYRztuYKxhD7+codL3IeVfIO5zRswSvIIYZOr35aGANLZValGJXIz87WH+e/aA6veQ6g2gfIhLKuPjAmfynngE4jbxiyxZh0K1Y558A5geVd8XKf3xEXmuyWUPH+sgBFUVoSi81yocZpjXcUcaatH8wkdh9rmP8erLDCLlRyOcwY/5Q5gIkgzSTyB5K9/bYChf8u/D/5J7aDyiXHyMWGKd6WOo29eQRclJ2pF9ZsE59a8xre6jk3hLvfvdXafHYb/7rIVBAreSZcvO0QOwDuehtGpVcGI/p4R7LgUrCTfZ/tA/LOnFUPf9fAfxUXeHF20LmMFOxi82ZeXRX6z/rT2NFknScX0LnXf89tSv0cXtXJxnbuB4fif0zDicbbkDj5fGbrai1MAKePidlfmgMzats8d0JaLnj4stsVySDEhMU3NqYs6RrEZiIZ3GT7joWe/hKt/tjPlz6dK3+Hc67UA6iOlxlop3J4Re7suBOFWWkKjMs09124ya9F6hK1p4eZh5gdRI9HmTtaohm6AjImSlCB/3BxW7NYkyfW5AJaohlpD5/9DJeTt3WmvnJWgFXx7q56v5Vv21PUv2Z9eJ8Z4zpnMnukCxUh7nq40C76hagB8XcjlJhs/THd+u+nUlzxzgU7vg59QzkHwEyYXgvGDMTNXO2WL07+s+ChdhWAHIsjcT7XdQ64EMp/mXvmA2Z9HSLnae/bkQxu90vb7TMLe4hnpgXhYr8Kg2DceUJqzugXV/ih/+XsHqzFmrc474BYr3uMc+LoZffVeXVJDLQXYPZJY52TrH8oWeu/IBlcnUwNagramPfL8aMehs7mOoCeaeDO1m8Z28UVDs0p/5z0pVzoJDnNQDyLK35CpXRdu7vbQRYgg5vlkofI4Cb9fJIBnnt75xnug8Xf7bUd230QrrnXamGKtWGfGUdblA56VXWN9LOsmDmqOuACimCLRNtP1+bfxdYvcJQ16Dd36DM+sIFeVAdwAcNBXOwD7vOsuG7bQ52pnRkbYPF9jJ5TmtK8v1M77cSDz7TbM/lBd10TVeT+WOrbDnZ//y+zICCR/xinHpHLncQosMNFLrL3WX6m1lCRkmyGTOM+4+49fMtM6z+10Lx7vw0GEZZFvx9LWf+DN9inA1jGMq7rbSo+yEUvh6sbkbGC3Lm5mrXQmMU1nrCnmyBLiYVh7IbMxtnXKetPIgQ9vC7YawoElE/4WS1SXnvEXdCF6VDJ0mqOM60Ad2K9LysDLylv9VRwsezNxKd0QPWHSgCcHRXaZoE/63L+7OHJ4vwWwWfWARQt1aixpsRa6YWYehFq6dGfVDIW7QWLX96f5WH6va1ojo3Nnl/xto6HeSkGiNqYHTv8U2ayge7NrC8P2mDFVXHIAGqt82TSt90N/d7NaOXHMe2wO90CTL+oMZe7wD7Avrbn+N8xmUp6+PwHhsgw0dItxA69D6O3SHKAPZ/0wdCvngHEYf54J+F+qC5lUfrPlSN99O9UpZ47n5EVPDktqImdJ2IgWMkoYIdL2KO1XNj6r80GepAPXt0BrKQJzGyE7P+Kdflz5ljMnvvaRZpmvp+ZuO84TZR1//tokWRnpTyjFgtKk4ZKsvJF72b/nmDhZ4GVzv3QIvp0ZAAz8AkuItiNXY+//JjYciDJMsxCfLrW+OLaADM/iwnHTGsn4wVetWF2pKKWJfGfxemg90QIerD75+wAhoL3VV8TRWlWnQpmmYmN4wnwyijuuNecS+zDvQWyM4+wFAQMZg5ZT6CGQhamfrSLucRuP5xj/cf6bnfSgVm7XHCw/js7AA6pOcrayp5Z48uJ5n4FIcldEZsdMK71L+Sp2zV7kAxDta1dxccvRGs8w/qvRQi6tOnHBV6Tz1wGUGf4qs3Uqt5Cpg9DYYLBXQbj6n3vZ0AJYK0NthQ2gt3OZEfnU81Cujsl3MDvzs36X3jz+ZlJLfbBBbSzjZnEEDczbL8AT3yWNBouzOqfwF+Gi7TD6ymU9w5WzLH+1XDWKnTQ5zYYdjD0F9cBnKOtn3WEXWhB97ryhnpIL5Dk714k6deqS2BPp4ZFvjmLVu2HFgIX98EebH35ZS7eKe3Cxb/P85m44CDrCBvMO3PuySKvvuvOZVvvXHyYN+G7GPizWJ+Q+zlWuceLyBMc1ALO1QEsSO25rK3k8kfG/s7+2UyWPyO7dFmEbTIj9DzkZ0rJBOd3iw4W/+JlAOdr6Pcb9V/Qa+TMvbdvo4/Fj3jhzP1CZG5zEyxc6Ps523YfLP75OYCVVA+5dzfA1S6We7mZC0EXuxqHhU0MofQGZlIDYYfvn/ikl9ED2J8b2SEtWMH0z473D6+5r0WKwDVsoBgzeXt4jFW0oE8NJnBeB8d5HoizvwDrr7HFRgR6B5osp7NHPYBdjrQTGnYw/PtwAEs1z+ziJNYz8fv3AbO/kftqpxkLq3fd1eczYY5FzmEXE4+l7gT2dz9X4nF46kkfnh3fs62wS/VBepUwwLnePi7phEY4scsmG7t97wVc2JNEzHEOm4rzhq/q++uTefQFw//Jdwn7vr1Yf4EdLPtqDqDeKFd6gtG37dMNXMAkYNIK5L6BizlpwS7fgllv3kvXOarTBiz2lROtPy7eih1+2wWh9T/AR0kGMM0o13uCtW/0jK840DDsMy3YpSa8mrlfjLuzmmKh3+x0vkD2+UhCnqP1P1j8EQeQWHa5kIKI86zqSifJKYJ8F+1GjdnWHdKCkehgBlHzPAt+IXQoF3AyFz6o34PVvdjdq8+QA/iMxLqLF1S5WF1RH/Air2FU3ZTKN09kX97LVezDUK9ZRF6V06EmqF9AEPhg91d/mZr9u5SNXOcw836y3tVyla/CBdgFq50DMcFbnINLw9TPn3f2gTWvdHU5+Bnt/YeJgFUygHMP3Jc7AVyY88dFO8k9eohBY8hKAwKFX6WAEnrviftzZijFT71IzLtZF0ARfhVIZ9UOoYPFXzEDeKpfPKyfqdfJlY49K29gf6p21+7xpzqSOBeDOeoUFywlH0z5RcwALqxxrynz8rCqdneby8wqzXnzRMNdB7QUSytz5CH1b9fEf5Yarx2+z8urQj5t2gAHB3DxLPt+Pju6IAvjXcW/V5/hPtf/LFvElfbuhVCNr++AWlsfZrmWhGWZnmU23dPTLwr22XhdfAiIu/1w9v5drir81A++F2/Qitx153/58wTa91XyXYbsB2X0ZRfioIP1P2QAT+MLT8OJoeimcB6Xz2dhT88Ij1egPduxXLonTeDdr+Fg/Q8OYLKROSeIHwue8Mr7Av14HDucxGQDt3eaJ+z2l6fENk0m+jxHTeCDZT84gPN3DBc62OeyOolzNcgOO3W5qH9NzGd37p/JMf4zilceXoXXRasBXDRB4NknPPIZ/Wf/G4r134en7eaemycov+ciisLPiP1xEZfI4fUUZQAXGi/GuXFVjzRfrhNielX4dYd7np2cYM2vuhCi8PisPe/Daw8OgCXW/PLiKgE7e+rrL5jjSR2fK7uEFb5rffDi8Frn3ixj/Q+P8uAAziHwhUzrYzmP4uqynTZzT4wj7AiTDnuOFMSfPWsyoyVyZtS+RgfOwfofHMA6ScC5R77zzpznt0s440v32ZCNnZOjz4K1WU83eKe7iafsvh1yxKmW1B85/tV25zobV6AtDmaET8MKYe+0cVjfa3ugBckXsNr1LqbniCVu66GK+5lxSNUFnQUyAM4/Hw7KRmLx09jb49spUcBneW9irbuBvZ/7hdZLObwO93UhB7Azh48sVvWtjvjKWNMFppDDCn+/KOsez76BwOy3LiIUfHASBx+6lgMYtZujnSY8rNHzfZ2T35vRoo7zPMFd9Nv3lFYcXgdzv6QDqG+BqaHDfGbu/TPBNT0hLTgvfUpcoC/EBbxkXPR1dUGOdrD4S2QAlSZ+NNg/PI1zcUHTaSiAc9pXFyMzqJcM26nX8xzSimciTl+UX+8z7AAmBeaVw7zDx3xKfcCFO22uIae+h2597Ofo5b+MVEewclz+TFf5zz1gx1N95eeWAUzFZ3bEc/ZvTPnMOaTljMl864ZVNgLWvDOQ5chBVwU7DuHrhTK/z+bj2M4K8J/WkPnwGlzP9ZRw06XN1jOVu7hALPEr7Od0sfI9fWrtOM79DJ4dBzDVdh9M/FPlD5etL466EEz54nNvTsW+7tvhtdRNwzl+9zPuAA6vz+TWmtkLVKI+HgOI9j8nvCebMCPkv5D4z/LUQUvIYgP7varPqAM4RPefjZuA2futJGW+2yaf5BWW0ohf4PQ+8zxrU63/PCJyrHVyBwdweH021wxW+dBsO34uz2IC/oPP5CLZZ6J5MP0XxQEckoDP8n6eyh1Wb8Wx7s5dqkS8v6/H079aLppBPhiuQwZwWFT7uPwp2ocYcwy1RQjsatyxw1UssDLw7KxkrP2lhxL8wQEcXudvGzA37t95nBi4kPfkIpLq7d1JrJfMHbRrDg7g8HpKzQPWf4OMJRPFv+xiR0Y9wYXh3N9Pp0xt4X1Va34w/QcHcHg9O4Hl2kRAi4wB4zP9iFa0/gfTf3AAT9EeOLz2Z/fPiRH6aVwKe+DSWd76H7bcwQFc5A1zWJ+rbGNcpHNekBoIT+UjqlGZn+Ah8PSsgc/oyxxuweF1scNnXOzTxmfugdQcC/LM3sBDBnB4HV7r26GVKsCL1ISfTp4GGaNvmvZMcB6P+PA6ZADPYCR1eJ3jk8BFf6K4gKeBw/45OICDkTm8Do/k6bkx2OEeTrb+ODy7p+J1gIAO5ujweoZW0e48HUsf6LBVDhnAYaMeXofX+itwNlPpYoR3h41xcACH1+F1eJ1bVDFdpHOC9T8AOwcHcNiKh9fh9TSF/4NHwVJL/7BnDg7gsCEPr8Nr7aWFwwY4vA4O4CKvXhy22+G13weNWR+YFv7jsBwPDuCwDw+vw+v81s/OCrosWv/DHjg4gMPromx+HHbgZ32dLPLAsQinxWHtPbOv/x9k4cb/ZdHNaAAAAABJRU5ErkJggg==")
MANIFEST = json.dumps({
    "id": "/", "name": "W7PlayMusic", "short_name": "W7Play", "description": "Seu player de música",
    "start_url": "/", "scope": "/", "display": "standalone", "orientation": "portrait",
    "background_color": "#07060f", "theme_color": "#07060f", "lang": "pt-BR", "categories": ["music"],
    "icons": [{"src": "/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any"},
              {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any"},
              {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable"}],
}, ensure_ascii=False)
SW = r"""const C='w7-v7';
self.addEventListener('install',e=>{self.skipWaiting()});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==C).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
  if(e.request.mode==='navigate'){
    e.respondWith(fetch(e.request).then(r=>{const c=r.clone();caches.open(C).then(x=>x.put('/',c));return r}).catch(()=>caches.match('/')));
  }
});
"""


HTML = r"""<!doctype html><html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#07060f">
<meta name="mobile-web-app-capable" content="yes">
<link rel="manifest" href="/manifest.webmanifest">
<link rel="icon" type="image/png" href="/icon-192.png">
<link rel="apple-touch-icon" href="/icon-192.png">
<title>W7PlayMusic</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Sora:wght@400;600;800&display=swap" rel="stylesheet">
<style>
@property --h{syntax:'<number>';inherits:true;initial-value:265}
:root{--h:265;--a1:#a855f7;--a2:#22d3ee;transition:--h 1s ease}
*{box-sizing:border-box}
body{margin:0;font-family:Sora,system-ui,sans-serif;background:#07060f;color:#f1eefc;-webkit-tap-highlight-color:transparent}
body::before{content:'';position:fixed;inset:0;z-index:-1;background:radial-gradient(120% 55% at 50% -8%,hsl(var(--h) 75% 24%),transparent 62%),radial-gradient(80% 40% at 100% 100%,hsl(calc(var(--h) + 60) 70% 16%),transparent 70%)}
button{font:inherit;color:inherit;border:0;background:none;cursor:pointer;transition:transform .15s,background .25s,color .25s}
button:active{transform:scale(.9)}
.glass{background:rgba(255,255,255,.07);backdrop-filter:blur(16px);-webkit-backdrop-filter:blur(16px);border:1px solid rgba(255,255,255,.12)}
#hd{display:none;align-items:center;justify-content:space-between;padding:16px 16px 0;max-width:640px;margin:auto}
#av{width:38px;height:38px;padding:0;border-radius:50%;overflow:hidden;box-shadow:0 0 16px #a855f755}
#av .pav{width:100%;height:100%}
.pav{width:40px;height:40px;border-radius:50%;object-fit:cover;display:inline-flex;align-items:center;justify-content:center;background:linear-gradient(135deg,var(--a1),var(--a2));color:#08060f;font-weight:800;flex:none}
.pav.big{width:96px;height:96px;font-size:2.4rem;box-shadow:0 0 30px #a855f766}
.fld{width:100%;padding:13px 16px;border-radius:24px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.07);color:#fff;font:inherit;outline:0}
.fld:focus{border-color:var(--a2);box-shadow:0 0 0 3px #22d3ee33}
.err{color:#ff6b8a;font-size:.85rem;min-height:1.2em}
.shake{animation:shake .4s}
@keyframes shake{20%,60%{transform:translateX(-8px)}40%,80%{transform:translateX(8px)}}
.pk{display:flex;align-items:center;gap:12px;text-align:left;width:100%}
#hlogo,#sl{display:inline-flex;font-weight:800;letter-spacing:-.5px}
#hlogo{font-size:22px;visibility:hidden}
.lt{display:inline-block;color:#fff;text-shadow:0 0 14px #22d3ee99}
.lt.w{color:var(--a1);text-shadow:0 0 16px #a855f7bb}
#v{padding:10px 14px 170px;max-width:640px;margin:auto}
#v.vin{animation:vin .4s cubic-bezier(.2,.8,.2,1) both}
#v.vout{opacity:0;transform:translateY(10px);transition:.14s}
@keyframes vin{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:none}}
h2{font-size:1.15rem;margin:24px 0 10px;font-weight:800}
.chips{display:flex;gap:8px;overflow-x:auto;padding:6px 0 4px;scrollbar-width:none}
.ch{padding:8px 16px;border-radius:14px;white-space:nowrap;flex:none;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1)}
.ch.on{background:linear-gradient(135deg,var(--a1),var(--a2));color:#08060f;font-weight:600;border-color:transparent;box-shadow:0 4px 20px #a855f755}
.hs{display:flex;gap:12px;overflow-x:auto;scrollbar-width:none;padding-bottom:6px}
.it{display:flex;align-items:center;gap:12px;padding:8px 6px;border-radius:14px;transition:background .2s,transform .15s}
.it:active{background:rgba(255,255,255,.08);transform:scale(.985)}
.in{animation:itIn .5s cubic-bezier(.2,.8,.2,1) both;animation-delay:calc(var(--n,0)*40ms)}
@keyframes itIn{from{opacity:0;transform:translateY(14px) scale(.97)}to{opacity:1;transform:none}}
.th{position:relative;flex:none;width:54px;height:54px;border-radius:12px;overflow:hidden;background:#1a1a26}
.th img{width:100%;height:100%;object-fit:cover;display:block}
.ph{width:54px;height:54px;border-radius:12px;background:#1a1a26;flex:none}
.cd{display:block;width:132px;flex:none;padding:0}
.cd .th{width:132px;height:132px;border-radius:16px;box-shadow:0 8px 24px #0008}
.cd .t{margin-top:8px;font-size:.88rem}
.inf{flex:1;min-width:0}
.t,.s{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.s{font-size:.78rem;color:#9a96b3}
.now .t{color:var(--a2)}
.eq{position:absolute;inset:0;display:none;align-items:flex-end;justify-content:center;gap:3px;padding-bottom:28%;background:#000a}
.now .eq{display:flex}
.eq b{width:4px;height:55%;background:var(--a2);border-radius:2px;transform-origin:bottom;animation:eq .9s ease-in-out infinite;animation-play-state:paused}
body.playing .eq b{animation-play-state:running}
.eq b:nth-child(2){animation-delay:-.3s}.eq b:nth-child(3){animation-delay:-.6s}
@keyframes eq{0%,100%{transform:scaleY(.25)}50%{transform:scaleY(1)}}
.ic{padding:8px 10px;font-size:1.2rem;color:#b3afc9}
.red{color:#ff4d8d}
.act{color:var(--a2);text-shadow:0 0 12px var(--a2)}
.btn{padding:9px 16px;border-radius:20px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.12)}
.acts,.bar{display:flex;gap:8px;margin:8px 0 12px;flex-wrap:wrap}.bar{flex-wrap:nowrap}
.bar input{flex:1;min-width:0;padding:13px 16px;border-radius:24px;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.07);color:#fff;font:inherit;outline:0}
.bar input:focus{border-color:var(--a2);box-shadow:0 0 0 3px #22d3ee33}
.sk{height:54px;border-radius:14px;margin:10px 0;background:linear-gradient(90deg,#ffffff0a 25%,#ffffff1a 50%,#ffffff0a 75%) 0 0/200% 100%;animation:sh 1.2s linear infinite}
@keyframes sh{to{background-position:-200% 0}}
#nav{position:fixed;left:0;right:0;bottom:0;z-index:5;display:flex;border-radius:20px 20px 0 0;padding-bottom:env(safe-area-inset-bottom,0px);background:rgba(10,8,20,.75)}
#nav button{flex:1;padding:9px 0;font-size:.72rem;color:#847fa0}
#nav .on{color:#fff}#nav .on span{animation:bump .5s}
#nav span{display:inline-flex}
#nav .i{width:1.45em;height:1.45em}
#nav .on .i{color:var(--a2);filter:drop-shadow(0 0 6px var(--a2))}
@keyframes bump{40%{transform:translateY(-6px) scale(1.25)}}
#mini{position:fixed;left:10px;right:10px;bottom:calc(64px + env(safe-area-inset-bottom,0px));z-index:5;border-radius:16px;display:flex;align-items:center;gap:10px;padding:8px;overflow:hidden;transform:translateY(220%);visibility:hidden;transition:transform .55s cubic-bezier(.2,.9,.25,1.2),visibility 0s .55s}
#mini.on{transform:none;visibility:visible;transition:transform .55s cubic-bezier(.2,.9,.25,1.2),visibility 0s}
#mini img{width:44px;height:44px;border-radius:10px;object-fit:cover}
#mb{position:absolute;left:0;bottom:0;height:2px;width:0;background:linear-gradient(90deg,var(--a1),var(--a2))}
#pl,#fq{position:fixed;inset:0;display:flex;flex-direction:column;transform:translateY(100%);visibility:hidden;transition:transform .5s cubic-bezier(.2,.9,.25,1.05),visibility 0s .5s;overflow:auto}
#pl.open,#fq.open{transform:none;visibility:visible;transition:transform .5s cubic-bezier(.2,.9,.25,1.05),visibility 0s}
#pl{z-index:20;background:linear-gradient(hsl(var(--h) 65% 20%),#07060f 88%);padding:12px 22px calc(18px + env(safe-area-inset-bottom,0px))}
#fq{z-index:30;background:#07060f;padding:12px 14px}
.top{display:flex;align-items:center;justify-content:space-between}
#cvw{position:relative;width:100%;max-width:400px;margin:18px auto;flex:none;transition:transform .6s cubic-bezier(.2,.9,.25,1.2)}
body:not(.playing) #cvw{transform:scale(.88)}
#cvw::before{content:'';position:absolute;inset:6%;border-radius:50%;background:hsl(var(--h) 95% 58%);filter:blur(46px);opacity:.55;animation:breath 3.2s ease-in-out infinite;animation-play-state:paused}
body.playing #cvw::before{animation-play-state:running}
@keyframes breath{50%{transform:scale(1.15);opacity:.8}}
#cv{position:relative;width:100%;aspect-ratio:1;object-fit:cover;border-radius:22px;display:block;box-shadow:0 18px 50px #000a}
#pt{font-size:1.35rem;font-weight:800;line-height:1.25}
.r2{display:flex;gap:8px;align-items:center;margin:12px 0;flex-wrap:wrap}
#pf.pop{animation:pop .5s}
@keyframes pop{40%{transform:scale(1.7) rotate(-8deg)}}
#pr{-webkit-appearance:none;appearance:none;width:100%;height:6px;border-radius:6px;outline:0;margin:8px 0;background:linear-gradient(90deg,var(--a1),var(--a2)) 0 0/var(--p,0%) 100% no-repeat,rgba(255,255,255,.18)}
#pr::-webkit-slider-thumb{-webkit-appearance:none;width:18px;height:18px;border-radius:50%;background:#fff;box-shadow:0 0 14px var(--a2)}
.tm{display:flex;justify-content:space-between;font-size:.8rem;color:#aaa}
.ctl{display:flex;justify-content:space-between;align-items:center;margin:12px 0}.ctl .ic{font-size:1.5rem}
#pp{width:70px;height:70px;border-radius:50%;background:linear-gradient(135deg,var(--a1),var(--a2));color:#08060f;font-size:1.6rem;box-shadow:0 0 28px #a855f799}
body.playing #pp{animation:ring 2s ease-in-out infinite}
@keyframes ring{50%{box-shadow:0 0 44px #22d3ee99}}
.qi.cur{background:linear-gradient(90deg,hsl(var(--h) 70% 30% / .55),transparent)}
.qi.arr{opacity:.7;background:#2a3a5f}
.hd{padding:10px;font-size:1.3rem;color:#888;touch-action:none}
#sh{position:fixed;inset:0;z-index:40;background:#000a;display:flex;align-items:flex-end;opacity:0;visibility:hidden;transition:opacity .3s,visibility 0s .3s}
#sh.open{opacity:1;visibility:visible;transition:opacity .3s}
.spn{width:100%;max-height:72vh;overflow:auto;border-radius:22px 22px 0 0;padding:18px;background:#14111f;transform:translateY(100%);transition:transform .4s cubic-bezier(.2,.9,.25,1.05)}
#sh.open .spn{transform:none}
.pr{display:flex;justify-content:space-between;width:100%;padding:15px 6px;border-bottom:1px solid #ffffff14;text-align:left}
#toast{position:fixed;left:50%;top:calc(14px + env(safe-area-inset-top,0px));z-index:60;padding:10px 18px;border-radius:20px;font-size:.85rem;max-width:90%;transform:translate(-50%,-200%);transition:transform .45s cubic-bezier(.2,.9,.25,1.2);background:rgba(20,17,31,.9)}
#toast.show{transform:translate(-50%,0)}
#splash{position:fixed;inset:0;z-index:100;background:#07060f;display:flex;flex-direction:column;align-items:center;justify-content:center;overflow:hidden;transition:background .7s ease}
#splash.go{background:transparent;pointer-events:none}
.orb{position:absolute;width:60vmax;height:60vmax;border-radius:50%;filter:blur(70px);opacity:.5;animation:orb 6s ease-in-out infinite alternate;transition:opacity .6s}
.o1{background:#a855f7;top:-25vmax;left:-20vmax}.o2{background:#22d3ee;bottom:-30vmax;right:-25vmax;animation-delay:-3s}
@keyframes orb{to{transform:translate(8vmax,6vmax) scale(1.15)}}
#splash.go .orb{opacity:0}
#sl{position:relative;font-size:44px;letter-spacing:-1px;transition:transform .85s cubic-bezier(.7,0,.2,1)}
#sl .lt{animation:ltIn .8s cubic-bezier(.2,.9,.3,1.4) both,glow 1.8s ease-in-out infinite}
@keyframes ltIn{from{opacity:0;transform:translateY(30px) scale(.4) rotate(-12deg);filter:blur(8px)}to{opacity:1;transform:none;filter:none}}
@keyframes glow{50%{text-shadow:0 0 30px currentColor,0 0 8px currentColor}}
.ld{position:relative;margin-top:30px;text-align:center;font-size:.85rem;color:#b3afc9;letter-spacing:3px;text-transform:uppercase;transition:opacity .4s,transform .4s}
.ld i{display:block;width:150px;height:3px;border-radius:3px;background:#ffffff1f;margin:14px auto 0;overflow:hidden}
.ld i::after{content:'';display:block;height:100%;background:linear-gradient(90deg,var(--a1),var(--a2));transform:scaleX(0);transform-origin:left;animation:bar 3s cubic-bezier(.4,0,.2,1) forwards}
@keyframes bar{to{transform:none}}
.dots::after{content:'';animation:dt 1.2s steps(1) infinite}
@keyframes dt{0%{content:''}25%{content:'.'}50%{content:'..'}75%{content:'...'}}
#splash.go .ld{opacity:0;transform:translateY(12px)}
#pick{position:relative;margin-top:26px;width:min(86vw,340px);display:none;flex-direction:column;gap:10px;text-align:center}
#pick.show{display:flex;animation:itIn .5s cubic-bezier(.2,.8,.2,1) both}
#pick .pk-t{font-weight:800;font-size:1.05rem;margin-bottom:4px}
#pkl{display:flex;flex-direction:column;gap:8px;max-height:30vh;overflow:auto}
#pick .bar{margin:4px 0 0}
#fq{overflow:hidden}
#fq .top,#fq .chips{flex:none}
#fl{flex:1;min-height:0;overflow-y:auto;padding-bottom:24px}
#pl>*{flex-shrink:0}
.skc{width:132px;height:176px;flex:none;border-radius:16px;background:linear-gradient(90deg,#ffffff0a 25%,#ffffff1a 50%,#ffffff0a 75%) 0 0/200% 100%;animation:sh 1.2s linear infinite}
.hs{scroll-snap-type:x proximity}.hs>.cd{scroll-snap-align:start}
.i{width:1.35em;height:1.35em;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;flex:none;display:block}
.i.f{fill:currentColor;stroke:none}
.i.pl{transform:translateX(2px)}
.ic{display:inline-flex;align-items:center;justify-content:center}
.btn .i{width:1.1em;height:1.1em}
.bi{display:inline-flex;align-items:center;gap:8px}
.ctl .i{width:1.6em;height:1.6em}
#pp{display:inline-flex;align-items:center;justify-content:center}
#pp .i{width:1.9em;height:1.9em}
#mp .i{width:1.5em;height:1.5em}
.act .i,.ic.act .i{filter:drop-shadow(0 0 6px var(--a2))}
.red .i{filter:drop-shadow(0 0 6px #ff4d8d)}
.hd .i{width:1.2em;height:1.2em}
.sh{display:flex;align-items:center;justify-content:space-between}
.sh h2{display:flex;align-items:center;gap:10px}
.sh h2::before{content:'';width:4px;height:18px;border-radius:3px;background:linear-gradient(var(--a1),var(--a2))}
.vt{display:inline-flex;align-items:center;color:var(--a2);font-size:.85rem;padding:6px 2px}
.vt .i{width:1em;height:1em}
.vm{width:100%;justify-content:center;margin:12px 0}
@media (prefers-reduced-motion:reduce){*,*::before,*::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important}}
</style></head><body>
<div id="hd"><div id="hlogo"></div><button id="av" data-a="tab" data-v="cfg"></button></div>
<div id="v"></div>
<div id="mini" class="glass"><img id="mi"><div class="inf"><div class="t" id="mt"></div><div class="s" id="ma"></div></div><button class="ic" id="mp" data-ic="play"></button><i id="mb"></i></div>
<div id="nav" class="glass"><button data-a="tab" data-v="inicio"><span data-ic="home"></span><br>Início</button><button data-a="tab" data-v="buscar"><span data-ic="search"></span><br>Buscar</button><button data-a="tab" data-v="bib"><span data-ic="lib"></span><br>Biblioteca</button><button data-a="tab" data-v="cfg"><span data-ic="user"></span><br>Perfil</button></div>
<div id="pl"><div class="top"><button class="ic" id="pc" data-ic="chevd"></button><div class="s" id="pfn"></div><span class="ic"></span></div>
<div id="cvw"><img id="cv"></div><div id="pt"></div><div class="s" id="pa"></div>
<div class="r2"><button class="ic" id="pf" data-ic="heart"></button><button class="btn bi" id="ps"><span data-ic="plus"></span>Salvar</button><button class="btn bi" id="pd"><span data-ic="down"></span>Baixar</button></div>
<input type="range" id="pr" min="0" max="100" step="0.1" value="0"><div class="tm"><span id="c1">0:00</span><span id="c2">0:00</span></div>
<div class="ctl"><button class="ic" id="pz" data-ic="shuffle"></button><button class="ic" id="pv" data-ic="prev"></button><button id="pp" data-ic="play"></button><button class="ic" id="pn" data-ic="next"></button><button class="ic" id="rp" data-ic="repeat"></button></div>
<button class="btn bi" id="pq"><span data-ic="queue"></span>Fila</button></div>
<div id="fq"><div class="top"><button class="ic" id="fx" data-ic="chevd"></button><div class="s" id="fn"></div><span class="ic"></span></div>
<div class="chips" id="fc" style="margin:10px 0"></div><div id="fl"></div></div>
<div id="sh"><div class="spn" id="shl"></div></div>
<div id="toast" class="glass"></div>
<div id="splash"><i class="orb o1"></i><i class="orb o2"></i><div id="sl"></div><div class="ld"><span class="dots">Carregando</span><i></i></div><div id="pick"></div></div>
<input type="file" id="ff" accept="image/*" hidden>
<audio id="a" preload="auto"></audio>
<script>
const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=s=>{if(!s||!isFinite(s))return'0:00';s=Math.floor(s);return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')};
const img=(id,q)=>'https://i.ytimg.com/vi/'+id+'/'+(q||'mqdefault')+'.jpg';
const hue=id=>{let h=0;for(const c of id)h=(h*31+c.charCodeAt(0))%360;return 180+h%140};
const wait=ms=>new Promise(r=>setTimeout(r,ms));
const skel=n=>'<div class="sk"></div>'.repeat(n);
const RM=matchMedia('(prefers-reduced-motion: reduce)').matches;
const SEC=@@SECOES@@;
const CHIPS=[['Tudo',null],...SEC.map(s=>[s[2],s[0]])];
const strip=t=>String(t).replace(/^[^\p{L}\p{N}]+/u,'').trim();
const IC={
 home:'<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v9.5a1 1 0 0 0 1 1H10v-6h4v6h3.5a1 1 0 0 0 1-1V10"/>',
 search:'<circle cx="11" cy="11" r="6.5"/><path d="m20 20-4.2-4.2"/>',
 lib:'<path d="M4 6.5h11M4 11.5h7M4 16.5h5"/><path d="M18.5 18V8.5l3 1.2"/><circle cx="16.4" cy="18" r="2.1"/>',
 user:'<circle cx="12" cy="8" r="3.6"/><path d="M4.8 20a7.2 7.2 0 0 1 14.4 0"/>',
 play:'<path d="M8 5.5v13a1 1 0 0 0 1.5.86l10.4-6.5a1 1 0 0 0 0-1.72L9.5 4.64A1 1 0 0 0 8 5.5z"/>',
 pause:'<rect x="6.5" y="5" width="4" height="14" rx="1.3"/><rect x="13.5" y="5" width="4" height="14" rx="1.3"/>',
 next:'<path d="M6 6.2v11.6a.9.9 0 0 0 1.4.75l8.2-5.8a.9.9 0 0 0 0-1.5L7.4 5.45A.9.9 0 0 0 6 6.2z"/><rect x="17" y="5" width="2.6" height="14" rx="1.1"/>',
 prev:'<g transform="translate(24 0) scale(-1 1)"><path d="M6 6.2v11.6a.9.9 0 0 0 1.4.75l8.2-5.8a.9.9 0 0 0 0-1.5L7.4 5.45A.9.9 0 0 0 6 6.2z"/><rect x="17" y="5" width="2.6" height="14" rx="1.1"/></g>',
 shuffle:'<path d="M16 4h4v4"/><path d="M4 20 20 4"/><path d="M20 16v4h-4"/><path d="m15 15 5 5"/><path d="M4 4l5 5"/>',
 repeat:'<path d="M17 2.5 20.5 6 17 9.5"/><path d="M4 11V9.5A3.5 3.5 0 0 1 7.5 6H20"/><path d="M7 21.5 3.5 18 7 14.5"/><path d="M20 13v1.5a3.5 3.5 0 0 1-3.5 3.5H4"/>',
 repeat1:'<path d="M17 2.5 20.5 6 17 9.5"/><path d="M4 11V9.5A3.5 3.5 0 0 1 7.5 6H20"/><path d="M7 21.5 3.5 18 7 14.5"/><path d="M20 13v1.5a3.5 3.5 0 0 1-3.5 3.5H4"/><path d="M11 10.3 12.5 9.4v5.4"/>',
 heart:'<path d="M12 20.8s-7.6-4.6-9.3-9.5C1.6 8 3.6 5 6.8 5c2 0 3.5 1.1 5.2 3.1C13.7 6.1 15.2 5 17.2 5c3.2 0 5.2 3 4.1 6.3-1.7 4.9-9.3 9.5-9.3 9.5z"/>',
 heartf:'<path d="M12 20.8s-7.6-4.6-9.3-9.5C1.6 8 3.6 5 6.8 5c2 0 3.5 1.1 5.2 3.1C13.7 6.1 15.2 5 17.2 5c3.2 0 5.2 3 4.1 6.3-1.7 4.9-9.3 9.5-9.3 9.5z"/>',
 plus:'<path d="M12 5v14M5 12h14"/>',
 down:'<path d="M12 4v11"/><path d="m7.5 11 4.5 4.5 4.5-4.5"/><path d="M5 19.5h14"/>',
 chevd:'<path d="m6 9 6 6 6-6"/>',
 chevu:'<path d="m6 15 6-6 6 6"/>',
 chevr:'<path d="m9 6 6 6-6 6"/>',
 back:'<path d="M19 12H5"/><path d="m11 6-6 6 6 6"/>',
 more:'<circle cx="12" cy="5.5" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="12" cy="18.5" r="1.8"/>',
 grip:'<path d="M5 8h14M5 12h14M5 16h14"/>',
 x:'<path d="M6 6l12 12M18 6 6 18"/>',
 check:'<path d="m5 12.5 4.5 4.5L19 7.5"/>',
 cam:'<path d="M4 8.5A1.5 1.5 0 0 1 5.5 7H8l1.2-2h5.6L16 7h2.5A1.5 1.5 0 0 1 20 8.5v9a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 17.5z"/><circle cx="12" cy="13" r="3.2"/>',
 trash:'<path d="M5 7h14"/><path d="M9.5 7V5h5v2"/><path d="M7 7l.8 12a1 1 0 0 0 1 .9h6.4a1 1 0 0 0 1-.9L17 7"/>',
 out:'<path d="M10 5H6.5A1.5 1.5 0 0 0 5 6.5v11A1.5 1.5 0 0 0 6.5 19H10"/><path d="M15 8l4 4-4 4"/><path d="M9 12h10"/>',
 inst:'<rect x="7" y="3" width="10" height="18" rx="2.2"/><path d="M12 8v6"/><path d="m9.7 12 2.3 2.3 2.3-2.3"/>',
 queue:'<path d="M4 6.5h12M4 11.5h12M4 16.5h6.5"/><path d="m15.5 14.5 5.5 3.3-5.5 3.2z" fill="currentColor" stroke="none"/>'
};
const FILL=new Set(['play','pause','next','prev','heartf','more']);
const ic=(n,c)=>`<svg class="i${FILL.has(n)?' f':''}${c?' '+c:''}" viewBox="0 0 24 24" aria-hidden="true">${IC[n]}</svg>`;
const icPlay=p=>ic(p?'play':'pause',p?'pl':'');
function pintaIcones(){document.querySelectorAll('[data-ic]').forEach(e=>{e.innerHTML=ic(e.dataset.ic)})}
let instalar=null;
window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();instalar=e;if(tab==='cfg')configV()});
window.addEventListener('appinstalled',()=>{instalar=null;toast('App instalado');if(tab==='cfg')configV()});
const standalone=()=>matchMedia('(display-mode: standalone)').matches||navigator.standalone;
const SIL='data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAIlYAAESsAAACABAAZGF0YQAAAAA=';
const A=$('#a');
const ls={get:k=>{try{return localStorage.getItem(k)||''}catch(e){return''}},set:(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}},del:k=>{try{localStorage.removeItem(k)}catch(e){}}};
let perfil=ls.get('w7perfil'),token=ls.get('w7token'),me={nome:'',foto:false,v:0};
const HD=()=>({'X-Perfil':encodeURIComponent(perfil),'X-Token':token});
let L={},fila=[],at=-1,fonte='',lib={playlists:{},recentes:[]},shuf=false,rep=0,tab='inicio',chip='Tudo',pgBusca=0,buMais=false,mixLoading=false,sil=false,io=null,filtro='Tudo',plAb=null,cache={},arr=null,seek=false,shT=null,lastQ='',pT=null,tT=null,dir=1,shown=null,PRE={};
async function api(p,b){try{const r=await fetch('/api/'+p,b?{method:'POST',headers:{...HD(),'Content-Type':'application/json'},body:JSON.stringify(b)}:{headers:HD()});const j=await r.json();
  if(j.erro==='auth'&&token){ls.del('w7token');ls.del('w7perfil');location.reload()}return j}catch(e){return{erro:'Sem conexão'}}}
function getUrl(id){const c=cache[id];if(c&&Date.now()-c.t<144e5)return c.p;
 const p=api('url?id='+id).then(j=>j.url||null);cache[id]={p,t:Date.now()};
 p.then(u=>{if(!u&&cache[id]&&cache[id].p===p)delete cache[id]});return p}
const isFav=m=>(lib.playlists.Favoritas||[]).some(x=>x.id===m.id);
const ev=(tipo,m)=>{api('evento',{tipo,track:m})};
function toast(x,ms){const e=$('#toast');e.textContent=x;e.classList.add('show');clearTimeout(tT);tT=setTimeout(()=>e.classList.remove('show'),ms||2600)}
function aviso(x){$('#mt').textContent=x;$('#pt').textContent=x}
function checaPulo(){const m=fila[at];if(m&&A.currentTime>0&&A.currentTime<15&&!A.ended)ev('pulo',m)}
function meta(m){if('mediaSession' in navigator)navigator.mediaSession.metadata=new MediaMetadata({title:m.titulo,artist:m.canal||'',artwork:[{src:img(m.id,'hqdefault')}]})}
function marcar(){const m=fila[at];document.querySelectorAll('[data-id]').forEach(e=>e.classList.toggle('now',!!m&&e.dataset.id===m.id))}
async function trocaCapa(m){
  const cv=$('#cv'),d=dir;cv.getAnimations().forEach(a=>a.cancel());
  if(!RM&&cv.getAttribute('src')){try{await cv.animate([{opacity:1,transform:'none'},{opacity:0,transform:`translateX(${-50*d}px) scale(.9)`}],{duration:170,fill:'forwards'}).finished}catch(e){}}
  if(shown!==m.id)return;
  cv.src=img(m.id,'hqdefault');
  if(RM)return;
  cv.animate([{opacity:0,transform:`translateX(${50*d}px) scale(.9)`},{opacity:1,transform:'none'}],{duration:480,easing:'cubic-bezier(.2,.9,.25,1.1)',fill:'both'});
  ['#pt','#pa'].forEach((s,k)=>$(s).animate([{opacity:0,transform:'translateY(14px)'},{opacity:1,transform:'none'}],{duration:450,delay:90+k*60,fill:'backwards'}));
}
function ui(){
  const m=fila[at];$('#mini').classList.toggle('on',!!m);if(!m)return;
  $('#mi').src=img(m.id);$('#mt').textContent=m.titulo;$('#ma').textContent=m.canal;
  if(shown!==m.id){shown=m.id;document.documentElement.style.setProperty('--h',hue(m.id));trocaCapa(m)}
  $('#pt').textContent=m.titulo;$('#pa').textContent=m.canal;
  $('#pf').className='ic'+(isFav(m)?' red':'');$('#pf').innerHTML=ic(isFav(m)?'heartf':'heart');renderFila();marcar();
}
async function tentaPlay(){for(let k=0;k<3;k++){try{await A.play();return true}catch(e){if(e&&e.name==='NotAllowedError')return false;await wait(250)}}return false}
function destrava(){if(A.paused){sil=true;A.src=SIL;A.play().catch(()=>{})}}
const mixC={};
function getMix(t){const c=mixC[t.id];if(c&&Date.now()-c.t<6e5)return c.p;
  const p=api('mix?id='+t.id+'&t='+encodeURIComponent(t.titulo));mixC[t.id]={p,t:Date.now()};
  p.then(j=>{if(!j.itens||!j.itens.length)delete mixC[t.id]});return p}
async function tocar(i,auto){
  if(!auto)checaPulo();
  at=i;const m=fila[i];ui();
  const u=await getUrl(m.id);
  if(fila[at]!==m)return;
  if(!u){sil=false;aviso('Não consegui tocar essa');if(auto&&at<fila.length-1)setTimeout(()=>prox(true),800);return}
  sil=false;A.autoplay=true;A.src=u;
  const ok=await tentaPlay();
  if(fila[at]!==m)return;
  if(!ok)toast('Toque em play para começar');
  ev('play',m);lib.recentes=[m,...lib.recentes.filter(x=>x.id!==m.id)].slice(0,30);meta(m);
  if(fila[i+1])getUrl(fila[i+1].id);
}
function abrirMusica(t,k){
  checaPulo();dir=1;t.c=true;
  const G=lib.gosto||{};
  const base=(L[k]||[]).filter(x=>x.id!==t.id).slice().sort((a,b)=>(G[b.canal]||0)-(G[a.canal]||0)).slice(0,20);
  fila=[t,...base];at=-1;fonte='Mix de '+t.titulo;filtro='Tudo';mixLoading=true;tocar(0,true);
  getMix(t).then(j=>{
    if(fila[0]!==t)return;
    mixLoading=false;
    if(j.itens&&j.itens.length){
      const head=fila.slice(0,at+1),ids=new Set(head.map(x=>x.id));
      const novos=j.itens.filter(x=>!ids.has(x.id)),nid=new Set(novos.map(x=>x.id));
      fila=head.concat(novos,fila.slice(at+1).filter(x=>!nid.has(x.id))).slice(0,45);
    }
    renderFila();if(fila[at+1])getUrl(fila[at+1].id);
  });
}
function tocarLista(l,i,nome,emb){
  destrava();checaPulo();dir=1;fila=l.slice();
  if(emb)for(let j=fila.length-1;j>0;j--){const r=Math.floor(Math.random()*(j+1));[fila[j],fila[r]]=[fila[r],fila[j]]}
  fonte=nome;at=-1;filtro='Tudo';tocar(emb?0:i,true);
}
async function prox(auto){
  if(!fila.length)return;let i;dir=1;if(!auto)destrava();
  if(shuf&&fila.length>1){do{i=Math.floor(Math.random()*fila.length)}while(i===at)}
  else if(at<fila.length-1)i=at+1;
  else if(rep===1)i=0;
  else{const last=fila[at];const j=await api('mix?id='+last.id+'&t='+encodeURIComponent(last.titulo));
    const ids=new Set(fila.map(x=>x.id));const nv=(j.itens||[]).filter(x=>!ids.has(x.id));
    if(!nv.length)return;fila.push(...nv);i=at+1;renderFila()}
  tocar(i,auto);
}
function ant(){if(A.currentTime>3)A.currentTime=0;else if(at>0){dir=-1;destrava();tocar(at-1)}}
const pct=()=>A.duration?A.currentTime/A.duration*100:0;
A.onended=()=>{if(sil)return;ev('fim',fila[at]);if(rep===2){A.currentTime=0;A.play()}else prox(true)};
A.onplay=A.onpause=()=>{$('#pp').innerHTML=icPlay(A.paused);$('#mp').innerHTML=ic(A.paused?'play':'pause');document.body.classList.toggle('playing',!A.paused)};
A.ontimeupdate=()=>{if(!seek){$('#pr').value=A.currentTime;$('#pr').style.setProperty('--p',pct()+'%')}$('#c1').textContent=fmt(A.currentTime);$('#mb').style.width=pct()+'%'};
A.onloadedmetadata=()=>{$('#pr').max=A.duration;$('#c2').textContent=fmt(A.duration)};
$('#pr').oninput=()=>{const p=$('#pr');seek=true;$('#c1').textContent=fmt(p.value);p.style.setProperty('--p',(p.value/p.max*100)+'%')};
$('#pr').onchange=()=>{A.currentTime=+$('#pr').value;seek=false};
const tgl=()=>A.paused?A.play():A.pause();
$('#pp').onclick=tgl;$('#mp').onclick=e=>{e.stopPropagation();tgl()};
$('#pn').onclick=()=>prox(false);$('#pv').onclick=ant;
$('#pz').onclick=()=>{shuf=!shuf;$('#pz').classList.toggle('act',shuf)};
$('#rp').onclick=()=>{rep=(rep+1)%3;$('#rp').innerHTML=ic(rep===2?'repeat1':'repeat');$('#rp').classList.toggle('act',rep>0)};
$('#mini').onclick=()=>$('#pl').classList.add('open');
$('#pc').onclick=()=>$('#pl').classList.remove('open');
$('#pq').onclick=()=>$('#fq').classList.add('open');
$('#fx').onclick=()=>$('#fq').classList.remove('open');
$('#ps').onclick=()=>{if(fila[at])sheet(fila[at])};
$('#pd').onclick=()=>{if(fila[at])baixar(fila[at])};
$('#pf').onclick=()=>{const m=fila[at];if(!m)return;const era=isFav(m);
  api('pl',{acao:era?'rem':'add',nome:'Favoritas',track:m}).then(j=>{lib.playlists=j.playlists;ui();
    if(!era){const f=$('#pf');f.classList.remove('pop');void f.offsetWidth;f.classList.add('pop')}})};
$('#sh').onclick=e=>{if(e.target.id==='sh')$('#sh').classList.remove('open')};
if('mediaSession' in navigator){const M=navigator.mediaSession;
  M.setActionHandler('play',()=>A.play());M.setActionHandler('pause',()=>A.pause());
  M.setActionHandler('nexttrack',()=>prox(false));M.setActionHandler('previoustrack',ant)}
async function baixar(t){
  toast('Preparando download...',90000);
  try{const r=await fetch('/api/baixar?id='+t.id,{headers:HD()});if(!r.ok)throw 0;
    const nome=decodeURIComponent(r.headers.get('X-Nome')||'')||(t.titulo+'.m4a');
    const b=await r.blob();
    if(window.AndroidBridge&&AndroidBridge.saveFile){
      const fr=new FileReader();fr.onload=()=>AndroidBridge.saveFile(fr.result,nome);fr.readAsDataURL(b);
    }else{
      const u=URL.createObjectURL(b),a=document.createElement('a');
      a.href=u;a.download=nome;document.body.appendChild(a);a.click();a.remove();
      setTimeout(()=>URL.revokeObjectURL(u),30000);
    }
    toast(r.headers.get('X-Capa')==='1'?'Baixado com capa: '+nome:'Baixado (sem capa): '+nome,4500);
  }catch(e){toast('Não consegui baixar essa música')}
}
function item(t,k,i,x){const n=fila[at]&&fila[at].id===t.id;return `<div class="it in${n?' now':''}" data-id="${t.id}" style="--n:${i%12}" data-k="${k}" data-i="${i}"><div class="th"><img loading="lazy" src="${img(t.id)}"><i class="eq"><b></b><b></b><b></b></i></div><div class="inf"><div class="t">${esc(t.titulo)}</div><div class="s">${esc(t.canal)}${t.dur?' · '+fmt(t.dur):''}</div></div>${x!=null?x:`<button class="ic" data-a="save" data-k="${k}" data-i="${i}">${ic('more')}</button>`}</div>`}
function card(t,k,i){const n=fila[at]&&fila[at].id===t.id;return `<div class="it cd in${n?' now':''}" data-id="${t.id}" style="--n:${i%12}" data-k="${k}" data-i="${i}"><div class="th"><img loading="lazy" src="${img(t.id)}"><i class="eq"><b></b><b></b><b></b></i></div><div class="t">${esc(t.titulo)}</div><div class="s">${esc(t.canal)}</div></div>`}
function anima(){const v=$('#v');v.classList.remove('vin');void v.offsetWidth;v.classList.add('vin')}
const skelCards=n=>'<div class="skc"></div>'.repeat(n);
const secH=s=>`<section data-sec="${s[0]}"><div class="sh"><h2>${esc(strip(s[1]))}</h2><button class="vt" data-a="chip" data-v="${esc(s[2])}">Ver tudo${ic('chevr')}</button></div><div class="hs" id="sec_${s[0]}">${skelCards(5)}</div></section>`;
function carregaSec(id){
  const pr=PRE[id]||api('secao?id='+id);PRE[id]=null;
  pr.then(j=>{const e=$('#sec_'+id);if(!e)return;const l=j.itens||[];L['s_'+id]=l;
    e.innerHTML=l.length?l.map((t,i)=>card(t,'s_'+id,i)).join(''):`<button class="btn" data-a="retry" data-v="${id}">Não carregou. Tentar de novo</button>`});
}
function observa(){
  if(io)io.disconnect();
  io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){io.unobserve(e.target);carregaSec(e.target.dataset.sec)}}),{rootMargin:'500px'});
  document.querySelectorAll('[data-sec]').forEach(x=>io.observe(x));
}
const vmBtn=(k,mais)=>{const e=$('#vm');if(e)e.innerHTML=mais?`<button class="btn bi vm" data-a="vermais" data-k="${k}">Ver mais${ic('chevd')}</button>`:''};
function inicio(){
  const c=chip,sid=(CHIPS.find(x=>x[0]===c)||[])[1];L.rec=lib.recentes;
  let h=`<div class="chips">${CHIPS.map(x=>`<button class="ch${x[0]===c?' on':''}" data-a="chip" data-v="${esc(x[0])}">${esc(x[0])}</button>`).join('')}</div>`;
  if(!sid){
    h+=(L.rec.length?`<div class="sh"><h2>Recentes</h2></div><div class="hs">${L.rec.slice(0,12).map((t,i)=>card(t,'rec',i)).join('')}</div>`:'')+'<div id="pes"></div>'+SEC.map(s=>secH(s)).join('');
    $('#v').innerHTML=h;
    const pp=PRE.pes||api('pessoal');PRE.pes=null;
    pp.then(j=>{const e=$('#pes');if(!e||chip!==c)return;const sh=j.shelves||[];
      sh.forEach(s=>{L['s_'+s.id]=s.itens});
      e.innerHTML=sh.map(s=>`<section><div class="sh"><h2>${esc(strip(s.titulo))}</h2></div><div class="hs">${s.itens.map((t,i)=>card(t,'s_'+s.id,i)).join('')}</div></section>`).join('')});
    observa();
  }else{
    h+=`<div class="sh"><h2>${esc(strip((SEC.find(s=>s[0]===sid)||[0,c])[1]))}</h2></div><div id="sv">${skel(6)}</div><div id="vm"></div>`;
    $('#v').innerHTML=h;
    api('secao?id='+sid+'&v=1').then(j=>{const e=$('#sv');if(!e||chip!==c)return;L.sv=j.itens||[];
      e.innerHTML=L.sv.map((t,i)=>item(t,'sv',i)).join('')||'<p class="s">Nada encontrado.</p>';vmBtn('sv',j.mais&&L.sv.length>0)});
  }
}
function buscarV(){
  $('#v').innerHTML=`<div class="bar"><input id="q" placeholder="Buscar música ou artista" autocomplete="off" value="${esc(lastQ)}"><button class="btn" data-a="busca">Buscar</button></div><div id="br">${(L.bu||[]).map((t,i)=>item(t,'bu',i)).join('')}</div><div id="vm"></div>`;
  $('#q').onkeydown=e=>{if(e.key==='Enter')busca()};
  if((L.bu||[]).length)vmBtn('bu',buMais);
}
async function busca(){
  const q=$('#q').value.trim();if(!q)return;lastQ=q;pgBusca=0;$('#br').innerHTML=skel(6);$('#vm').innerHTML='';
  const j=await api('search?q='+encodeURIComponent(q)+'&pg=0');L.bu=j.itens||[];buMais=!!j.mais;
  const e=$('#br');if(!e)return;
  e.innerHTML=L.bu.map((t,i)=>item(t,'bu',i)).join('')||'<p class="s">Nada encontrado.</p>';vmBtn('bu',buMais&&L.bu.length>0);
}
async function vermais(k){
  const box=$('#vm'),l=L[k]||[],ja=l.map(x=>x.id).join(',');let j;box.innerHTML=skel(3);
  if(k==='bu'){pgBusca++;j=await api('search?q='+encodeURIComponent(lastQ)+'&pg='+pgBusca+'&ja='+ja)}
  else{const sid=(CHIPS.find(x=>x[0]===chip)||[])[1];j=await api('secao?id='+sid+'&v=1&mais=1&ja='+ja)}
  const alvo=$(k==='bu'?'#br':'#sv');if(!alvo)return;
  const novos=j.itens||[];L[k]=l.concat(novos);
  alvo.insertAdjacentHTML('beforeend',novos.map((t,i)=>item(t,k,l.length+i)).join(''));
  if(k==='bu')buMais=!!j.mais;vmBtn(k,!!j.mais&&novos.length>0);
}
const row=(n,l)=>`<div class="it in" data-a="abrirpl" data-v="${esc(n)}">${l[0]?`<div class="th"><img src="${img(l[0].id)}"></div>`:'<div class="ph"></div>'}<div class="inf"><div class="t">${esc(n)}</div><div class="s">${l.length} músicas</div></div></div>`;
function bib(){
  if(plAb)return abrirPl();const P=lib.playlists;
  $('#v').innerHTML=`<h2>Biblioteca</h2><button class="btn bi" data-a="nova">${ic('plus')}Nova playlist</button>`
   +Object.keys(P).map(n=>row(n,P[n])).join('')+row('Recentes',lib.recentes);
}
function abrirPl(){
  const n=plAb,l=n==='Recentes'?lib.recentes:(lib.playlists[n]||[]);L.pl=l;const ed=n!=='Recentes';
  $('#v').innerHTML=`<button class="ic bi" data-a="voltar">${ic('back')}Biblioteca</button><h2>${esc(n)} <span class="s">${l.length} músicas</span></h2><div class="acts"><button class="btn bi" data-a="tocartudo">${ic('play')}Tocar tudo</button><button class="btn bi" data-a="aleat">${ic('shuffle')}Aleatório</button>${ed&&n!=='Favoritas'?`<button class="btn bi" data-a="apagarpl">${ic('trash')}Apagar</button>`:''}</div>`
   +(l.map((t,i)=>item(t,'pl',i,ed?`<button class="ic" data-a="rem" data-i="${i}">${ic('x')}</button>`:'')).join('')||'<p class="s">Vazia.</p>');
}
function render(){
  document.querySelectorAll('#nav button').forEach(b=>b.classList.toggle('on',b.dataset.v===tab));
  $('#hd').style.display=tab==='inicio'?'flex':'none';
  ({inicio,buscar:buscarV,bib,cfg:configV})[tab]();anima();
}
function renderFila(){
  $('#fn').textContent='Tocando: '+fonte+(mixLoading?' · montando o mix...':'');$('#pfn').textContent=fonte;
  $('#fc').innerHTML=['Tudo','Conhecidas','Descobrir'].map(f=>`<button class="ch${f===filtro?' on':''}" data-a="filtro" data-v="${f}">${f}</button>`).join('');
  const ok=x=>filtro==='Tudo'||(filtro==='Conhecidas'?x.c===true:x.c===false);
  $('#fl').innerHTML=fila.map((t,i)=>ok(t)?`<div class="qi it${i===at?' cur now':''}" data-id="${t.id}" data-k="fila" data-i="${i}"><div class="th"><img src="${img(t.id)}"><i class="eq"><b></b><b></b><b></b></i></div><div class="inf"><div class="t">${esc(t.titulo)}</div><div class="s">${esc(t.canal)}${t.dur?' · '+fmt(t.dur):''}</div></div>${filtro==='Tudo'?`<span class="hd">${ic('grip')}</span>`:''}</div>`:'').join('')+(mixLoading?skel(3):'');
}
function sheet(t){
  shT=t;const P=lib.playlists;
  $('#shl').innerHTML=`<div class="t" style="margin-bottom:8px;font-weight:800">${esc(t.titulo)}</div><button class="pr" data-a="dl"><span class="bi">${ic('down')}Baixar música</span></button>`
   +Object.keys(P).map(n=>`<button class="pr" data-a="tg" data-v="${esc(n)}"><span>${esc(n)}</span><span>${P[n].some(x=>x.id===t.id)?ic('check'):''}</span></button>`).join('')
   +`<button class="pr" data-a="novat"><span class="bi">${ic('plus')}Nova playlist</span></button>`;
  $('#sh').classList.add('open');
}
const pedeNome=()=>(prompt('Nome da playlist')||'').trim();
function act(b){
  const a=b.dataset.a,v=b.dataset.v,i=+b.dataset.i;
  if(a==='tab'){if(v===tab&&!plAb)return;const el=$('#v');el.classList.add('vout');
    setTimeout(()=>{el.classList.remove('vout');tab=v;plAb=null;render()},140)}
  else if(a==='chip'){chip=v;inicio();anima()}
  else if(a==='busca')busca();
  else if(a==='nova'){const n=pedeNome();if(n)api('pl',{acao:'criar',nome:n}).then(j=>{lib.playlists=j.playlists;bib()})}
  else if(a==='abrirpl'){plAb=v;bib();anima()}
  else if(a==='voltar'){plAb=null;bib();anima()}
  else if(a==='tocartudo'||a==='aleat'){if(L.pl&&L.pl.length)tocarLista(L.pl,0,plAb,a==='aleat')}
  else if(a==='apagarpl'){if(confirm('Apagar a playlist '+plAb+'?'))api('pl',{acao:'apagar',nome:plAb}).then(j=>{lib.playlists=j.playlists;plAb=null;bib();anima()})}
  else if(a==='rem'){api('pl',{acao:'rem',nome:plAb,track:L.pl[i]}).then(j=>{lib.playlists=j.playlists;bib()})}
  else if(a==='save'){const t=(L[b.dataset.k]||[])[i];if(t)sheet(t)}
  else if(a==='dl'){$('#sh').classList.remove('open');baixar(shT)}
  else if(a==='tg'){const has=(lib.playlists[v]||[]).some(x=>x.id===shT.id);
    api('pl',{acao:has?'rem':'add',nome:v,track:shT}).then(j=>{lib.playlists=j.playlists;sheet(shT);ui()})}
  else if(a==='novat'){const n=pedeNome();if(n)api('pl',{acao:'add',nome:n,track:shT}).then(j=>{lib.playlists=j.playlists;sheet(shT);ui()})}
  else if(a==='foto')$('#ff').click();
  else if(a==='fotorm'){api('foto',{remover:true}).then(j=>{if(j.ok){me.foto=false;me.v=j.v;pintaAv();configV();toast('Foto removida')}})}
  else if(a==='senha'){api('senha',{atual:$('#sa').value,nova:$('#sn').value}).then(j=>{
    if(j.ok){toast('Senha salva');$('#sa').value='';$('#sn').value=''}
    else toast(j.erro==='senha'?'Senha atual incorreta':'A nova senha precisa ter de 4 a 64 caracteres')})}
  else if(a==='sair'){api('sair',{}).then(()=>{ls.del('w7token');ls.del('w7perfil');location.reload()})}
  else if(a==='retry'){const e=$('#sec_'+v);if(e)e.innerHTML=skelCards(5);carregaSec(v)}
  else if(a==='vermais')vermais(b.dataset.k);
  else if(a==='instalar'){if(instalar){instalar.prompt();instalar.userChoice.finally(()=>{instalar=null;if(tab==='cfg')configV()})}}
  else if(a==='filtro'){filtro=v;renderFila()}
}
document.addEventListener('click',e=>{
  if(e.target.closest('.hd'))return;
  const b=e.target.closest('[data-a]');if(b)return act(b);
  const it=e.target.closest('.it');if(!it)return;
  const k=it.dataset.k,i=+it.dataset.i;
  if(k==='fila'){dir=i>=at?1:-1;destrava();return tocar(i)}
  const t=(L[k]||[])[i];if(!t)return;
  if(k==='pl')tocarLista(L.pl,i,plAb,false);else{destrava();abrirMusica(t,k)}
});
document.addEventListener('pointerdown',e=>{
  const h=e.target.closest('.hd');
  if(h){arr=h.closest('.qi');arr.classList.add('arr');h.setPointerCapture(e.pointerId);return}
  const it=e.target.closest('.it');
  if(it&&it.dataset.k&&it.dataset.k!=='fila'){const t=(L[it.dataset.k]||[])[+it.dataset.i];if(t){clearTimeout(pT);pT=setTimeout(()=>{getUrl(t.id);if(!/^(pl|fila)$/.test(it.dataset.k))getMix(t)},120)}}
});
document.addEventListener('pointercancel',()=>clearTimeout(pT));
document.addEventListener('pointermove',e=>{
  if(!arr)return;const o=document.elementFromPoint(e.clientX,e.clientY),t=o&&o.closest('.qi');
  if(t&&t!==arr){const r=t.getBoundingClientRect();if(e.clientY<r.top+r.height/2)t.before(arr);else t.after(arr)}
});
document.addEventListener('pointerup',()=>{
  if(!arr)return;const cur=fila[at];
  const ids=[...document.querySelectorAll('#fl .qi')].map(x=>x.dataset.id);
  fila=ids.map(id=>fila.find(x=>x.id===id));at=fila.indexOf(cur);arr=null;renderFila();
});
function logo(el,anim){el.innerHTML=[...'W7PlayMusic'].map((c,i)=>`<span class="lt${i<2?' w':''}"${anim?` style="animation-delay:${i*70}ms,${900+i*70}ms"`:''}>${c}</span>`).join('')}
function sair(){return new Promise(res=>{
  const sp=$('#splash'),sl=$('#sl'),h=$('#hlogo');
  if(RM){sp.remove();h.style.visibility='visible';return res()}
  const a=sl.getBoundingClientRect(),b=h.getBoundingClientRect();
  const s=b.width/a.width,dx=b.left+b.width/2-(a.left+a.width/2),dy=b.top+b.height/2-(a.top+a.height/2);
  sp.classList.add('go');sl.style.transform=`translate(${dx}px,${dy}px) scale(${s})`;
  setTimeout(()=>{h.style.visibility='visible';sp.remove();res()},880);
})}
const fotoUrl=(n,v)=>'/api/foto?n='+encodeURIComponent(n)+'&v='+v;
const avH=(x,big)=>x.foto?`<img class="pav${big?' big':''}" src="${fotoUrl(x.nome,x.v)}">`:`<span class="pav${big?' big':''}">${esc((x.nome||'?')[0].toUpperCase())}</span>`;
const pintaAv=()=>{$('#av').innerHTML=avH(me,false)};
function configV(){
  const inst=standalone()?'':`<h2>Instalar app</h2>${instalar?`<button class="btn bi" data-a="instalar">${ic('inst')}Instalar na tela inicial</button>`:'<p class="s">No Chrome, abra o menu (três pontinhos) e toque em Instalar app ou Adicionar à tela inicial.</p>'}`;
  $('#v').innerHTML=`<div style="text-align:center;margin-top:18px">${avH(me,true)}<h2 style="margin:12px 0 4px">${esc(me.nome)}</h2></div>
  <div class="acts" style="justify-content:center"><button class="btn bi" data-a="foto">${ic('cam')}Trocar foto</button>${me.foto?`<button class="btn bi" data-a="fotorm">${ic('trash')}Remover foto</button>`:''}</div>
  <h2>Senha</h2><input class="fld" id="sa" type="password" placeholder="Senha atual" autocomplete="current-password"><div style="height:8px"></div><input class="fld" id="sn" type="password" placeholder="Nova senha (mínimo 4)" autocomplete="new-password"><div class="acts"><button class="btn" data-a="senha">Salvar senha</button></div>
  ${inst}<h2>Conta</h2><button class="btn bi" data-a="sair">${ic('out')}Sair da conta</button>`;
}
$('#ff').onchange=async e=>{
  const f=e.target.files[0];e.target.value='';if(!f)return;
  try{const bmp=await createImageBitmap(f),s=Math.min(bmp.width,bmp.height),c=document.createElement('canvas');
    c.width=c.height=256;c.getContext('2d').drawImage(bmp,(bmp.width-s)/2,(bmp.height-s)/2,s,s,0,0,256,256);
    const j=await api('foto',{dados:c.toDataURL('image/jpeg',.8)});
    if(j.ok){me.foto=true;me.v=j.v;pintaAv();if(tab==='cfg')configV();toast('Foto atualizada')}else toast('Não consegui salvar a foto');
  }catch(err){toast('Imagem inválida')}
};
function picker(lista){return new Promise(res=>{
  const ld=document.querySelector('.ld'),p=$('#pick');ld.style.display='none';
  const fin=r=>{p.classList.remove('show');ld.style.display='';res(r)};
  const show=h=>{p.classList.remove('show');void p.offsetWidth;p.innerHTML=h;p.classList.add('show')};
  const erro=m=>{const e=$('#pke');e.textContent=m;e.classList.remove('shake');void e.offsetWidth;e.classList.add('shake')};
  const t1=()=>{
    show(`<div class="pk-t">Quem está ouvindo?</div><div id="pkl">${lista.map((x,i)=>`<button class="btn pk" data-i="${i}">${avH(x,false)}<span>${esc(x.nome)}</span></button>`).join('')}</div><button class="btn bi" id="pkn">${ic('plus')}Novo perfil</button>`);
    $('#pkl').onclick=e=>{const b=e.target.closest('[data-i]');if(!b)return;const x=lista[+b.dataset.i];x.tem_senha?tLogin(x):tSenha(x.nome,'definir')};
    $('#pkn').onclick=tNome;
  };
  const tLogin=x=>{
    show(`<div class="pk-t">Olá, ${esc(x.nome)}</div><input class="fld" id="pks" type="password" placeholder="Senha" autocomplete="current-password"><div class="err" id="pke"></div><button class="btn" id="pkok">Entrar</button><button class="ic bi" id="pkv">${ic('back')}Voltar</button>`);
    const go=async()=>{const s=$('#pks').value;if(!s)return;$('#pkok').disabled=true;
      const j=await api('entrar',{nome:x.nome,senha:s});$('#pkok').disabled=false;
      if(j.token)return fin({nome:j.nome,token:j.token});
      if(j.definir)return tSenha(x.nome,'definir');
      erro(j.erro==='bloqueado'?'Muitas tentativas. Espere '+j.espera+'s':j.erro==='senha'?'Senha incorreta':'Erro, tente de novo')};
    $('#pkok').onclick=go;$('#pks').onkeydown=e=>{if(e.key==='Enter')go()};$('#pkv').onclick=t1;
  };
  const tNome=()=>{
    show(`<div class="pk-t">Novo perfil</div><input class="fld" id="pkn2" maxlength="20" placeholder="Seu nome" autocomplete="off"><div class="err" id="pke"></div><button class="btn" id="pkok">Continuar</button><button class="ic bi" id="pkv">${ic('back')}Voltar</button>`);
    const go=()=>{const n=$('#pkn2').value.trim().replace(/[^\w \-]/g,'').slice(0,20);if(!n)return;
      if(lista.some(x=>x.nome.toLowerCase()===n.toLowerCase()))return erro('Esse nome já existe');tSenha(n,'criar')};
    $('#pkok').onclick=go;$('#pkn2').onkeydown=e=>{if(e.key==='Enter')go()};$('#pkv').onclick=t1;
  };
  const tSenha=(n,modo)=>{
    show(`<div class="pk-t">${modo==='criar'?'Crie uma senha':'Defina uma senha para proteger este perfil'}</div><div class="s">Letras e números, mínimo 4 caracteres</div><input class="fld" id="pks" type="password" placeholder="Senha" autocomplete="new-password"><input class="fld" id="pks2" type="password" placeholder="Repita a senha" autocomplete="new-password"><div class="err" id="pke"></div><button class="btn" id="pkok">${modo==='criar'?'Criar perfil':'Salvar e entrar'}</button><button class="ic bi" id="pkv">${ic('back')}Voltar</button>`);
    const go=async()=>{const s=$('#pks').value;
      if(s.length<4)return erro('Mínimo 4 caracteres');if(s!==$('#pks2').value)return erro('As senhas não são iguais');
      $('#pkok').disabled=true;const j=await api(modo==='criar'?'criar':'definir',{nome:n,senha:s});$('#pkok').disabled=false;
      if(j.token)return fin({nome:j.nome||n,token:j.token});
      erro(j.erro==='nome_existe'?'Esse nome já existe':j.erro==='lotado'?'Limite de perfis atingido':'Não foi possível, tente de novo')};
    $('#pkok').onclick=go;$('#pks2').onkeydown=e=>{if(e.key==='Enter')go()};$('#pkv').onclick=t1;
  };
  t1();
})}
async function boot(){
  pintaIcones();if('serviceWorker' in navigator)navigator.serviceWorker.register('/sw.js').catch(()=>{});
  let t0=Date.now();logo($('#sl'),true);logo($('#hlogo'),false);
  if(!token){
    const pj=await api('perfis');await wait(1800);
    const r=await picker(pj.perfis||[]);
    perfil=r.nome;token=r.token;ls.set('w7perfil',perfil);ls.set('w7token',token);
    t0=Date.now()-1800;
  }
  const lp=api('lib');PRE.alta=api('secao?id=alta');PRE.pes=api('pessoal');
  const j=await lp;lib={playlists:j.playlists||{},recentes:j.recentes||[],gosto:j.gosto||{}};
  me=j.eu||{nome:perfil,foto:false,v:0};pintaAv();
  await Promise.race([PRE.alta,wait(8000)]);
  await wait(Math.max(0,3000-(Date.now()-t0)));
  render();await sair();
}
boot();
</script></body></html>
"""
HTML = HTML.replace("@@SECOES@@", json.dumps([[s[0], s[1], s[2]] for s in SECOES], ensure_ascii=False))


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def out(self, obj, tipo="application/json; charset=utf-8"):
        b = obj.encode() if isinstance(obj, str) else json.dumps(obj, ensure_ascii=False).encode()
        self.send_response(200)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def token(self):
        return self.headers.get("X-Token", "")

    def auth(self):
        n = urllib.parse.unquote(self.headers.get("X-Perfil", "")).strip()
        k = achar(n) if NOME.fullmatch(n) else None
        t = self.token()
        if not k or not t:
            return None
        P = D["perfis"][k]
        return (k, P) if token_ok(P, t) else None

    def json_perfil(self, k, P):
        with LOCK:
            s = json.dumps({"playlists": P["playlists"], "recentes": P["recentes"],
                            "gosto": P["gosto"],
                            "eu": {"nome": k, "foto": bool(P["foto"]), "v": P["foto_v"]}}, ensure_ascii=False)
        self.out(s)

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        p = {k: v[0] for k, v in urllib.parse.parse_qs(u.query).items()}
        r = u.path
        try:
            if r == "/":
                return self.out(HTML, "text/html; charset=utf-8")
            if r == "/api/perfis":
                with LOCK:
                    ps = [{"nome": k, "foto": bool(v["foto"]), "v": v["foto_v"], "tem_senha": bool(v["senha"])}
                          for k, v in D["perfis"].items()]
                return self.out({"perfis": ps})
            if r == "/manifest.webmanifest":
                return self.out(MANIFEST, "application/manifest+json; charset=utf-8")
            if r == "/sw.js":
                return self.out(SW, "text/javascript; charset=utf-8")
            if r in ("/icon-192.png", "/icon-512.png"):
                b = ICON192 if "192" in r else ICON512
                self.send_response(200)
                self.send_header("Content-Type", "image/png")
                self.send_header("Content-Length", str(len(b)))
                self.send_header("Cache-Control", "public, max-age=86400")
                self.end_headers()
                return self.wfile.write(b)
            if r == "/api/foto":
                k = achar(p.get("n"))
                if not k or not D["perfis"][k]["foto"]:
                    return self.send_error(404)
                b = base64.b64decode(D["perfis"][k]["foto"])
                self.send_response(200)
                self.send_header("Content-Type", "image/jpeg")
                self.send_header("Content-Length", str(len(b)))
                self.send_header("Cache-Control", "public, max-age=31536000")
                self.end_headers()
                return self.wfile.write(b)
            a = self.auth()
            if not a:
                return self.out({"erro": "auth"}) if r.startswith("/api/") and r != "/api/baixar" else self.send_error(401)
            k, P = a
            if r == "/api/lib":
                return self.json_perfil(k, P)
            if r == "/api/pessoal":
                return self.out({"shelves": pessoal(P)})
            if r == "/api/secao":
                sid = p.get("id", "")
                if sid not in SEC_IDS:
                    return self.out({"itens": [], "mais": False})
                ja2 = [x for x in p.get("ja", "").split(",")[:300] if ID.fullmatch(x)]
                if p.get("v") == "1":
                    return self.out(secao_pag(sid, p.get("mais") == "1", ja2))
                return self.out({"itens": (secao(sid) or [])[:24]})
            ja = [x for x in p.get("ja", "").split(",")[:300] if ID.fullmatch(x)]
            if r == "/api/search":
                try:
                    pg = max(0, min(int(p.get("pg", 0)), 5))
                except ValueError:
                    pg = 0
                return self.out(busca_pag(p.get("q", "")[:100], pg, ja))
            i = p.get("id", "")
            if r in ("/api/mix", "/api/url", "/api/baixar") and not ID.fullmatch(i):
                return self.out({"erro": "ID inválido"})
            if r == "/api/mix":
                t = p.get("t", "")[:100]
                itens = cache("mix:" + i, 600, lambda: mix_yt(i, t)) or []
                return self.out({"itens": ordenar(itens, P)[:30]})
            if r == "/api/url":
                u2 = url_audio(i)
                return self.out({"url": u2} if u2 else {"erro": "Sem áudio"})
            if r == "/api/baixar":
                return self.baixar(i)
        except Exception as e:
            return self.out({"erro": str(e)[:150]})
        self.send_error(404)

    def baixar(self, i):
        tmp = tempfile.mkdtemp()
        try:
            with SEMD, ydl(format="ba[ext=m4a]/ba", noplaylist=True, skip_download=False,
                           outtmpl=os.path.join(tmp, "%(title).80s.%(ext)s")) as y:
                info = y.extract_info("https://www.youtube.com/watch?v=" + i, download=True) or {}
            fs = [f for f in os.listdir(tmp) if not f.endswith((".part", ".ytdl"))]
            if not fs:
                return self.send_error(500)
            nome = fs[0]
            caminho = os.path.join(tmp, nome)
            titulo = info.get("track") or info.get("title") or os.path.splitext(nome)[0]
            artista = info.get("artist") or (info.get("channel") or info.get("uploader") or "").replace(" - Topic", "")
            com_capa = etiqueta(caminho, titulo, artista, capa_bytes(i))
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(os.path.getsize(caminho)))
            self.send_header("X-Nome", urllib.parse.quote(nome))
            self.send_header("X-Capa", "1" if com_capa else "0")
            self.send_header("Content-Disposition", "attachment; filename*=UTF-8''" + urllib.parse.quote(nome))
            self.end_headers()
            with open(caminho, "rb") as f:
                shutil.copyfileobj(f, self.wfile)
        except Exception:
            try:
                self.send_error(500)
            except Exception:
                pass
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def do_POST(self):
        try:
            n = min(int(self.headers.get("Content-Length", 0)), 200000)
            d = json.loads(self.rfile.read(n) or b"{}")
            if not isinstance(d, dict):
                d = {}
            r = self.path
            if r == "/api/entrar":
                return self.out(entrar(d))
            if r == "/api/criar":
                return self.out(criar(d))
            if r == "/api/definir":
                return self.out(definir(d))
            a = self.auth()
            if not a:
                return self.out({"erro": "auth"})
            k, P = a
            if r == "/api/evento":
                evento(P, d.get("tipo"), d.get("track"))
                return self.out({"ok": 1})
            if r == "/api/pl":
                pl(P, d)
                return self.json_perfil(k, P)
            if r == "/api/senha":
                return self.out(trocar_senha(P, d, self.token()))
            if r == "/api/foto":
                return self.out(foto(P, d))
            if r == "/api/sair":
                sair(P, self.token())
                return self.out({"ok": 1})
        except Exception as e:
            return self.out({"erro": str(e)[:150]})
        self.send_error(404)


def iniciar_android(diretorio):
    """Inicia o backend local dentro do processo Android (Chaquopy)."""
    global ARQ, ARQ_CACHE, D, SECAO_CACHE
    os.makedirs(diretorio, exist_ok=True)
    ARQ = os.path.join(diretorio, "musica_dados.json")
    ARQ_CACHE = os.path.join(diretorio, "musica_cache_v7.json")
    D = carregar()
    try:
        with open(ARQ_CACHE, encoding="utf-8") as f:
            SECAO_CACHE = json.load(f)
    except Exception:
        SECAO_CACHE = {}
    threading.Thread(target=aquecer, daemon=True).start()
    servidor = ThreadingHTTPServer(("127.0.0.1", 8003), H)
    threading.Thread(target=servidor.serve_forever, daemon=True).start()
    return "ok"


if __name__ == "__main__":
    if "--resetar-senha" in sys.argv:
        i = sys.argv.index("--resetar-senha")
        k = achar(sys.argv[i + 1]) if len(sys.argv) > i + 1 else None
        if not k:
            raise SystemExit("Perfil não encontrado. Uso: python player_musica_v7.py --resetar-senha NOME")
        D["perfis"][k]["senha"], D["perfis"][k]["tokens"] = None, []
        salvar()
        raise SystemExit(f"Senha de '{k}' removida. Na próxima entrada será pedida uma nova senha.")
    rede = "--rede" in sys.argv
    try:
        import mutagen  # noqa: F401
    except ImportError:
        print("Dica: rode 'pip install mutagen' para os downloads virem com capa.")
    threading.Thread(target=aquecer, daemon=True).start()
    print("Rodando em http://localhost:8003  (Ctrl+C para parar)")
    if rede:
        print("Mesmo Wi-Fi: http://" + meu_ip() + ":8003")
    ThreadingHTTPServer(("0.0.0.0" if rede else "127.0.0.1", 8003), H).serve_forever()
